import json,subprocess,sys
from pathlib import Path
repo=Path.cwd(); output=repo/'.cache/combined-ci-preparation-tests-shared-objects'; output.mkdir()
windows=[sys.executable,'-B',str(repo/'reports/implementation/range-combined-candidate/tools/prepare.spec.py'),str(repo),'C:/Users/guido/ghq/projects/rustdom/.git']
linux=['wsl','-d','Ubuntu-22.04','--cd','/','--','python3','-B','/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom/reports/implementation/range-combined-candidate/tools/prepare.spec.py','/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom']
records=[]
for label,argv in [('windows',windows),('linux',linux+['/home/guido/rustdom-validation/range-combined-candidate-20261025-f781/source']),('linux-shallow',linux+['/home/guido/rustdom-validation/combined-ci-shallow-contract-20261025/source'])]:
 with (output/(label+'.stdout.log')).open('xb') as stdout,(output/(label+'.stderr.log')).open('xb') as stderr:
  result=subprocess.run(argv,stdout=stdout,stderr=stderr,timeout=240)
 records.append({'label':label,'argv':argv,'exitCode':result.returncode})
 (output/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
 print(json.dumps(records[-1]),flush=True)
 assert result.returncode==0,label
