"""Exercise the published CI entry points in a fresh Linux Git checkout, without historical package changes."""
import hashlib,json,os,subprocess
from pathlib import Path
repository=Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom')
root=Path('/home/guido/rustdom-validation/combined-range-ci-entry-20261025')
source=root/'source';origin=Path('/home/guido/rustdom-validation/range-combined-candidate-20261025-f781/source')
assert not root.exists();root.mkdir()
for argv in [['git','clone','--shared','--no-checkout',str(origin),str(source)],
             ['git','-C',str(source),'config','core.autocrlf','false'],
             ['git','-C',str(source),'sparse-checkout','set','--no-cone','/*','!/*/','/src/','/scripts/','/benchmarks/','/tests/','/third-party/','/types/',
              '/reports/validation/native-class-ownership/ci-macos-timeout/fixture.json.gz',
              '/reports/validation/native-class-ownership/ci-macos-timeout/39686199408/fixture.json.gz',
              '/reports/validation/native-class-ownership/ci-windows-timeout/39894045206/comparison.json.gz'],
             ['git','-C',str(source),'checkout','--detach','f781c3b7549a86b6aa8b5a34d2bbb32038c315b7']]:
    subprocess.run(argv,cwd=root,check=True)
node=Path('/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node/bin/node')
tools=repository/'reports/implementation/range-combined-candidate/tools'
assert hashlib.sha256(node.read_bytes()).hexdigest()=='bf9112eb83a827dc9f9c8d19bb7bddcbf00f7b2fedae18fdcaee05406981f20a'
identities={file.relative_to(tools).as_posix():hashlib.sha256(file.read_bytes()).hexdigest() for file in tools.rglob('*') if file.is_file() and '__pycache__' not in file.parts}
(root/'tools-inputs.json').write_text(json.dumps(identities,indent=2)+'\n')
toolchain=Path('/home/guido/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin')
environment=dict(os.environ,PATH=str(node.parent)+os.pathsep+str(toolchain)+os.pathsep+os.environ.get('PATH',''),RUSTC=str(toolchain/'rustc'),RUSTDOC=str(toolchain/'rustdoc'),RUSTUP_TOOLCHAIN='1.99.1',CARGO_HOME='/mnt/c/Users/guido/ghq/projects/rustdom/.tools/cargo',CARGO_TARGET_DIR=str(root/'target'),CARGO_BUILD_JOBS='2',CARGO_INCREMENTAL='0')
commands=[]
for label,argv in [('prepare',['python3','-B',str(tools/'prepare.py'),str(repository),str(source),str(root/'proof')]),
                   ('qualify',['python3','-B',str(tools/'qualify.py'),str(repository),str(source),str(root/'proof'),str(node)])]:
    with (root/(label+'.stdout.log')).open('xb') as stdout,(root/(label+'.stderr.log')).open('xb') as stderr:
        observed=subprocess.run(argv,cwd=root,env=environment,stdout=stdout,stderr=stderr)
    commands.append({'label':label,'argv':argv,'exitCode':observed.returncode})
    (root/'entry-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    print(json.dumps(commands[-1]),flush=True)
    assert observed.returncode==0,label
print(json.dumps({'publicEntryPointPassed':True,'benchmarkExecuted':False,'performanceAccepted':None}))
