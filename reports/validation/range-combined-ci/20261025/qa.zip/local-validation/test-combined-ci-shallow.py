import json,subprocess
from pathlib import Path
root=Path('/home/guido/rustdom-validation/combined-ci-shallow-contract-20261025');root.mkdir()
source=root/'source';origin=Path('/home/guido/rustdom-validation/range-combined-candidate-20261025-f781/source')
records=[]
for label,argv in [('clone',['git','clone','--shared','--no-checkout',str(origin),str(source)]),
                   ('depth',['git','-C',str(source),'fetch','--depth=2','origin','f781c3b7549a86b6aa8b5a34d2bbb32038c315b7']),
                   ('checkout',['git','-C',str(source),'checkout','--detach','f781c3b7549a86b6aa8b5a34d2bbb32038c315b7'])]:
    with (root/(label+'.stdout.log')).open('xb') as stdout,(root/(label+'.stderr.log')).open('xb') as stderr:
        observed=subprocess.run(argv,cwd=root,stdout=stdout,stderr=stderr)
    records.append({'argv':argv,'exitCode':observed.returncode});assert observed.returncode==0,label
assert subprocess.check_output(['git','rev-parse','--is-shallow-repository'],cwd=source).strip()==b'true'
argv=['python3','-B','/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom/reports/implementation/range-combined-candidate/tools/prepare.spec.py','/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom',str(source)]
with (root/'contracts.stdout.log').open('xb') as stdout,(root/'contracts.stderr.log').open('xb') as stderr:
    observed=subprocess.run(argv,cwd=root,stdout=stdout,stderr=stderr)
records.append({'argv':argv,'exitCode':observed.returncode})
(root/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
assert observed.returncode==0
print(json.dumps({'shallowDepth':2,'preparationContracts':8,'exitCode':observed.returncode}))
