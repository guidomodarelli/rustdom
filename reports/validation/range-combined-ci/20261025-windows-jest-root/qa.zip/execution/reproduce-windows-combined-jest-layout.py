"""Reproduce Windows Jest discovery using the authenticated current candidate DLL, real Git, and real dependencies."""
import hashlib,json,os,subprocess,sys,zipfile
from pathlib import Path,PurePosixPath
repo=Path.cwd();main=Path('C:/Users/guido/ghq/projects/rustdom');root=main/'artifacts/combined-windows-layout-20261025';assert not root.exists();root.mkdir()
outer=root/'workspace';outer.mkdir();origin=main/'.git/objects';assert origin.is_dir()
archive=repo/'.cache/combined-ci-b6146131-failures/12588507573.zip';meta=next(m for m in json.loads((repo/'.cache/combined-ci-b6146131-failures/artifacts-early.json').read_bytes())['artifacts'] if m['id']==12588507573)
raw=archive.read_bytes();assert 'sha256:'+hashlib.sha256(raw).hexdigest()==meta['digest'] and len(raw)==meta['size_in_bytes'];assert meta['workflow_run']['id']==40165972204 and meta['workflow_run']['head_sha']=='b6146131c482c0c43eb501b3cf5525ed9cb34c5b'
records=[]
def run(label,argv,cwd=root,expect=0,env=None):
 result=subprocess.run(list(map(str,argv)),cwd=cwd,env=env,capture_output=True)
 (root/(label+'.stdout.log')).write_bytes(result.stdout);(root/(label+'.stderr.log')).write_bytes(result.stderr)
 records.append({'label':label,'argv':list(map(str,argv)),'cwd':str(cwd),'exitCode':result.returncode,'expected':expect});(root/'commands.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(records[-1]),flush=True)
 assert (result.returncode!=0 if expect=='nonzero' else result.returncode==expect),label
 return result
sources={}
for label,relative in [('before','.cache/combined-range-source'),('after','artifacts/combined-range-source')]:
 source=outer/relative;source.parent.mkdir(parents=True,exist_ok=True)
 run(label+'-init',['git','init',source]);(source/'.git/objects/info/alternates').write_text(origin.as_posix()+'\n',encoding='utf-8',newline='\n')
 run(label+'-autocrlf',['git','config','core.autocrlf','false'],source)
 run(label+'-sparse',['git','sparse-checkout','set','--no-cone','/*','!/*/','/src/','/scripts/','/tests/','/types/'],source)
 run(label+'-checkout',['git','checkout','--detach','f781c3b7549a86b6aa8b5a34d2bbb32038c315b7'],source)
 run(label+'-prepare',[sys.executable,'-B',repo/'reports/implementation/range-combined-candidate/tools/prepare.py',repo,source,root/(label+'-proof')])
 with zipfile.ZipFile(archive) as z:
  marker=next(n for n in z.namelist() if n.endswith('/combined-range-source/dist/native-build.json'));prefix=marker[:-len('dist/native-build.json')]
  for info in z.infolist():
   if not info.filename.startswith(prefix) or info.is_dir():continue
   relative=PurePosixPath(info.filename[len(prefix):]);assert not relative.is_absolute() and '..' not in relative.parts
   target=source.joinpath(*relative.parts);assert target.resolve().is_relative_to(source.resolve())
   data=z.read(info)
   if relative.parts[0]=='src':assert target.read_bytes()==data,str(relative)
   elif relative.parts[0] in ['dist','types']:target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
  native=json.loads((source/'dist/native-build.json').read_bytes());assert hashlib.sha256((source/'dist/rustdom.node').read_bytes()).hexdigest()==native['binarySha256']
 run(label+'-junction',['cmd','/c','mklink','/J',source/'node_modules',main/'node_modules'])
 sources[label]=source
for version in ['22.12.0','24.14.1']:
 node=main/'.tools/node-win'/('node-v'+version+'-win-x64')/'node.exe';npm=node.parent/'node_modules/npm/bin/npm-cli.js';assert node.is_file() and npm.is_file()
 env=dict(os.environ,PATH=str(node.parent)+os.pathsep+os.environ['PATH'])
 observed=run('node-'+version,[node,'--version'],env=env);assert observed.stdout.strip()==('v'+version).encode()
 before=run('before-jest-'+version,[node,npm,'run','test:jest'],sources['before'],'nonzero',env)
 assert b'No tests found' in before.stdout
 after=run('after-jest-'+version,[node,npm,'run','test:jest'],sources['after'],env=env)
 assert b'22 passed, 22 total' in after.stderr,after.stderr[-3000:]
 for name in ['test:vitest','test:vm']:
  run('after-'+name.replace(':','-')+'-'+version,[node,npm,'run',name],sources['after'],env=env)
(root/'summary.json').write_text(json.dumps({'artifact':12588507573,'sourceRun':40165972204,'artifactSha256':hashlib.sha256(raw).hexdigest(),'nodeVersions':['22.12.0','24.14.1'],'beforeJestTestsFound':False,'afterJestPassedPerNode':22,'vitestAndVmPassed':True,'nativeMocked':False,'dependenciesRoot':str(main/'node_modules'),'sourceCommit':'f781c3b7549a86b6aa8b5a34d2bbb32038c315b7','runtimeIntegrated':False,'benchmarkExecuted':False,'performanceAccepted':None},indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'windowsRealJestBothNodesPassed':True,'vitestAndVmPassed':True,'benchmarkExecuted':False}))
