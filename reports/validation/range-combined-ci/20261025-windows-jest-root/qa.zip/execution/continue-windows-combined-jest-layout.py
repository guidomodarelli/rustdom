"""Continue the retained Windows reproduction with its own lockfile-installed dependencies; preserve the initial setup failure."""
import hashlib,json,os,subprocess
from pathlib import Path
repo=Path.cwd();main=Path('C:/Users/guido/ghq/projects/rustdom');root=main/'artifacts/combined-windows-layout-20261025';outer=root/'workspace';sources={'before':outer/'.cache/combined-range-source','after':outer/'artifacts/combined-range-source'}
records=json.loads((root/'commands.json').read_bytes())
def run(label,argv,cwd=root,expect=0,env=None):
 assert all(record['label']!=label for record in records)
 result=subprocess.run(list(map(str,argv)),cwd=cwd,env=env,capture_output=True)
 (root/(label+'.stdout.log')).write_bytes(result.stdout);(root/(label+'.stderr.log')).write_bytes(result.stderr);records.append({'label':label,'argv':list(map(str,argv)),'cwd':str(cwd),'exitCode':result.returncode,'expected':expect});(root/'commands.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(records[-1]),flush=True)
 assert (result.returncode!=0 if expect=='nonzero' else result.returncode==expect),label
 return result
removed=[]
for label,source in sources.items():
 junction=source/'node_modules';assert junction.is_junction();assert junction.parent.resolve()==source.resolve();target=junction.resolve();assert target==(main/'node_modules').resolve()
 # Remove only our junction entry, never recurse into or alter its shared target.
 os.rmdir(junction);assert not os.path.lexists(junction) and target.is_dir();removed.append({'link':str(junction),'preservedTarget':str(target),'recursive':False})
(root/'junction-entry-removal.json').write_text(json.dumps(removed,indent=2)+'\n')
node24=main/'.tools/node-win/node-v24.14.1-win-x64/node.exe';npm24=node24.parent/'node_modules/npm/bin/npm-cli.js';env24=dict(os.environ,PATH=str(node24.parent)+os.pathsep+os.environ['PATH'])
run('own-dependencies-ci',[node24,npm24,'ci','--no-audit','--no-fund'],sources['after'],env=env24)
run('before-own-dependencies-junction',['cmd','/c','mklink','/J',sources['before']/'node_modules',sources['after']/'node_modules'])
lock=(sources['after']/'package-lock.json').read_bytes();manifest=json.loads((repo/'reports/implementation/range-combined-candidate/source.json').read_bytes());assert hashlib.sha256(lock).hexdigest()==manifest['buildInputs']['package-lock.json']
for version in ['22.12.0','24.14.1']:
 node=main/'.tools/node-win'/('node-v'+version+'-win-x64')/'node.exe';npm=node.parent/'node_modules/npm/bin/npm-cli.js';env=dict(os.environ,PATH=str(node.parent)+os.pathsep+os.environ['PATH'])
 before=run('confirmed-before-jest-'+version,[node,npm,'run','test:jest'],sources['before'],'nonzero',env);assert b'No tests found' in before.stdout
 after=run('confirmed-after-jest-'+version,[node,npm,'run','test:jest'],sources['after'],env=env);assert b'22 passed, 22 total' in after.stderr,after.stderr[-3000:]
 for name in ['test:vitest','test:vm']:run('confirmed-after-'+name.replace(':','-')+'-'+version,[node,npm,'run',name],sources['after'],env=env)
(root/'summary.json').write_text(json.dumps({'artifact':12588507573,'sourceRun':40165972204,'nodeVersions':['22.12.0','24.14.1'],'beforeJestTestsFound':False,'afterJestPassedPerNode':22,'vitestAndVmPassed':True,'nativeMocked':False,'dependenciesSource':'npm ci from exact authenticated candidate lockfile in owned private checkout','originalSharedDependencyJunctionsRemovedWithoutRecursion':removed,'initialDependencySetupFailurePreserved':True,'sourceCommit':'f781c3b7549a86b6aa8b5a34d2bbb32038c315b7','runtimeIntegrated':False,'benchmarkExecuted':False,'performanceAccepted':None},indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'realJestBothWindowsNodesPassed':True,'vitestAndVmPassed':True,'benchmarkExecuted':False}))
