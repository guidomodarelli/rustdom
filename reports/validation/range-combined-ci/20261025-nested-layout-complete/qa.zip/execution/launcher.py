"""Reproduce actual Actions nesting, retain its Cargo failure, then qualify the corrected layout once."""
import hashlib,json,os,subprocess
from pathlib import Path
repo=Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom')
root=Path('/home/guido/rustdom-validation/combined-ci-nested-layout-20261025');assert not root.exists();root.mkdir()
outer=root/'workspace';source=outer/'.cache/combined-range-source';origin=Path('/mnt/c/Users/guido/ghq/projects/rustdom/.git')
node=Path('/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node/bin/node');toolchain=Path('/home/guido/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin')
env=dict(os.environ,PATH=str(node.parent)+os.pathsep+str(toolchain)+os.pathsep+os.environ['PATH'],RUSTC=str(toolchain/'rustc'),RUSTDOC=str(toolchain/'rustdoc'),RUSTUP_TOOLCHAIN='1.99.1',CARGO_HOME='/mnt/c/Users/guido/ghq/projects/rustdom/.tools/cargo',CARGO_TARGET_DIR='/home/guido/rustdom-validation/combined-range-ci-entry-20261025/target',CARGO_BUILD_JOBS='2',CARGO_INCREMENTAL='0')
records=[]
def run(label,argv,cwd=root,expect=0):
 with (root/(label+'.stdout.log')).open('xb') as stdout,(root/(label+'.stderr.log')).open('xb') as stderr:
  result=subprocess.run(list(map(str,argv)),cwd=cwd,env=env,stdout=stdout,stderr=stderr)
 records.append({'label':label,'argv':list(map(str,argv)),'exitCode':result.returncode,'expectedExitCode':expect})
 (root/'layout-commands.json').write_text(json.dumps(records,indent=2)+'\n')
 print(json.dumps(records[-1]),flush=True)
 assert (result.returncode!=0 if expect=='nonzero' else result.returncode==expect),label
 return result

def checkout(label,path,commit,patterns):
 run(label+'-init',['git','init',path]);alternate=path/'.git/objects/info/alternates';alternate.write_text((origin/'objects').as_posix()+'\n')
 run(label+'-autocrlf',['git','config','core.autocrlf','false'],path)
 run(label+'-sparse',['git','sparse-checkout','set','--no-cone',*patterns],path)
 run(label+'-checkout',['git','checkout','--detach',commit],path)
outer_patterns=['/*','!/*/','/.github/','/reports/implementation/range-combined-candidate/','/reports/implementation/static-range-candidate/','/reports/benchmarks/native-class-ownership/range-collapse-candidate/']
checkout('outer',outer,'f2c449e645bad996d34be3cb655807ad83611ffc',outer_patterns)
checkout('source',source,'f781c3b7549a86b6aa8b5a34d2bbb32038c315b7',['/*','!/*/','/src/','/scripts/','/benchmarks/','/tests/','/types/','/third-party/','/reports/validation/native-class-ownership/ci-macos-timeout/fixture.json.gz','/reports/validation/native-class-ownership/ci-macos-timeout/39686199408/fixture.json.gz','/reports/validation/native-class-ownership/ci-windows-timeout/39894045206/comparison.json.gz'])
run('nested-before-format',['cargo','fmt','--check'],source,'nonzero')
assert b'invalid potential workspace manifest' in (root/'nested-before-format.stderr.log').read_bytes()
fixed=['/*','!/*/','!/Cargo.toml',*outer_patterns[2:]]
run('outer-fixed-sparse',['git','sparse-checkout','set','--no-cone',*fixed],outer)
assert not (outer/'Cargo.toml').exists() and (source/'Cargo.toml').is_file()
run('nested-after-format',['cargo','fmt','--check'],source)
run('outer-status',['git','status','--porcelain','--untracked-files=all'],outer)
run('source-status',['git','status','--porcelain','--untracked-files=all'],source)
assert (root/'outer-status.stdout.log').read_bytes()==b'' and (root/'source-status.stdout.log').read_bytes()==b''
(root/'layout.json').write_text(json.dumps({'outerCommit':'f2c449e645bad996d34be3cb655807ad83611ffc','sourceCommit':'f781c3b7549a86b6aa8b5a34d2bbb32038c315b7','outerBeforePatterns':outer_patterns,'outerAfterPatterns':fixed,'sourceCargoManifestUnchanged':True,'beforeCargoFailed':True,'afterCargoPassed':True,'benchmarkExecuted':False,'runtimeIntegrated':False,'performanceAccepted':None},indent=2)+'\n')
tools=repo/'reports/implementation/range-combined-candidate/tools'
for label,argv in [('prepare',['python3','-B',tools/'prepare.py',outer,source,root/'proof']),('qualify',['python3','-B',tools/'qualify.py',outer,source,root/'proof',node])]:run(label,argv)
print(json.dumps({'nestedEntryPointPassed':True,'benchmarkExecuted':False,'performanceAccepted':None}))
