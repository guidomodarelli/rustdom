/** @file Executes the same Web API contracts in both actual Vitest VM worker pools. */
import './platform.vitest.mjs';
