/** @file Exercises the Web API bridge in actual Vitest test execution. */
import { test, expect } from 'vitest';
import { createRequire } from 'node:module';

/** Exercise FileReader's real platform brand check in normal and VM workers. */
const { readDomFile } = createRequire(import.meta.url)('./read-dom-file.cjs');

test('should submit DOM FormData through a native Request without changing filenames', async () => {
  const form = new FormData();
  form.append('name', 'rustdom');
  form.append('file', new Blob(['content'], { type: 'text/plain' }), 'content.txt');
  const request = new Request('http://localhost/upload', { method: 'POST', body: form });
  const received = await request.formData();
  expect(received).toBeInstanceOf(FormData);
  expect(received.get('file')).toBeInstanceOf(File);
  expect(received.get('file')).toBeInstanceOf(Blob);
  expect(received.get('name')).toBe('rustdom');
  expect(received.get('file').name).toBe('content.txt');
  expect(await readDomFile(globalThis, received.get('file'))).toEqual(Array.from(new TextEncoder().encode('content')));
});

test('should decode multipart and urlencoded forms in the worker realm through both body owners and their clones', async () => {
  const multipart = new FormData();
  multipart.append('tag', 'first');
  multipart.append('file', new File([new Uint8Array([0, 128, 255])], 'binary.dat', { type: 'application/octet-stream' }));
  multipart.append('tag', 'second');
  for (const body of [multipart, new URLSearchParams('tag=first&tag=second')]) {
    const request = new Request('http://localhost/upload', { method: 'POST', body });
    const response = new Response(body);
    for (const owner of [request.clone(), request, response.clone(), response]) {
      const received = await owner.formData();
      expect(received.constructor).toBe(FormData);
      expect(received.getAll('tag')).toEqual(['first', 'second']);
      if (received.has('file')) {
        const file = received.get('file');
        expect(file.constructor).toBe(File);
        expect(file.name).toBe('binary.dat');
        expect(file.type).toBe('application/octet-stream');
        expect(await readDomFile(globalThis, file)).toEqual([0, 128, 255]);
      }
      expect(owner.bodyUsed).toBe(true);
    }
  }
});

test('should remove a DOM listener when a native AbortController aborts', () => {
  const button = document.createElement('button');
  const controller = new AbortController();
  let clicks = 0;
  button.addEventListener('click', () => clicks++, { signal: controller.signal });
  button.click();
  controller.abort();
  button.click();
  expect(clicks).toBe(1);
});

test('should preserve DOM FileReader while accepting Blob responses and clones', async () => {
  const file = new File(['file body'], 'body.txt', { type: 'text/plain' });
  const reader = new FileReader();
  const loaded = new Promise((resolve, reject) => {
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error);
  });
  reader.readAsText(file);
  expect(await loaded).toBe('file body');
  const response = new Response(file);
  expect(await response.clone().text()).toBe('file body');
  expect(await response.text()).toBe('file body');
});

test('should retain body consumption and malformed multipart errors', async () => {
  const body = new FormData();
  body.append('field', 'value');
  const request = new Request('http://localhost', { method: 'POST', body });
  expect((await request.clone().formData()).get('field')).toBe('value');
  expect((await request.formData()).get('field')).toBe('value');
  await expect(request.formData()).rejects.toMatchObject({ name: 'TypeError' });
  const malformed = new Response('invalid', { headers: { 'content-type': 'multipart/form-data; boundary=example' } });
  await expect(malformed.formData()).rejects.toMatchObject({ name: 'TypeError' });
});
