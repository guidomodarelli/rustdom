import json,shutil,subprocess
from pathlib import Path
repo=Path.cwd();out=repo/'.cache/combined-prospective-core-final';out.mkdir();packet=repo/'reports/benchmarks/native-class-ownership/combined-process-study';shutil.copytree(packet,out/'tested-source',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
records=[]
for label,node in [('node22','/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node-22/bin/node'),('node24','/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node/bin/node')]:
 argv=['wsl','-d','Ubuntu-22.04','--cd','/','--','python3','-B','/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom/.cache/validate-combined-prospective-core-linux.py',node]
 with (out/(label+'.stdout.log')).open('xb') as stdout,(out/(label+'.stderr.log')).open('xb') as stderr:result=subprocess.run(argv,stdout=stdout,stderr=stderr)
 records.append({'node':label,'argv':argv,'exitCode':result.returncode});(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(records[-1]),flush=True);assert result.returncode==0
