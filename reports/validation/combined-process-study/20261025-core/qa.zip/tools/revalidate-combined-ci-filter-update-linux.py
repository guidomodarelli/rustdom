import json,shutil,subprocess
from pathlib import Path
original=Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom');source=Path('/home/guido/rustdom-validation/combined-process-contract-ci-20261025-attempt2/source');proof=source.parent/'proof'
for relative,label in [('.github/workflows/combined-process-study-contracts.yml','workflow'),('reports/benchmarks/native-class-ownership/combined-process-study/constants/ci-files.json','ci-files')]:
 target=source/relative;prior=proof/('before-path-filter-update-'+label);assert not prior.exists();shutil.copyfile(target,prior);shutil.copyfile(original/relative,target)
argv=['python3','-B',str(source/'reports/benchmarks/native-class-ownership/combined-process-study/tools/configure-checkout.py'),str(source)]
result=subprocess.run(argv,cwd=source,capture_output=True);(proof/'final-source-check.stdout.log').write_bytes(result.stdout);(proof/'final-source-check.stderr.log').write_bytes(result.stderr)
(proof/'final-source-check.command.json').write_text(json.dumps({'argv':argv,'exitCode':result.returncode,'change':'Only path triggers and their catalog digest changed after successful local workflow execution; test commands and modules are unchanged'},indent=2)+'\n',encoding='utf-8',newline='\n');assert result.returncode==0,result.stderr.decode();print(result.stdout.decode())
