import os,subprocess,sys
from pathlib import Path
packet=Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom/reports/benchmarks/native-class-ownership/combined-process-study')
env=dict(os.environ,RUSTDOM_COMBINED_PACKAGE_ROOT='/home/guido/rustdom-validation/combined-range-package-roundtrip-20261025/combined-range-packages')
result=subprocess.run([sys.argv[1],'--test',str(packet/'compare.spec.cjs'),str(packet/'preparation.spec.cjs')],env=env)
raise SystemExit(result.returncode)
