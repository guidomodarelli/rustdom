"""Exercise the exact sparse-checkout, fixed archive, official SDK and real tests in a native Linux Git checkout."""
import hashlib,json,os,re,shutil,subprocess,sys
from pathlib import Path
original=Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom');outer=Path('/home/guido/rustdom-validation/combined-process-contract-ci-20261025-attempt2');assert not outer.exists();outer.mkdir()
source=outer/'source';proof=outer/'proof';proof.mkdir();method='reports/benchmarks/native-class-ownership/combined-process-study'
subprocess.run(['git','init','-q',str(source)],check=True)
(source/'.git/objects/info/alternates').write_text('/mnt/c/Users/guido/ghq/projects/rustdom/.git/objects\n',encoding='utf-8')
for key,value in [('core.autocrlf','false'),('core.sparseCheckout','true'),('core.sparseCheckoutCone','false')]:subprocess.run(['git','-C',str(source),'config',key,value],check=True)
(source/'.git/info/sparse-checkout').write_text('/'+method+'/\n',encoding='utf-8')
subprocess.run(['git','-C',str(source),'checkout','--detach','135f9d62584dfc80d869baca2537e7003dae8b87'],check=True)
shutil.copytree(original/method,source/method,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
workflow='.github/workflows/combined-process-study-contracts.yml';(source/workflow).parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(original/workflow,source/workflow)
records=[]
def run(label,argv,environment=None):
 with (proof/(label+'.stdout.log')).open('xb') as stdout,(proof/(label+'.stderr.log')).open('xb') as stderr:result=subprocess.run(list(map(str,argv)),cwd=source,stdout=stdout,stderr=stderr,env=environment)
 records.append({'label':label,'argv':list(map(str,argv)),'exitCode':result.returncode});(proof/'commands.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(records[-1]),flush=True);assert result.returncode==0,label
run('configure',['python3','-B',source/method/'tools/configure-checkout.py',source])
run('extract',['python3','-B',source/'reports/benchmarks/native-class-ownership/range-combined-packages/extract.py',source,outer/'data'])
environment=dict(os.environ,RUSTDOM_COMBINED_PACKAGE_ROOT=str(outer/'data/combined-range-packages'))
for label,node,version in [('node22','/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node-22/bin/node','22.12.0'),('node24','/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node/bin/node','24.14.1')]:
 run(label+'-runtime',[node,source/method/'tools/runtime.cjs',version])
 run(label+'-tests',[node,'--test',source/method/'compare.spec.cjs',source/method/'preparation.spec.cjs'],environment)
(proof/'source-head.txt').write_bytes(subprocess.check_output(['git','rev-parse','HEAD'],cwd=source))
(proof/'source-status-raw.txt').write_bytes(subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=source))
(proof/'source-state.json').write_text(json.dumps({'sourceCommit':'135f9d62584dfc80d869baca2537e7003dae8b87','methodOverlay':'current uncommitted authored files; not claimed to be a clean published method checkout','runtimeExecuted':False,'samplerInvoked':False,'performanceAccepted':None},indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'commands':len(records),'allPassed':True,'samplerInvoked':False,'performanceAccepted':None}))
