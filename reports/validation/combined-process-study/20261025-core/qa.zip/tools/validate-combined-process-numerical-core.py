import hashlib,json,shutil,subprocess,sys
from pathlib import Path
repo=Path.cwd();phase=sys.argv[1];assert phase in ['pre-rounding-fix','final'];out=repo/('.cache/combined-process-numerical-contracts-'+phase);out.mkdir()
packet=repo/'reports/benchmarks/native-class-ownership/combined-process-study';shutil.copytree(packet,out/'tested-source',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
records=[]
for label,node in [('node22','/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node-22/bin/node'),('node24','/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node/bin/node')]:
 argv=['wsl','-d','Ubuntu-22.04','--cd','/','--',node,'--test','/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom/reports/benchmarks/native-class-ownership/combined-process-study/compare.spec.cjs']
 with (out/(label+'.stdout.log')).open('xb') as stdout,(out/(label+'.stderr.log')).open('xb') as stderr:result=subprocess.run(argv,stdout=stdout,stderr=stderr)
 records.append({'node':label,'argv':argv,'exitCode':result.returncode});(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(records[-1]),flush=True)
if phase=='final':assert all(record['exitCode']==0 for record in records)
