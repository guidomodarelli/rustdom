"""Compute one prospective critical value from the pinned numerical reference runtime; no DOM or measurement."""
import json,sys,datetime
from pathlib import Path
repo=Path.cwd();sys.path.insert(0,str(repo/'.cache/statistics-reference'))
import numpy,scipy
from scipy.stats import t
assert numpy.__version__=='2.2.6' and scipy.__version__=='1.15.3'
value=float(t.ppf(0.975,15))
index=json.loads((repo/'reports/benchmarks/native-class-ownership/range-collapse-study-results/40137458635/original-index.json').read_bytes())
elapsed=(datetime.datetime.fromisoformat(index['finishedAt'].replace('Z','+00:00'))-datetime.datetime.fromisoformat(index['startedAt'].replace('Z','+00:00'))).total_seconds()
result={'purpose':'prospective-method-preparation','confidenceLevel':0.95,'pairsPerComparison':16,'degreesOfFreedom':15,'twoSidedCriticalValue':value,'scipy':scipy.__version__,'numpy':numpy.__version__,'historicalCostObservation':{'run':40137458635,'processes':len(index['processes']),'wallSeconds':elapsed,'performanceAccepted':index['performanceAccepted'],'usedToReevaluateAcceptance':False},'domExecuted':False,'benchmarkExecuted':False,'performanceAccepted':None}
(repo/'.cache/combined-prospective-statistics.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(result))
