import json,subprocess,sys
from pathlib import Path
out=Path('.cache')/('combined-process-actionlint-'+sys.argv[1]);out.mkdir()
argv=['wsl','-d','Ubuntu-22.04','--cd','/','--','/mnt/c/Users/guido/ghq/projects/rustdom/.tools/actionlint/actionlint','/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom/.github/workflows/combined-process-study-contracts.yml']
result=subprocess.run(argv,capture_output=True);(out/'stdout.log').write_bytes(result.stdout);(out/'stderr.log').write_bytes(result.stderr);(out/'command.json').write_text(json.dumps({'argv':argv,'exitCode':result.returncode},indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps({'exitCode':result.returncode}));raise SystemExit(result.returncode)
