import json,os,subprocess,sys
from pathlib import Path
repo=Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom');out=repo/'.cache/combined-prospective-preparation-final';out.mkdir()
env=dict(os.environ,RUSTDOM_COMBINED_PACKAGE_ROOT='/home/guido/rustdom-validation/combined-range-package-roundtrip-20261025/combined-range-packages')
records=[]
for label,node in [('node22','/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node-22/bin/node'),('node24','/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node/bin/node')]:
 argv=[node,'--test',str(repo/'reports/benchmarks/native-class-ownership/combined-process-study/preparation.spec.cjs')]
 with (out/(label+'.stdout.log')).open('xb') as stdout,(out/(label+'.stderr.log')).open('xb') as stderr:result=subprocess.run(argv,stdout=stdout,stderr=stderr,env=env)
 records.append({'node':label,'argv':argv,'exitCode':result.returncode});(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(records[-1]),flush=True);assert result.returncode==0
