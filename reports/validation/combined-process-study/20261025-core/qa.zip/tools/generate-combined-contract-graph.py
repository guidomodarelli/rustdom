import json,subprocess
from pathlib import Path
repo=Path.cwd();output=repo/'reports/benchmarks/native-class-ownership/combined-process-study/constants/ci-files.json'
argv=['wsl','-d','Ubuntu-22.04','--cd','/','--','/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node-22/bin/node','/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom/reports/benchmarks/native-class-ownership/combined-process-study/tools/dependencies.cjs']
result=subprocess.run(argv,capture_output=True);(repo/'.cache/combined-contract-graph.stderr.log').write_bytes(result.stderr);assert result.returncode==0,result.stderr.decode(errors='replace');policy=json.loads(result.stdout);output.write_bytes(result.stdout);print(json.dumps({'files':len(policy['files']),'historicalPins':policy['historicalPins']}))
