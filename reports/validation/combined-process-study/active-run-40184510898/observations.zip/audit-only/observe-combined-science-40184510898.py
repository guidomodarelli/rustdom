"""Observe only this unique scientific run; preserve actual metadata and its independent pre-artifact binding. Never activates or repeats measurement."""
import datetime
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

if sys.flags.optimize:
    raise RuntimeError('Combined observation requires non-optimized Python')

repository = Path.cwd(); run_id = 40184510898
head = '95e64bd20711975b08864cf1bef1dee362b79663'
method_path = repository / 'reports/benchmarks/native-class-ownership/combined-process-study'
output = repository / '.cache/combined-process-run-40184510898'; output.mkdir(exist_ok=True)
history = output / 'observations'; history.mkdir(exist_ok=True)
stamp = datetime.datetime.now(datetime.timezone.utc)
def api(endpoint, filename):
    raw = subprocess.check_output(['gh', 'api', 'repos/guidomodarelli/rustdom/' + endpoint])
    (history / (stamp.strftime('%Y%m%dT%H%M%S%fZ') + '-' + filename)).write_bytes(raw)
    return json.loads(raw)

run = api(f'actions/runs/{run_id}', 'run.json')
jobs = api(f'actions/runs/{run_id}/attempts/1/jobs?per_page=100', 'jobs.json')
assert run['id'] == run_id and run['head_sha'] == head and run['run_attempt'] == 1
assert run['path'].split('@')[0] == '.github/workflows/ownership-combined-process-study.yml'
assert run['event'] == 'pull_request'
if not jobs['jobs']:
    print(json.dumps({'run': run_id, 'status': run['status'], 'jobRegistered': False, 'labelReapplied': False}))
    sys.exit(0)
assert len(jobs['jobs']) == 1; job = jobs['jobs'][0]
intent = json.loads((repository / '.cache/combined-process-trigger-95e64bd2/intent.json').read_bytes())
assert intent['head'] == head
binding = {'repository': 'guidomodarelli/rustdom', 'revision': 'ownership-combined-process-means-v1',
    'runId': run_id, 'jobId': job['id'], 'head': head, 'attempt': 1,
    'workflow': '.github/workflows/ownership-combined-process-study.yml',
    'artifactName': 'ownership-combined-process-means-' + head + '-attempt1',
    'artifactId': None, 'tarName': 'combined-process-study.tar.xz', 'rootName': 'combined-process-study',
    'publicationSha256': intent['publicationSha256'], 'methodFilesSha256': intent['methodFilesSha256']}
specification = importlib.util.spec_from_file_location('current_combined_transport', method_path / 'transport.py')
transport = importlib.util.module_from_spec(specification); specification.loader.exec_module(transport)
transport.current_binding(binding, repository)
transport.current_reader(repository, binding).authenticate_run(run, jobs)
binding_file = output / 'binding.activation.json'
if binding_file.exists():
    assert json.loads(binding_file.read_bytes()) == binding
else:
    with binding_file.open('x', encoding='utf-8', newline='\n') as destination:
        json.dump(binding, destination, indent=2); destination.write('\n')
status = {'runId': run_id, 'jobId': job['id'], 'head': head, 'attempt': 1,
    'status': run['status'], 'conclusion': run['conclusion'], 'jobStatus': job['status'], 'jobConclusion': job['conclusion'],
    'activeSteps': [step['name'] for step in job['steps'] if step['status'] == 'in_progress'],
    'completedSteps': [step['name'] for step in job['steps'] if step['status'] == 'completed'],
    'observedAtUTC': stamp.isoformat(), 'plannedProcesses': 2048, 'processesObserved': None,
    'labelAppliedOnce': True, 'measurementRepeated': False, 'performanceAccepted': None, 'gateReevaluated': False}
(output / 'latest.json').write_text(json.dumps(status, indent=2) + '\n', encoding='utf-8', newline='\n')
for state_file in [repository / '.cache/range-inventory-operational-state.json',
    Path('C:/Users/guido/ghq/projects/rustdom/.codex-autofix/watch-80.range-telemetry-enabled-d5ec4186.json')]:
    state = json.loads(state_file.read_bytes())
    method = state['combinedRangeCandidate']['prospectiveProcessMethod']['enabledCaptureMethod']
    assert method['publishedHead'] == head
    if method.get('activeExecution'):
        assert method['activeExecution']['runId'] == run_id and method['activeExecution']['jobId'] == job['id']
    method.update(newStudyActivated=True, newMeasurementProcesses=None, activeExecution=status,
        independentBinding=str(binding_file.relative_to(repository)).replace('\\', '/'))
    state['observedAtUTC'] = stamp.isoformat()
    state['nextAction'] = 'Observar únicamente run40184510898/job' + str(job['id']) + '/intento1/SHA95e64bd2. No reaplicar etiqueta, relanzar ni añadir muestras. Al terminar conservar ZIP/TAR/metadata/logs completos, autenticar artifact desde API y completar binding.results.json sin modificar binding.activation.json. Replay/decisión offline actual en ambos Node oficiales con Git Linux real95e64bd2; no ejecutar código archivado. Preservar rechazos,599pins,434fuentes,48ajenos yautorizaciones. Sin tag/merge sin aceptación. Método y paquete congelados.'
    state_file.write_text(json.dumps(state, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(status))
