"""Read prerequisites by default; --apply-once may apply the new method label exactly once after exact-source CI and published review. Never retries a scientific activation."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import urllib.parse

if sys.flags.optimize:
    raise RuntimeError('Combined activation requires non-optimized Python before any observation or mutation')

repository = Path.cwd()
head = '95e64bd20711975b08864cf1bef1dee362b79663'
ci_run_id = 40183945744
method_path = repository / 'reports/benchmarks/native-class-ownership/combined-process-study'
policy = json.loads((method_path / 'constants/protocol.json').read_bytes())
capture = json.loads((method_path / 'constants/capture.json').read_bytes())
output = repository / '.cache/combined-process-trigger-95e64bd2'
output.mkdir(exist_ok=True)
observations = output / 'observations'; observations.mkdir(exist_ok=True)
stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')

def api(endpoint, name):
    raw = subprocess.check_output(['gh', 'api', 'repos/guidomodarelli/rustdom/' + endpoint])
    (observations / (stamp + '-' + name)).write_bytes(raw)
    return json.loads(raw)

assert len(sys.argv) == 1 or sys.argv[1:] == ['--apply-once']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == head
assert not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=all'])
assert subprocess.check_output(['git', 'ls-remote', 'origin', 'refs/heads/feature/native-class-ownership'], text=True).split()[0] == head
published_review = json.loads((repository / '.cache/combined-activation-published-review-95e64bd2.json').read_bytes())
assert published_review['publishedHead'] == head and published_review['actionableFindings'] == 0
publication = repository / capture['publicationReceipt']; reviewed = json.loads(publication.read_bytes())
assert policy['executionReady'] is True and reviewed['executionReady'] is True and reviewed['completeMethodReview'] is True
assert reviewed['actionableFindings'] == 0 and len(reviewed['files']) == 724
assert reviewed['methodFilesSha256'] == '9f49b150cbeea0badc1c00b24ef3984cdaed93c0c3eb6657c15a630bd1cc7aab'
for name, expected in reviewed['files'].items():
    assert hashlib.sha256((repository / name).read_bytes()).hexdigest() == expected, name
run = api(f'actions/runs/{ci_run_id}', 'ci-run.json')
jobs = api(f'actions/runs/{ci_run_id}/attempts/1/jobs', 'ci-jobs.json')
assert run['head_sha'] == head and run['run_attempt'] == 1 and run['path'] == capture['contractWorkflow']
assert run['event'] == 'pull_request'
assert sorted(job['name'] for job in jobs['jobs']) == sorted(capture['requiredChecks'])
for job in jobs['jobs']:
    assert job['head_sha'] == head and job['run_id'] == ci_run_id and job['run_attempt'] == 1
ready = run['status'] == 'completed' and run['conclusion'] == 'success' and all(
    job['status'] == 'completed' and job['conclusion'] == 'success' for job in jobs['jobs'])
if not ready:
    print(json.dumps({'ready': False, 'CI': ci_run_id, 'status': run['status'], 'conclusion': run['conclusion'],
        'jobs': [{'id': job['id'], 'status': job['status'], 'conclusion': job['conclusion']} for job in jobs['jobs']], 'labelApplied': False}))
    sys.exit(0)
assert not (output / 'intent.json').exists(), 'Activation already requested: observe the same run; never apply again'
pull_request = api('pulls/80', 'pull-request.json')
assert pull_request['state'] == 'open' and pull_request['head']['sha'] == head
assert capture['label'] not in [label['name'] for label in pull_request['labels']], 'Label already present: find the existing run without reapplying'
# The workflow file first appeared in this immutable source history. Query a fixed creation window and every page,
# not the unregistered workflow-name endpoint, which returns 404 before its first event.
introduction = subprocess.check_output(['git', 'log', '--diff-filter=A', '--format=%H %cI', '--', capture['workflow']], text=True).strip()
assert introduction == '9b31d4cc3c85ba9e64d58ba1a92cf13caca89be6 2026-10-25T06:16:16-03:00'
start = '2026-10-25T09:16:16Z'
end = datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
recorded = []
page = 1
while True:
    query = urllib.parse.urlencode({'event': 'pull_request', 'created': start + '..' + end, 'per_page': 100, 'page': page})
    observed = api('actions/runs?' + query, f'prior-runs-page-{page}.json')
    assert observed['total_count'] < 1000, 'Split the read-only time window before drawing conclusions from capped API results'
    recorded.extend(observed['workflow_runs'])
    if len(observed['workflow_runs']) < 100:
        break
    page += 1
assert len(recorded) == observed['total_count'] and len({item['id'] for item in recorded}) == len(recorded)
prior = [item for item in recorded if item['path'].split('@')[0] == capture['workflow'] and item['conclusion'] != 'skipped']
assert not prior, 'A prior or active method run exists; preserve it without another label application'
if len(sys.argv) == 1:
    print(json.dumps({'ready': True, 'head': head, 'CI': ci_run_id, 'priorRuns': len(prior), 'labelApplied': False}))
    sys.exit(0)
labels = api('labels?per_page=100', 'repository-labels.json')
assert len(labels) < 100, 'Read all label pages before creating a definition'
if capture['label'] not in [label['name'] for label in labels]:
    result = subprocess.run(['gh', 'label', 'create', capture['label'], '--repo', 'guidomodarelli/rustdom', '--color', '5319e7',
        '--description', 'Una secuencia prospectiva con medias por proceso; conservar también rechazos y parciales'], capture_output=True)
    (output / 'label-definition.stdout.log').write_bytes(result.stdout)
    (output / 'label-definition.stderr.log').write_bytes(result.stderr)
    assert result.returncode == 0, result.stderr.decode(errors='replace')
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == head
assert not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=all'])
immediate = api('pulls/80', 'immediate-preapplication-pull-request.json')
assert immediate['state'] == 'open' and immediate['head']['sha'] == head
assert capture['label'] not in [label['name'] for label in immediate['labels']], 'Observe the existing application instead of applying again'
intent = {'head': head, 'methodFilesSha256': reviewed['methodFilesSha256'],
    'publicationSha256': hashlib.sha256(publication.read_bytes()).hexdigest(), 'CI': ci_run_id,
    'label': capture['label'], 'applicationRequestedAtUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'standingAuthorization': 'Autonomía y autorización permanente en AGENTS.md', 'measurementProcesses': policy['processes'],
    'captureTimeoutMinutes': policy['captureTimeoutMinutes'], 'jobTimeoutMinutes': policy['jobTimeoutMinutes'],
    'budgetsChanged': False, 'scientificSequenceRepeated': False, 'performanceAccepted': None}
with (output / 'intent.json').open('x', encoding='utf-8', newline='\n') as destination:
    json.dump(intent, destination, indent=2); destination.write('\n')
result = subprocess.run(['gh', 'pr', 'edit', '80', '--repo', 'guidomodarelli/rustdom', '--add-label', capture['label']], capture_output=True)
(output / 'application.stdout.log').write_bytes(result.stdout); (output / 'application.stderr.log').write_bytes(result.stderr)
receipt = {'requestExitCode': result.returncode, 'requestedOnce': True, 'repeatPermitted': False,
    'observedAtUTC': datetime.datetime.now(datetime.timezone.utc).isoformat()}
(output / 'application-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8', newline='\n')
assert result.returncode == 0, 'Inspect this same application/run: never apply the label again after an uncertain response'
print(json.dumps({'head': head, 'CI': ci_run_id, 'labelAppliedOnce': True, 'performanceAccepted': None}))
