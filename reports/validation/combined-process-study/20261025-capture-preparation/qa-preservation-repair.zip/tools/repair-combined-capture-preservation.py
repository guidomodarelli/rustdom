"""Repair Windows long-path transport omissions without changing original ZIPs or running any archived code."""
import hashlib
import json
from pathlib import Path
import zipfile

repo = Path.cwd()
native = Path(r'\\?\UNC\wsl.localhost\Ubuntu-22.04\home\guido\rustdom-validation')
final = native / 'combined-process-capture-ci-20261025-transport-budget-fix'
out = repo / 'reports/validation/combined-process-study/20261025-capture-preparation'
data = repo / 'reports/benchmarks/native-class-ownership/combined-capture-preparation/20261025'

def digest(filename):
    checksum = hashlib.sha256()
    with filename.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1048576), b''): checksum.update(chunk)
    return checksum.hexdigest()

def dump(filename, value):
    filename.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')

inventory = json.loads((final / 'preparation-inventory.json').read_bytes())
manifest_file = data / 'manifest.json'; original_manifest = manifest_file.read_bytes()
manifest = json.loads(original_manifest)
missing = set(inventory['files']) - set(manifest['files'])
expected_missing = {'method/reports/benchmarks/native-class-ownership/jsdom-telemetry-results/39959175058/tools/extract-current-ownership-result.py'}
assert missing == expected_missing and not (set(manifest['files']) - set(inventory['files']))
for name, identity in manifest['files'].items():
    assert identity['bytes'] == inventory['files'][name]['bytes'] and identity['sha256'] == inventory['files'][name]['sha256']
initial = out / 'preparation-manifest-initial.json'; assert not initial.exists(); initial.write_bytes(original_manifest)
archive = data / 'preparation-part-005.zip'; assert not archive.exists()
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as output:
    for name in sorted(missing):
        filename = final / 'preparation-proof' / name
        assert filename.is_file() and digest(filename) == inventory['files'][name]['sha256']
        output.write(filename, name)
with zipfile.ZipFile(archive) as source:
    assert source.testzip() is None
    for name in missing:
        raw = source.read(name); identity = inventory['files'][name]
        assert len(raw) == identity['bytes'] and hashlib.sha256(raw).hexdigest() == identity['sha256']
        manifest['files'][name] = {'archive': archive.name, **identity}
manifest['parts'].append({'path': archive.name, 'bytes': archive.stat().st_size, 'sha256': digest(archive), 'members': len(missing)})
manifest['preservationRepair'] = {'cause': 'Windows ordinary UNC long-path stat omitted one existing file; extended UNC reads all members',
    'initialMembers': len(json.loads(original_manifest)['files']), 'completeMembers': len(manifest['files']),
    'originalPartsUnchanged': True, 'missingMembersAdded': sorted(missing), 'samplerInvoked': False}
dump(manifest_file, manifest)
assert len(manifest['files']) == len(inventory['files'])
assert {name: {'bytes': identity['bytes'], 'sha256': identity['sha256']} for name, identity in manifest['files'].items()} == inventory['files']

entries = {}
def add_tree(prefix, directory):
    for filename in directory.rglob('*'):
        if filename.is_file() and '__pycache__' not in filename.parts and filename.suffix != '.pyc':
            entries[prefix + '/' + filename.relative_to(directory).as_posix()] = filename

method = 'reports/benchmarks/native-class-ownership/combined-process-study'
for label, dirname in [('initial-sdk-bound-failure', 'combined-process-capture-ci-20261025'),
                       ('binary-reader-fixed', 'combined-process-capture-ci-20261025-binary-fix'),
                       ('final-transport-budget-fixed', 'combined-process-capture-ci-20261025-transport-budget-fix')]:
    root = native / dirname
    add_tree(label + '/proof', root / 'proof'); add_tree(label + '/method', root / 'source' / method)
    for workflow in ['combined-process-study-contracts.yml', 'ownership-combined-process-study.yml']:
        entries[label + '/' + workflow] = root / 'source/.github/workflows' / workflow
    for node in ['node22', 'node24']:
        directory = root / (node + '-derived')
        if directory.exists(): add_tree(label + '/' + node + '-derived', directory)
add_tree('current-source/method', repo / method)
for workflow in ['combined-process-study-contracts.yml', 'ownership-combined-process-study.yml']:
    entries['current-source/' + workflow] = repo / '.github/workflows' / workflow
for name in ['make-combined-capture-ci-helper.py', 'reproduce-combined-capture-ci-linux.py',
             'reproduce-combined-capture-ci-binary-fix-linux.py', 'reproduce-combined-capture-ci-budget-fix-linux.py',
             'prepare-combined-capture-inputs.cjs', 'preserve-combined-capture.py']:
    entries['tools/' + name] = repo / '.cache' / name
for name in ['preflight.json', 'preparation-inventory.json', 'preparation-result.json']:
    entries['preparation/' + name] = final / name
with zipfile.ZipFile(out / 'qa.zip') as source:
    existing = set(source.namelist()); assert existing.issubset(entries)
    for name in existing: assert hashlib.sha256(source.read(name)).hexdigest() == digest(entries[name]), name
qa_missing = set(entries) - existing
repair_file = out / 'qa-preservation-repair.zip'; assert not repair_file.exists()
with zipfile.ZipFile(repair_file, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as output:
    for name in sorted(qa_missing): output.write(entries[name], name)
    output.write(Path(__file__), 'tools/repair-combined-capture-preservation.py')
with zipfile.ZipFile(repair_file) as source:
    assert source.testzip() is None
    repaired = {name: {'bytes': len(source.read(name)), 'sha256': hashlib.sha256(source.read(name)).hexdigest()} for name in source.namelist()}
dump(out / 'qa-preservation-repair.json', {'bytes': repair_file.stat().st_size, 'sha256': digest(repair_file),
    'originalQAUnchanged': True, 'missingOriginalMembers': sorted(qa_missing),
    'completeOriginalQAMembers': len(entries), 'files': repaired, 'archivedCodeExecuted': False, 'samplerInvoked': False})
summary_file = out / 'summary.json'; summary = json.loads(summary_file.read_bytes())
summary.update({'preparationMembers': len(manifest['files']), 'preparationParts': len(manifest['parts']),
    'initialIncompletePreparationMembers': len(json.loads(original_manifest)['files']),
    'preservationRepairCause': 'Windows long-path ordinary UNC enumeration omitted members; extended UNC and exact inventory coverage fixed transport',
    'qaRepairMembers': len(repaired), 'completeOriginalQAMembers': len(entries), 'sourceSnapshotMethodMembersVerified': 701})
dump(summary_file, summary)
assert sum(name.startswith('method/') for name in manifest['files']) == 701
with (out / 'README.md').open('a', encoding='utf-8', newline='\n') as stream:
    stream.write('''
La auditoría de preservación detectó una omisión por rutas largas UNC en Windows.
Los cuatro ZIP iniciales se conservaron intactos y el quinto agrega el único
miembro faltante. La cobertura final coincide exactamente con los1.162 archivos
del inventario Linux, incluidos701 de método. Se conserva el manifiesto inicial.
La QA también se cotejó con los árboles reales usando UNC extendido: los miembros
omitidos se agregaron en QA de reparación separada, sin modificar qa.zip original.
No se repitieron mediciones, preparación ni tests; solo lectura y transporte.
''')
print(json.dumps({'preparationMembers': len(manifest['files']), 'parts': len(manifest['parts']),
    'methodMembers': 701, 'originalQAMembers': len(existing), 'completeOriginalQAMembers': len(entries),
    'missingQAMembersAdded': len(qa_missing), 'originalArchivesUnchanged': True, 'newMeasurements': 0}))
