"""Reproduce the expanded contract workflow in a new real Git checkout without invoking DOM or the sampler."""
import json
import os
from pathlib import Path
import shutil
import subprocess

original = Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom')
outer = Path('/home/guido/rustdom-validation/combined-process-transport-ci-20261025-tar-recovery')
outer.mkdir(parents=True)
source = outer / 'source'; proof = outer / 'proof'; proof.mkdir()
method = 'reports/benchmarks/native-class-ownership/combined-process-study'
workflow = '.github/workflows/combined-process-study-contracts.yml'
subprocess.run(['git', 'init', '-q', str(source)], check=True)
(source / '.git/objects/info/alternates').write_text('/mnt/c/Users/guido/ghq/projects/rustdom/.git/objects\n', encoding='utf-8')
for key, value in [('core.autocrlf', 'false'), ('core.sparseCheckout', 'true'), ('core.sparseCheckoutCone', 'false')]:
    subprocess.run(['git', '-C', str(source), 'config', key, value], check=True)
(source / '.git/info/sparse-checkout').write_text('/' + method + '/\n', encoding='utf-8')
subprocess.run(['git', '-C', str(source), 'checkout', '--detach', '9b31d4cc3c85ba9e64d58ba1a92cf13caca89be6'], check=True)
shutil.copytree(original / method, source / method, dirs_exist_ok=True, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
(source / workflow).parent.mkdir(parents=True, exist_ok=True)
shutil.copyfile(original / workflow, source / workflow)
capture_workflow = '.github/workflows/ownership-combined-process-study.yml'
shutil.copyfile(original / capture_workflow, source / capture_workflow)
records = []

def run(label, argv, environment=None):
    with (proof / (label + '.stdout.log')).open('xb') as stdout, (proof / (label + '.stderr.log')).open('xb') as stderr:
        result = subprocess.run(list(map(str, argv)), cwd=source, env=environment, stdout=stdout, stderr=stderr)
    records.append({'label': label, 'argv': list(map(str, argv)), 'exitCode': result.returncode})
    (proof / 'commands.json').write_text(json.dumps(records, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(records[-1]), flush=True)
    assert result.returncode == 0, label

run('configure', ['python3', '-B', source / method / 'tools/configure-checkout.py', source])
run('extract', ['python3', '-B', source / 'reports/benchmarks/native-class-ownership/range-combined-packages/extract.py', source, outer / 'data'])
for label, node, version in [('node22', '/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node-22/bin/node', '22.12.0'), ('node24', '/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node/bin/node', '24.14.1')]:
    manifest = proof / (label + '-source-manifest.json')
    derived = outer / (label + '-derived')
    environment = dict(os.environ, RUSTDOM_COMBINED_PACKAGE_ROOT=str(outer / 'data/combined-range-packages'), RUSTDOM_COMBINED_DERIVED_ROOT=str(derived))
    run(label + '-runtime', [node, source / method / 'tools/runtime.cjs', version])
    run(label + '-source', [node, source / method / 'source.cjs', manifest])
    run(label + '-derive', ['python3', '-B', source / method / 'derive.py', source, manifest, derived])
    run(label + '-transport', ['python3', '-B', source / method / 'transport.spec.py'], environment)
    run(label + '-tests', [node, '--test', *[source / method / name for name in ['compare.spec.cjs', 'preparation.spec.cjs', 'worker.spec.cjs', 'results.spec.cjs', 'portable.spec.cjs', 'study.spec.cjs']]], environment)
run('actionlint', ['/mnt/c/Users/guido/ghq/projects/rustdom/.tools/actionlint/actionlint', '-ignore', 'SC.*', source / workflow, source / capture_workflow])
(proof / 'source-status-raw.txt').write_bytes(subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=all'], cwd=source))
(proof / 'source-state.json').write_text(json.dumps({'sourceCommit': '9b31d4cc3c85ba9e64d58ba1a92cf13caca89be6', 'methodOverlay': 'Actual uncommitted authored method; not declared clean', 'measurementProcesses': 0, 'invalidManifestWorkerPerNode': 1, 'DOMLoaded': False, 'performanceAccepted': None}, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'commands': len(records), 'allPassed': True, 'measurementProcesses': 0}), flush=True)
