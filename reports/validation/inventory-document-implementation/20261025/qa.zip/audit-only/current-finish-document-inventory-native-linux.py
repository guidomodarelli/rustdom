"""Add the actually invoked tracked memory helper, preserve the prior missing-file failure and complete only pending validation."""
import json
from pathlib import Path
import subprocess

base = Path('/home/guido/rustdom-validation')
source = base / 'document-inventory-source-fc99401e-complete'
working = base / 'document-implementation-inventory-20261025-native-complete'
receipt = json.loads((working / 'node22/receipt.json').read_bytes())
assert receipt['commands'][0]['exitCode'] == 0 and receipt['commands'][1]['exitCode'] == 0
assert receipt['commands'][2]['exitCode'] == 1 and receipt['commands'][3]['exitCode'] == 0
subprocess.run(['git', '-C', str(source), 'sparse-checkout', 'add', '--no-cone', '/tests/helpers/inventory-memory.cjs'], check=True)
node = '/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node-22/bin/node'
arguments = [node, '--test', str(source / 'tests/validation/migration-inventory.spec.mjs')]
with (working / 'node22/canonical-fixed.stdout.log').open('xb') as stdout, (working / 'node22/canonical-fixed.stderr.log').open('xb') as stderr:
    result = subprocess.run(arguments, cwd=source, stdout=stdout, stderr=stderr)
fixed = {'argv': arguments, 'exitCode': result.returncode, 'sourceCodeAndAssertionsUnchanged': True,
    'fix': 'Materialize the existing tests/helpers/inventory-memory.cjs actually invoked by the canonical test'}
(working / 'node22/canonical-fixed.json').write_text(json.dumps(fixed, indent=2) + '\n')
print(json.dumps({'node': 'v22.12.0', 'canonicalAfterSetupFix': result.returncode}), flush=True)
assert result.returncode == 0
helper = (base / 'qualify-document-implementation-inventory-native-complete-linux.py').read_text()
helper = helper.replace("working.mkdir()", "working.mkdir(exist_ok=True)")
marker = "('node24', 'node', 'v24.14.1')]:\n"
assert marker in helper
helper = helper.replace(marker, marker + "    if profile != 'node24': continue\n")
destination = base / 'qualify-document-implementation-inventory-node24-linux.py'; assert not destination.exists()
destination.write_text(helper)
subprocess.run(['python3', '-B', str(destination)], check=True)
