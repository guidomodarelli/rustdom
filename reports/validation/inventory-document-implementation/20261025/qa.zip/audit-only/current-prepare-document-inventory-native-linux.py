"""Move only the current inventory harness to real Linux Git/filesystem, preserving source identities and immutable prepared product packages."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

original = Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom')
source = Path('/home/guido/rustdom-validation/document-inventory-source-fc99401e-complete')
head = 'fc99401e790d517f7a1f1abec43f0c42c2d2b716'
assert not source.exists()
subprocess.run(['git', 'init', '-q', str(source)], check=True)
(source / '.git/objects/info/alternates').write_text('/mnt/c/Users/guido/ghq/projects/rustdom/.git/objects\n')
for key, value in [('core.autocrlf', 'false'), ('core.sparseCheckout', 'true'), ('core.sparseCheckoutCone', 'false')]:
    subprocess.run(['git', '-C', str(source), 'config', key, value], check=True)
audits = json.loads((original / 'reports/progress/inventory/document-implementation-audit-20261025/merged-audits.json').read_bytes())
paths = {'package.json', 'scripts/migration-inventory.cjs', 'scripts/migration-inventory/', 'scripts/constants/migration-inventory.cjs',
    'tests/validation/migration-inventory.spec.mjs', 'tests/helpers/migration-inventory-memory.cjs', 'reports/progress/inventory/',
    'reports/validation/range-combined-packages/baselines/20261025/qa.json',
    'reports/benchmarks/native-class-ownership/constants/current-ownership.json',
    'tests/helpers/document-implementation-memory.cjs', 'scripts/memory-endpoint.cjs',
    'tests/fixtures/wpt/dom/nodes/DOMImplementation-createDocument-with-null-browsing-context-crash.html',
    'tests/fixtures/wpt/dom/nodes/DOMImplementation-createHTMLDocument-with-null-browsing-context-crash.html'}
for audit in audits.values():
    for field in ['rustSources', 'javascriptSources', 'tests', 'evidence']:
        paths.update(audit[field])
(source / '.git/info/sparse-checkout').write_text(''.join('/' + name + '\n' for name in sorted(paths)))
subprocess.run(['git', '-C', str(source), 'checkout', '--detach', head], check=True)
for root in ['reports/progress/inventory/document-implementation-audit-20261025', 'reports/validation/inventory-document-implementation/20261025']:
    for filename in (original / root).rglob('*'):
        if filename.is_file():
            destination = source / filename.relative_to(original); destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(filename, destination)
            assert hashlib.sha256(destination.read_bytes()).digest() == hashlib.sha256(filename.read_bytes()).digest()
prepared = Path('/home/guido/rustdom-validation/combined-process-activation-ci-20261025-reviewed/data/combined-range-packages/controls')
modules = source / 'node_modules'; modules.mkdir()
for entry in (prepared / 'node_modules').iterdir():
    os.symlink(entry, modules / entry.name, target_is_directory=entry.is_dir())
typescript = original / 'node_modules/typescript'; assert typescript.is_dir()
shutil.copytree(typescript, modules / 'typescript')
typescript_files = {}
for filename in typescript.rglob('*'):
    if filename.is_file():
        relative = filename.relative_to(typescript); expected = hashlib.sha256(filename.read_bytes()).hexdigest()
        assert hashlib.sha256((modules / 'typescript' / relative).read_bytes()).hexdigest() == expected
        typescript_files[relative.as_posix()] = expected
helper = (original / '.cache/qualify-document-implementation-inventory-linux.py').read_text()
helper = helper.replace("client = Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom')", 'client = Path(' + repr(str(source)) + ')')
helper = helper.replace("document-implementation-inventory-20261025');", "document-implementation-inventory-20261025-native-complete');")
helper = helper.replace("'sourceHead': mapping['sourceHead'],", "'sourceHead': mapping['sourceHead'], 'sourceChangesRaw': subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=all'], cwd=client).decode(),")
destination = source.parent / 'qualify-document-implementation-inventory-native-complete-linux.py'; assert not destination.exists()
destination.write_text(helper)
receipt = {'head': head, 'realGitDirectory': (source / '.git').is_dir(),
    'sourceChangesRaw': subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=all'], cwd=source).decode(),
    'typescriptVersion': json.loads((typescript / 'package.json').read_bytes())['version'], 'typescriptFiles': typescript_files,
    'scientificSourceChanged': False, 'preparedPackageChanged': False, 'runtimeRebuilt': False}
(source.parent / 'document-inventory-native-complete-source.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({key: value for key, value in receipt.items() if key not in ['typescriptFiles', 'sourceChangesRaw']}), flush=True)
subprocess.run(['python3', '-B', str(destination)], check=True)
