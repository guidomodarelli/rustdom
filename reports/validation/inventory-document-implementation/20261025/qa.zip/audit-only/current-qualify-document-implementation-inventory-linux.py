"""Exercise the unchanged, independently pinned A0 product with current tests and inventory code; never alter or repeat scientific capture."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

if sys.flags.optimize:
    raise RuntimeError('Inventory qualification requires non-optimized Python')
client = Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom')
prepared = Path('/home/guido/rustdom-validation/combined-process-activation-ci-20261025-reviewed/data/combined-range-packages/controls')
working = Path('/home/guido/rustdom-validation/document-implementation-inventory-20261025'); working.mkdir()
index_bytes = (prepared / 'baseline-index.json').read_bytes()
published = json.loads((client / 'reports/validation/range-combined-packages/baselines/20261025/qa.json').read_bytes())['files']['prepared/baseline-index.json']
assert len(index_bytes) == published['bytes'] and hashlib.sha256(index_bytes).hexdigest() == published['sha256']
index = json.loads(index_bytes)
for directory, files in [(prepared / 'packages/A0', index['distributions']['A0']['files']), (prepared, index['dependencies']['files'])]:
    for item in files:
        filename = directory / item['path']; assert filename.resolve().is_relative_to(prepared.resolve())
        raw = filename.read_bytes()
        assert len(raw) == item['bytes'] and hashlib.sha256(raw).hexdigest() == item['sha256'], item['path']
mapping = json.loads((client / 'reports/progress/inventory/document-implementation-audit-20261025/source-map.json').read_bytes())
for name, checksum in mapping['mappedLocalSources'].items():
    assert hashlib.sha256((client / name).read_bytes()).hexdigest() == checksum
    assert hashlib.sha256((prepared / 'baseline-sources' / name).read_bytes()).hexdigest() == checksum
reference = prepared / 'node_modules/jsdom'
assert json.loads((reference / 'package.json').read_bytes())['version'] == '27.4.0'
runtime = prepared / 'packages/A0/dist'
executables = json.loads((client / 'reports/benchmarks/native-class-ownership/constants/current-ownership.json').read_bytes())['runtimeExecutableHashes']
for profile, relative, version in [('node22', 'node-22', 'v22.12.0'), ('node24', 'node', 'v24.14.1')]:
    output = working / profile; output.mkdir()
    node = Path('/mnt/c/Users/guido/ghq/projects/rustdom/.tools') / relative / 'bin/node'
    assert subprocess.check_output([node, '--version'], text=True).strip() == version
    assert hashlib.sha256(node.read_bytes()).hexdigest() == executables[version]
    shadow = output / 'runtime'; (shadow / 'tests/helpers').mkdir(parents=True); (shadow / 'scripts').mkdir()
    os.symlink(runtime, shadow / 'dist', target_is_directory=True)
    os.symlink(prepared / 'node_modules', shadow / 'node_modules', target_is_directory=True)
    copied = {}
    files = list(client.glob('tests/document-implementation*.spec.cjs')) + [client / 'tests/helpers/document-implementation-memory.cjs', client / 'scripts/memory-endpoint.cjs',
        client / 'tests/fixtures/wpt/dom/nodes/DOMImplementation-createDocument-with-null-browsing-context-crash.html',
        client / 'tests/fixtures/wpt/dom/nodes/DOMImplementation-createHTMLDocument-with-null-browsing-context-crash.html']
    for filename in files:
        local = filename.relative_to(client); destination = shadow / local; destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(filename, destination); copied[local.as_posix()] = hashlib.sha256(filename.read_bytes()).hexdigest()
    public = client / 'reports/validation/inventory-document-implementation/20261025/tools/public-contracts.spec.cjs'
    copied[public.relative_to(client).as_posix()] = hashlib.sha256(public.read_bytes()).hexdigest()
    environment = dict(os.environ, RUSTDOM_DOCUMENT_INVENTORY_RUNTIME=str(runtime / 'index.cjs'),
        RUSTDOM_DOCUMENT_INVENTORY_NATIVE=str(runtime / 'native.cjs'), RUSTDOM_DOCUMENT_INVENTORY_REFERENCE=str(reference))
    commands = [('document-contracts', [node, '--expose-gc', '--test', '--test-concurrency=1', *sorted((shadow / 'tests').glob('document-implementation*.spec.cjs')), public], shadow),
        ('document-resources', [node, '--expose-gc', shadow / 'tests/helpers/document-implementation-memory.cjs'], shadow),
        ('canonical-inventory-contracts', [node, '--test', client / 'tests/validation/migration-inventory.spec.mjs'], client),
        ('proposal-cli', [node, client / 'scripts/migration-inventory.cjs', '--reference', reference, '--audits',
            client / 'reports/progress/inventory/document-implementation-audit-20261025/merged-audits.json', '--output', output / 'catalog'], client)]
    receipt = {'node': version, 'nodeSha256': executables[version], 'sourceHead': mapping['sourceHead'],
        'runtimeLabel': 'A0 baseline with byte-identical DOMImplementation sources; not the current ownership/Range candidate',
        'baselineIndexSha256': published['sha256'], 'nativeBinarySha256': hashlib.sha256((runtime / 'rustdom.node').read_bytes()).hexdigest(),
        'distributionFilesAuthenticated': len(index['distributions']['A0']['files']), 'dependencyFilesAuthenticated': len(index['dependencies']['files']),
        'mappedLocalAndBaselineSources': mapping['mappedLocalSources'], 'currentTestFiles': copied,
        'scientificCaptureModified': False, 'scientificMeasurementProcesses': 0, 'benchmarkExecuted': False,
        'rustRebuilt': False, 'installExecuted': False, 'commands': []}
    for name, arguments, cwd in commands:
        with (output / (name + '.stdout.log')).open('xb') as stdout, (output / (name + '.stderr.log')).open('xb') as stderr:
            result = subprocess.run(list(map(str, arguments)), cwd=cwd, env=environment, stdout=stdout, stderr=stderr)
        receipt['commands'].append({'name': name, 'argv': list(map(str, arguments)), 'exitCode': result.returncode})
        (output / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
        print(json.dumps({'node': version, 'command': name, 'exitCode': result.returncode}), flush=True)
    assert all(command['exitCode'] == 0 for command in receipt['commands']), profile
