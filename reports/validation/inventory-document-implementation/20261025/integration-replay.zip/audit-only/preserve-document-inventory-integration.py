"""Retain the actual integrated-ledger replay, its previous input bytes and every SDK output."""
import hashlib
import json
from pathlib import Path
import zipfile

repository = Path.cwd()
source = Path(r'\\?\UNC\wsl.localhost\Rustdom-Validation-20261025\home\guido\rustdom-validation\document-inventory-integration-20261025')
receipt = json.loads((source / 'receipt.json').read_bytes())
assert len(receipt['commands']) == 4 and all(command['exitCode'] == 0 for command in receipt['commands'])
assert receipt['canonicalOutputsReproduced'] and receipt['newScientificMeasurementProcesses'] == 0
for name, checksum in receipt['inputs'].items():
    assert hashlib.sha256((repository / name).read_bytes()).hexdigest() == checksum
destination = repository / 'reports/validation/inventory-document-implementation/20261025'
archive = destination / 'integration-replay.zip'; members = []
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as output:
    for filename in sorted(source.rglob('*')):
        if filename.is_file():
            raw = filename.read_bytes(); name = filename.relative_to(source).as_posix()
            output.writestr(name, raw); members.append({'name': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
    for filename in sorted((repository / '.cache').glob('*document*inventory*.py')):
        raw = filename.read_bytes(); name = 'audit-only/' + filename.name
        output.writestr(name, raw); members.append({'name': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
with zipfile.ZipFile(archive) as output:
    assert output.testzip() is None and len(output.infolist()) == len(members)
    for member in members:
        assert hashlib.sha256(output.read(member['name'])).hexdigest() == member['sha256']
report = {**receipt, 'QA': {'bytes': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'members': members}}
(destination / 'integration-replay.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'SDKCommands': len(receipt['commands']), 'members': len(members), 'bytes': archive.stat().st_size, 'canonicalReproduced': True}))
