"""Preserve successful and interrupted inventory qualification, without executing any archived implementation."""
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

repository = Path.cwd()
base = Path(r'\\?\UNC\wsl.localhost\Rustdom-Validation-20261025\home\guido\rustdom-validation')
assert base.is_dir()
working = base / 'document-implementation-inventory-20261025-native-complete'
destination = repository / 'reports/validation/inventory-document-implementation/20261025'
results = []
for profile in ['node22', 'node24']:
    receipt = json.loads((working / profile / 'receipt.json').read_bytes())
    assert receipt['commands'][0]['exitCode'] == 0 and receipt['commands'][1]['exitCode'] == 0 and receipt['commands'][3]['exitCode'] == 0
    if profile == 'node22':
        assert receipt['commands'][2]['exitCode'] == 1
        fixed = json.loads((working / profile / 'canonical-fixed.json').read_bytes()); assert fixed['exitCode'] == 0
        canonical = (working / profile / 'canonical-fixed.stdout.log').read_text(encoding='utf-8')
    else:
        assert receipt['commands'][2]['exitCode'] == 0
        canonical = (working / profile / 'canonical-inventory-contracts.stdout.log').read_text(encoding='utf-8')
    assert ('# tests 7' in canonical and '# pass 7' in canonical) or ('ℹ tests 7' in canonical and 'ℹ pass 7' in canonical)
    contracts = (working / profile / 'document-contracts.stdout.log').read_text(encoding='utf-8')
    assert ('# tests 164' in contracts and '# pass 164' in contracts) or ('ℹ tests 164' in contracts and 'ℹ pass 164' in contracts)
    memory_files = list((working / profile / 'runtime/reports/memory').glob('*-document-implementation.json')); assert len(memory_files) == 1
    memory = json.loads(memory_files[0].read_bytes()); assert memory['pass'] is True and len(memory['cycles']) == 12
    assert all(cycle['released']['reached'] for cycle in memory['cycles'])
    summary = json.loads((working / profile / 'catalog/summary.json').read_bytes())
    assert summary['counts']['files']['audited'] == 7 and summary['counts']['apis']['audited'] == 37
    assert summary['counts']['callableUnits']['audited'] == 6 and summary['counts']['callableUnits']['states']['rust-complete'] == 2
    results.append({'node': receipt['node'], 'nodeSha256': receipt['nodeSha256'], 'documentContracts': 164, 'inventoryContracts': 7,
        'memoryCycles': 12, 'memoryPass': True, 'counts': summary['counts'], 'nativeBinarySha256': receipt['nativeBinarySha256'],
        'baselineIndexSha256': receipt['baselineIndexSha256'], 'sourceChangesRaw': receipt['sourceChangesRaw']})
assert results[0]['counts'] == results[1]['counts']
archive = destination / 'qa.zip'; assert not archive.exists()
members = []
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as output:
    for root_name in ['document-implementation-inventory-20261025', 'document-implementation-inventory-20261025-native-complete']:
        root = base / root_name
        for filename in sorted(root.rglob('*')):
            if not filename.is_file() or filename.is_symlink() or filename.suffix == '.pyc' or '__pycache__' in filename.parts:
                continue
            relative = filename.relative_to(root)
            if 'node_modules' in relative.parts or 'dist' in relative.parts:
                continue
            raw = filename.read_bytes(); name = root_name + '/' + relative.as_posix()
            output.writestr(name, raw); members.append({'name': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
    for root_name in ['document-inventory-source-fc99401e', 'document-inventory-source-fc99401e-complete']:
        root = base / root_name
        for relative in ['reports/validation/inventory-document-implementation/20261025/tools/public-contracts.spec.cjs',
            'reports/progress/inventory/audits.json']:
            raw = (root / relative).read_bytes(); name = root_name + '/' + relative
            output.writestr(name, raw); members.append({'name': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
    for filename in [*base.glob('document-inventory-native*-source.json'), *base.glob('qualify-document-implementation-inventory*-linux.py'),
        *repository.glob('.cache/*document*inventory*-linux.py')]:
        raw = filename.read_bytes(); name = 'audit-only/' + ('linux-' if filename.parent == base else 'current-') + filename.name
        output.writestr(name, raw); members.append({'name': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
with zipfile.ZipFile(archive) as output:
    assert output.testzip() is None and len(output.infolist()) == len(members)
    assert len({member['name'] for member in members}) == len(members)
    for member in members:
        assert hashlib.sha256(output.read(member['name'])).hexdigest() == member['sha256']
(destination / '.gitattributes').write_bytes(b'* -text\n')
summary = {'sourceHead': 'fc99401e790d517f7a1f1abec43f0c42c2d2b716', 'results': results,
    'qualificationSource': 'A0 product package with four byte-identical current DOMImplementation sources',
    'currentCandidateQualifiedByThisAudit': False, 'scientificMeasurementProcesses': 0, 'benchmarkExecuted': False,
    'performanceAccepted': None, 'gateReevaluated': False, 'scopeClosed': False, 'migrationPercent': None,
    'attemptsPreserved': ['Windows-mounted scan interrupted after slow I/O', 'Initial Linux sparse setup missing QA metadata',
        'Linux canonical 6/7 due to missing existing inventory-memory helper', 'Linux canonical corrected 7/7, assertions unchanged'],
    'QA': {'bytes': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'members': members}}
(destination / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8', newline='\n')
memory_destination = repository / 'reports/memory/inventory-document-implementation/20261025'; memory_destination.mkdir(parents=True)
for profile in ['node22', 'node24']:
    filename = next((working / profile / 'runtime/reports/memory').glob('*-document-implementation.json'))
    shutil.copyfile(filename, memory_destination / (profile + '.json'))
(memory_destination / '.gitattributes').write_bytes(b'* -text\n')
print(json.dumps({'QA_members': len(members), 'QA_bytes': archive.stat().st_size,
    'SDKs': [{key: result[key] for key in ['node', 'documentContracts', 'inventoryContracts', 'memoryCycles']} for result in results]}))
