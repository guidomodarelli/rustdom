"""Exercise the real integrated ledger and unchanged canonical generator in both SDKs; never change a product package or scientific run."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

original = Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom')
source = Path('/home/guido/rustdom-validation/document-inventory-source-fc99401e-complete')
output = Path('/home/guido/rustdom-validation/document-inventory-integration-20261025'); output.mkdir()
inputs = {}
for name in ['reports/progress/inventory/audits.json', 'reports/progress/inventory/classification.json',
    'reports/progress/inventory/summary.json', 'tests/validation/migration-inventory.spec.mjs']:
    previous = output / 'previous-source' / name; previous.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source / name, previous)
    shutil.copyfile(original / name, source / name)
    inputs[name] = hashlib.sha256((source / name).read_bytes()).hexdigest()
results = []
for profile, relative in [('node22', 'node-22'), ('node24', 'node')]:
    node = Path('/mnt/c/Users/guido/ghq/projects/rustdom/.tools') / relative / 'bin/node'
    directory = output / profile; directory.mkdir()
    commands = [('contracts', [node, '--test', source / 'tests/validation/migration-inventory.spec.mjs']),
        ('canonical-cli', [node, source / 'scripts/migration-inventory.cjs', '--output', directory / 'catalog'])]
    for name, arguments in commands:
        with (directory / (name + '.stdout.log')).open('xb') as stdout, (directory / (name + '.stderr.log')).open('xb') as stderr:
            result = subprocess.run(list(map(str, arguments)), cwd=source, stdout=stdout, stderr=stderr)
        results.append({'profile': profile, 'name': name, 'argv': list(map(str, arguments)), 'exitCode': result.returncode})
        (output / 'commands.json').write_text(json.dumps(results, indent=2) + '\n')
        print(json.dumps({'profile': profile, 'name': name, 'exitCode': result.returncode}), flush=True)
        assert result.returncode == 0
    for name in ['reference.json', 'classification.json', 'summary.json', 'implementation-units.json']:
        assert (directory / 'catalog' / name).read_bytes() == (original / 'reports/progress/inventory' / name).read_bytes(), name
    if profile == 'node24':
        assert (directory / 'catalog/surface.json').read_bytes() == (original / 'reports/progress/inventory/surface.json').read_bytes()
receipt = {'commands': results, 'sourceHead': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip(),
    'sourceChangesRaw': subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=all'], cwd=source).decode(),
    'inputs': inputs, 'canonicalOutputsReproduced': True, 'scopeClosed': False, 'migrationPercent': None,
    'newScientificMeasurementProcesses': 0, 'runtimeRebuilt': False, 'productPackagesModified': False}
(output / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({key: value for key, value in receipt.items() if key not in ['commands', 'sourceChangesRaw', 'inputs']}))
