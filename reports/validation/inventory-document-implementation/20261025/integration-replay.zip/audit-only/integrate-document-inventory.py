"""Integrate the tested classifications while preserving denominators, frozen sources and prior authored entries."""
import hashlib
import json
from pathlib import Path

repository = Path.cwd(); ledger = repository / 'reports/progress/inventory'
proposal = ledger / 'document-implementation-audit-20261025'
mapping = json.loads((proposal / 'source-map.json').read_bytes())
audits = ledger / 'audits.json'; before = audits.read_bytes()
assert hashlib.sha256(before).hexdigest() == mapping['baseAuditsSha256']
old = json.loads(before); merged_bytes = (proposal / 'merged-audits.json').read_bytes(); merged = json.loads(merged_bytes)
assert all(merged[name] == record for name, record in old.items()) and len(merged) - len(old) == 11
native = Path(r'\\?\UNC\wsl.localhost\Rustdom-Validation-20261025\home\guido\rustdom-validation\document-implementation-inventory-20261025-native-complete\node24\catalog')
for name in ['reference.json', 'surface.json', 'implementation-units.json']:
    assert (native / name).read_bytes() == (ledger / name).read_bytes(), name
changed = {}
for name in ['classification.json', 'summary.json']:
    source = (native / name).read_bytes()
    changed[name] = {'beforeSha256': hashlib.sha256((ledger / name).read_bytes()).hexdigest(), 'afterSha256': hashlib.sha256(source).hexdigest()}
    (ledger / name).write_bytes(source)
audits.write_bytes(merged_bytes)
receipt = {'baseAuditsSha256': mapping['baseAuditsSha256'], 'integratedAuditsSha256': hashlib.sha256(merged_bytes).hexdigest(),
    'priorEntriesPreserved': len(old), 'newEntries': 11, 'denominatorsUnchanged': {'files': 531, 'apis': 4331, 'callableUnits': 7246},
    'regeneratedFrom': 'Node 24.14.1 real proposal CLI output, after both SDK qualifications', 'changedFiles': changed,
    'referenceSurfaceAndAnchorsByteIdentical': True, 'scopeClosed': False, 'migrationPercent': None,
    'runtimeModified': False, 'scientificCaptureModified': False}
(repository / 'reports/validation/inventory-document-implementation/20261025/integration.json').write_text(
    json.dumps(receipt, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(receipt))
