"""Exercise the current sequential coordinator on existing immutable data, including a deliberate inspection rejection."""
import argparse
from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys

if sys.flags.optimize or sys.platform != 'linux':
    raise RuntimeError('Coordinator qualification requires non-optimized Linux Python')
SOURCE = Path('/dev/shm/rustdom-pilot-v2-published-525e2be6')
REPOSITORY = Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom')
TOOL = Path('/mnt/c/Users/guido/.codex/worktrees/pilot-v2-ci-evidence/rustdom/tools/evidence-transport')
PRIMARY = Path('/mnt/c/Users/guido/ghq/projects/rustdom')
DESCRIPTOR = REPOSITORY/'.cache/coordinator-descriptor-v2.json'
DESCRIPTOR_SHA = 'd959313bec728fa1420846f4e7a1aa9179597f5724a7a40de99ca59468e9ea23'
COLLECTION = Path('/run/rustdom-scientific-collection-v2-20261026')
COLLECTION_SHA = '2c2d78b9921923b0363673d2c7ef67055cbd9914fd96fc9a82920390b1fb2f34'
DATA_RUN = 40366685759
DATA_HEAD = '1078e4fd190276a116e6dc5e64c9fe32eca3e7e9'
NAMESPACE = 'reports/validation/jsdom-block-pilot-v2/coordinator-qualification/20261026'


@contextmanager
def credentials(root):
    """Existing local credential in memory/environment only; all long-lived clients are native Linux."""
    config = root/'private-config'
    config.mkdir(mode=0o700)
    names = ['GH_TOKEN','GITHUB_TOKEN','GH_ENTERPRISE_TOKEN','GITHUB_ENTERPRISE_TOKEN','GH_HOST','GH_CONFIG_DIR',
        'GH_NO_UPDATE_NOTIFIER','GH_PROMPT_DISABLED','GIT_TERMINAL_PROMPT']
    previous = {name:os.environ.get(name) for name in names}
    token = subprocess.check_output(['/mnt/c/Program Files/GitHub CLI/gh.exe','auth','token','--hostname','github.com'],
        stderr=subprocess.PIPE,timeout=30).strip()
    if not token or any(part in token for part in [b'\r',b'\n',b'\x00']):
        raise ValueError('Existing credential lookup returned no single opaque token')
    try:
        for name in ['GITHUB_TOKEN','GH_ENTERPRISE_TOKEN','GITHUB_ENTERPRISE_TOKEN']:
            os.environ.pop(name,None)
        os.environ.update(GH_TOKEN=token.decode('ascii'),GH_HOST='github.com',GH_CONFIG_DIR=str(config),
            GH_NO_UPDATE_NOTIFIER='1',GH_PROMPT_DISABLED='1',GIT_TERMINAL_PROMPT='0')
        yield token
    finally:
        for name,value in previous.items():
            if value is None:
                os.environ.pop(name,None)
            else:
                os.environ[name] = value


def inspect_credential_storage(root, token):
    for filename in root.rglob('*'):
        if filename.is_file():
            with filename.open('rb') as reader:
                tail = b''
                for chunk in iter(lambda:reader.read(1048576),b''):
                    joined = tail+chunk
                    if token in joined:
                        raise RuntimeError('Credential bytes reached private QA evidence; do not publish')
                    tail = joined[-len(token):]


def main(arguments):
    if not re.fullmatch('[0-9a-f]{40}',arguments.parent):
        raise ValueError('QA requires the exact independently observed evidence branch parent')
    root = arguments.root
    if not root.is_absolute() or any(parent.is_symlink() for parent in [root,*root.parents]):
        raise ValueError('QA root must be physical and absolute')
    canonical = root.resolve()
    if canonical.parent != Path('/run'):
        raise ValueError('This fixed QA uses one new direct child of /run only')
    for protected in [SOURCE,TOOL,PRIMARY]:
        if canonical.is_relative_to(protected) or protected.is_relative_to(canonical):
            raise ValueError('QA root must remain outside producer/tool/primary repositories and ancestors')
    raw = DESCRIPTOR.read_bytes()
    if hashlib.sha256(raw).hexdigest() != DESCRIPTOR_SHA:
        raise ValueError('Reviewed coordinator descriptor changed')
    descriptor = json.loads(raw)
    loader_path = TOOL/'loader.py'
    loader_raw = loader_path.read_bytes()
    if len(loader_raw) != descriptor['loader']['bytes'] or hashlib.sha256(loader_raw).hexdigest() != descriptor['loader']['sha256']:
        raise ValueError('Reviewed coordinator loader changed')
    bootstrap = {'__name__':'reviewed_coordinator_qa_bootstrap','__file__':str(loader_path)}
    exec(compile(loader_raw,str(loader_path),'exec'),bootstrap)
    modules = bootstrap['load'](TOOL,descriptor['files'])
    runtime = modules['runtime']
    artifacts = modules['artifacts']
    replay = modules['replay']
    coordinator = modules['coordinator']
    root.mkdir(mode=0o700,exist_ok=False)
    runtime.configure(source=SOURCE,output=root/'journals',work=root/'work',
        branch='feature/pilot-v2-ci-evidence',namespace=NAMESPACE,
        native_cli=Path('/run/rustdom-native-gh-2.103.3/gh'))
    handlers = runtime.start_supervision()
    completed = []
    try:
        if runtime.command(runtime.GIT+['rev-parse','HEAD'],'qa-source-head').strip() != descriptor['readerSourceCommit'].encode():
            raise ValueError('Actual Linux reader source commit changed')
        if runtime.command(runtime.GIT+['status','--porcelain'],'qa-source-clean') != b'':
            raise ValueError('Actual Linux reader checkout is not clean')
        old_raw = (COLLECTION/'summary.json').read_bytes()
        if hashlib.sha256(old_raw).hexdigest() != COLLECTION_SHA:
            raise ValueError('Previously reviewed complete source collection changed')
        old = json.loads(old_raw)
        if old['originalArchivesAuthenticated'] != 33 or old['dataRunId'] != DATA_RUN or old['dataSourceCommit'] != DATA_HEAD:
            raise ValueError('QA source is not the fixed consumed 33-artifact dataset')
        old_by_id = {record['id']:record for record in old['records']}
        legacy = replay.initialize_readers(PRIMARY,'legacy')
        current = replay.initialize_readers(PRIMARY,'current') if arguments.mode == 'positive' else None
        with credentials(root) as token:
            if runtime.remote_head('qa-initial-parent') != arguments.parent:
                raise ValueError('Evidence branch advanced before this fixed QA sequence')
            author = runtime.command(runtime.GIT+['show','-s','--format=%an%x00%ae',descriptor['readerSourceCommit']],
                'qa-existing-author').decode().strip().split('\0')
            plan = artifacts.discover(run_id=DATA_RUN,source_commit=DATA_HEAD,
                workflow_path='.github/workflows/jsdom-block-pilot-capture.yml',criteria=legacy['criteria'])
            replay.write_json(root/'plan.json',plan)
            if not plan['allExpectedArtifactsAvailable'] or len(plan['records']) != 33:
                raise ValueError('Fixed existing qualification dataset lost an original artifact')
            def borrowed(row):
                original = old_by_id[row['metadata']['id']]
                if original['sha256'] != row['metadata']['digest'][7:] or original['bytes'] != row['metadata']['size_in_bytes']:
                    raise ValueError('Current API identity differs from the previously reviewed original')
                filename = COLLECTION/'journals'/original['originalPath']
                if filename.is_symlink() or not filename.resolve().is_relative_to(COLLECTION):
                    raise ValueError('Borrowed source escaped the fixed reviewed original collection')
                return filename
            parent = arguments.parent
            ordinal = 0
            if arguments.mode == 'negative':
                row = plan['records'][0]
                if row['ordinal'] is not None:
                    raise ValueError('Negative QA must use the preflight original only')
                def rejected_inspection(extracted, original):
                    raise ValueError('Controlled inspector rejection before replay')
                try:
                    coordinator.coordinate_one(row,relative_prefix=NAMESPACE+'/negative/'+str(row['metadata']['id'])+'/zip.parts',
                        parent=parent,author=author,ordinal=ordinal,inspect=rejected_inspection,borrowed_original=borrowed(row))
                except ValueError as error:
                    if str(error) != 'Controlled inspector rejection before replay':
                        raise
                else:
                    raise AssertionError('Controlled inspection rejection unexpectedly returned success')
                identity = str(row['metadata']['id'])
                publication = json.loads((runtime.OUTPUT/('artifact-'+identity+'-publication.json')).read_bytes())
                parent = publication['parts'][-1]['commit']
                if not publication['wholeRemoteDigestVerified'] or runtime.remote_head('qa-negative-final-parent') != parent:
                    raise ValueError('Negative QA did not confirm preservation of the complete original')
                local = runtime.OUTPUT/('zip-'+identity)/'stdout.bin'
                slot = runtime.WORK/(coordinator.POLICY['slotPrefix']+identity)
                if not local.is_file() or runtime.checksum_path(local) != publication['sha256'] or not slot.is_dir():
                    raise AssertionError('Failed inspection lost its original or derived slot')
                if (runtime.OUTPUT/('artifact-'+identity+'-retired.json')).exists() or list(runtime.WORK.glob('*.git')):
                    raise AssertionError('Negative QA retired input or retained a Git publication client')
                result = {'mode':'negative','controlledInspectionFailureObserved':True,'wholeOriginalPublishedBeforeFailure':True,
                    'originalAndSlotRetained':True,'publication':publication,'finalEvidenceCommit':parent}
            else:
                context = {'profile':legacy,'runId':DATA_RUN}
                for row in plan['records']:
                    result,parent,ordinal = coordinator.coordinate_one(row,
                        relative_prefix=NAMESPACE+'/legacy/'+str(row['metadata']['id'])+'/zip.parts',parent=parent,
                        author=author,ordinal=ordinal,inspect=lambda extracted, original:replay.inspect_capture(extracted,original,context),
                        borrowed_original=borrowed(row))
                    readers = result['inspection']['readers']
                    if row['ordinal'] is not None:
                        if (len(readers) != 2 or not result['inspection']['readerAgreement']
                                or any(reader['exitCode'] != 1 or reader['result'].get('reason') != 'no-index'
                                    or reader['result']['complete'] is not False or reader['result']['analysis'] is not None for reader in readers)):
                            raise AssertionError('Coordinator changed an existing historical partial result')
                    completed.append(result)
                    print(json.dumps({'coordinatedArtifact':row['metadata']['id'],'ordinal':row['ordinal'],
                        'remoteOriginalVerified':True,'ownedCopiesRetired':True}),flush=True)
                metadata = json.loads(artifacts.api('actions/artifacts/12688150146','qa-functional-metadata'))
                if (metadata['workflow_run']['id'] != 40395417183 or metadata['workflow_run']['head_sha'] != descriptor['readerSourceCommit']
                        or metadata['name'] != 'jsdom-block-calendar-22.12.0-'+descriptor['readerSourceCommit']
                        or metadata['size_in_bytes'] != 111209731
                        or metadata['digest'] != 'sha256:914dccda28284f206e1e077f9805e652f66209694ef7c7bbe405c520ed2ecff7'):
                    raise ValueError('Known complete functional CI artifact differs from its existing identity')
                jobs = json.loads(artifacts.api('actions/runs/40395417183/attempts/1/jobs?per_page=100','qa-functional-jobs'))
                matching = [job for job in jobs['jobs'] if job['name'] == 'Calendario y medias Node 22.12.0']
                if len(matching) != 1 or matching[0]['head_sha'] != descriptor['readerSourceCommit'] or matching[0]['conclusion'] != 'success':
                    raise ValueError('Known complete CI fixture has no unique successful source job')
                row = {'metadata':metadata,'ordinal':0,'jobId':matching[0]['id'],'jobConclusion':matching[0]['conclusion']}
                context = {'profile':current,'dataNode':'v22.12.0'}
                result,parent,ordinal = coordinator.coordinate_one(row,
                    relative_prefix=NAMESPACE+'/functional/'+str(metadata['id'])+'/zip.parts',parent=parent,author=author,ordinal=ordinal,
                    inspect=lambda extracted, original:replay.inspect_functional_ci(extracted,original,context),
                    borrowed_original=Path('/run/rustdom-ci-4196-artifacts-20261026/journals/zip-12688150146.stdout'))
                readers = result['inspection']['readers']
                if (len(readers) != 4 or not result['inspection']['readerAgreement']
                        or any(reader['exitCode'] != 0 or not reader['result']['complete'] or reader['result']['analysis'] is not None
                            or reader['result']['sourceBindingChecked'] is not True for reader in readers)):
                    raise AssertionError('Coordinator failed the real complete AA/AB functional controls in both SDKs')
                completed.append(result)
                if len(completed) != 34 or ordinal != 37 or list(runtime.WORK.iterdir()):
                    raise AssertionError('Sequential coordinator matrix or retired workspace is incomplete')
                totals = {}
                for reader in readers:
                    if reader['node'] == 'v22.12.0':
                        for key,value in reader['result']['totals'].items():
                            totals[key] = totals.get(key,0)+value
                result = {'mode':'positive','coordinatedArtifacts':len(completed),'boundedParts':ordinal,
                    'historicalPartialReplays':64,'completeFunctionalReplays':4,'uniqueExistingFunctionalDataTotals':totals,
                    'readersDoNotCreateNewSamples':True,'records':completed,'finalEvidenceCommit':parent}
            inspect_credential_storage(root,token)
        runtime.check_cancelled()
        if runtime.owned_processes():
            raise ValueError('Coordinator native descendants remain')
        for name,pin in descriptor['files'].items():
            if runtime.checksum_path(TOOL/name) != pin['sha256']:
                raise ValueError('Coordinator code changed during qualification: '+name)
        if runtime.command(runtime.GIT+['status','--porcelain'],'qa-source-clean-after') != b'':
            raise ValueError('Coordinator modified the qualified producer source')
        result.update(initialParent=arguments.parent,descriptorSha256=DESCRIPTOR_SHA,
            ownedLinuxDescendantsRemaining=[],credentialBytesPersisted=False,
            originalBorrowedInputsNotRemoved=True,newDOMExecuted=False,scientificCaptureExecuted=False,
            archivedCodeExecuted=False,performanceAccepted=None,gateReevaluated=False)
        replay.write_json(root/'summary.json',result)
        print(json.dumps({'mode':arguments.mode,'finalEvidenceCommit':parent,'newDOMExecuted':False}),flush=True)
    except BaseException as error:
        replay.write_json(root/'failure.json',{'errorType':type(error).__name__,'message':str(error),
            'completedArtifacts':[record['original']['id'] for record in completed],
            'ownedLinuxDescendantsAtFailure':runtime.owned_processes(),'newDOMExecuted':False,
            'allUnconfirmedOriginalsAndIntentsRetained':True})
        raise
    finally:
        runtime.settle_tree(terminate=True)
        for requested,handler in handlers.items():
            signal.signal(requested,handler)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode',choices=['negative','positive'],required=True)
    parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--parent',required=True)
    main(parser.parse_args())
