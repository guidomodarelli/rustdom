"""Verify the normal exact-SHA fetch/fast-forward changed only confirmed QA evidence paths."""
import json
from pathlib import Path
import subprocess

source = Path(__file__).resolve().parent.parent
data = Path('C:/Users/guido/.codex/worktrees/pilot-v2-ci-evidence/rustdom')
audit = json.loads((source/'.cache/coordinator-sync-audit.json').read_bytes())
git = ['git','--no-optional-locks','-c','core.longpaths=true','-c','gc.auto=0','-c','maintenance.auto=false']
def command(*arguments,**kwargs):
    return subprocess.check_output(git+list(arguments),cwd=data,**kwargs)
if command('rev-parse','HEAD').decode().strip() != audit['expectedRemoteHead']:
    raise ValueError('Exact confirmed coordinator tip was not fast-forwarded')
observed = command('rev-list','--reverse',audit['expectedRemoteHead'],'^'+audit['sharedParent']).decode().splitlines()
if observed != [part['commit'] for part in audit['commits']]:
    raise ValueError('Imported commit chain differs from the confirmed native publications')
for part in audit['commits']:
    changes = command('diff-tree','--no-commit-id','--no-renames','--name-status','-r',part['parent'],part['commit'])
    if changes != ('A\t'+part['path']+'\n').encode():
        raise ValueError('Normal synchronization changed more than one recorded evidence path')
    if command('ls-files','-v','--',part['path']).decode().strip() != 'S '+part['path']:
        raise ValueError('Raw QA evidence was unexpectedly hydrated into the sparse checkout')
common = Path(command('rev-parse','--path-format=absolute','--git-common-dir').decode().strip())
pack = max((common/'objects/pack').glob('pack-*.pack'),key=lambda filename:filename.stat().st_mtime)
types = {}
identities = set()
for line in command('verify-pack','-v',str(pack.with_suffix('.idx'))).decode().splitlines():
    fields = line.split()
    if len(fields) >= 5 and len(fields[0]) == 40 and fields[1] in ['commit','tree','blob','tag']:
        types[fields[1]] = types.get(fields[1],0)+1
        identities.add(fields[0])
if not set(observed).issubset(identities) or set(types)-{'commit','tree'}:
    raise ValueError('Newest imported pack is not exactly a metadata-only pack covering the expected commits')
result = {'sharedHead':audit['expectedRemoteHead'],'verifiedSingleAdditionCommits':len(observed),
    'rawPathsRemainSparse':True,'packName':pack.name,'packBytes':pack.stat().st_size,'objectTypes':types,
    'newRawBlobPayloadsFetched':0,'filteredFetchUsed':False,'permanentGitObjectsDeleted':False,
    'blockedTemporaryBufferLeftUntouched':(common/'objects/pack/tmp_pack_IyiPK4').is_file()}
with (source/'.cache/coordinator-sync-verification.json').open('xb') as writer:
    writer.write(json.dumps(result,indent=2).encode()+b'\n')
print(json.dumps(result))
