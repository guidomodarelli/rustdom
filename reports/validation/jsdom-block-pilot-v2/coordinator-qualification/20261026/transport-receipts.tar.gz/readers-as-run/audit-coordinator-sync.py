"""Prove the fixed coordinator commits reference only blobs already known at the shared Git parent."""
import json
from pathlib import Path
import subprocess
import sys

if sys.flags.optimize:
    raise RuntimeError('Coordinator Git synchronization audit requires non-optimized Python')
source = Path(__file__).resolve().parent.parent
data = Path('C:/Users/guido/.codex/worktrees/pilot-v2-ci-evidence/rustdom')
base = '5b0780eaf81428eda592abcba629f3922f31bbfb'
head = 'b9c0fab317c7ff14c567492802afd536cf40a6bc'
git = ['git','--no-optional-locks','-c','core.longpaths=true','-c','gc.auto=0','-c','maintenance.auto=false']
def command(*arguments,**kwargs):
    return subprocess.check_output(git+list(arguments),cwd=data,**kwargs)
def read_linux(filename):
    program = 'from pathlib import Path; import sys; sys.stdout.buffer.write(Path('+repr(filename)+').read_bytes())'
    return json.loads(subprocess.check_output(['wsl','-d','Rustdom-Validation-20261025','-u','root','--','python3','-c',program]))
if command('rev-parse','HEAD').decode().strip() != base:
    raise ValueError('Shared evidence checkout advanced; inspect it before synchronization')
for key in ['remote.origin.promisor','remote.origin.partialclonefilter','extensions.partialclone']:
    result = subprocess.run(git+['config','--get',key],cwd=data,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    if result.returncode != 1 or result.stdout:
        raise ValueError('Shared repository has partial-clone configuration; do not repeat the failed conversion')
negative = read_linux('/run/rustdom-coordinator-negative-20261026/summary.json')
positive = read_linux('/run/rustdom-coordinator-positive-20261026/summary.json')
if (negative['initialParent'] != base or positive['initialParent'] != negative['finalEvidenceCommit']
        or positive['finalEvidenceCommit'] != head or positive['coordinatedArtifacts'] != 34 or positive['boundedParts'] != 37):
    raise ValueError('Actual completed coordinator chain differs')
groups = [(12669334760,negative['publication']['parts'])]+[(record['original']['id'],record['publication']['parts']) for record in positive['records']]
parent = base
parts = []
known_blobs = {}
for identity,group in groups:
    for index,part in enumerate(group):
        if part['parent'] != parent or not part['independentRemoteDigestVerified'] or not part['bothDisposableRepositoriesRemoved']:
            raise ValueError('Coordinator publication chain is not intact and confirmed')
        if not part['path'].startswith('reports/validation/jsdom-block-pilot-v2/coordinator-qualification/20261026/'):
            raise ValueError('Unexpected publication namespace in coordinator chain')
        canonical = ('reports/validation/jsdom-block-pilot-v2/scientific-transport/20261026/roundtrip/12688150146/zip.parts/'+str(index).zfill(4)+'.bin'
            if identity == 12688150146 else 'reports/benchmarks/native-class-ownership/jsdom-block-pilot-results/40366685759/evidence/collection/'+str(identity)+'.zip')
        observed = command('rev-parse',base+':'+canonical).decode().strip()
        if observed != part['blob']:
            raise ValueError('New publication introduces a blob not already referenced by the known parent')
        known_blobs[part['blob']] = {'bytes':part['bytes'],'sha256':part['sha256'],'canonicalParentPath':canonical}
        parts.append(part)
        parent = part['commit']
if len(parts) != 38 or parent != head:
    raise ValueError('Expected 38 metadata-only coordinator commits')
oids = list(known_blobs)
observed = command('cat-file','--batch-check',input=''.join(identity+'\n' for identity in oids).encode()).decode().splitlines()
if len(observed) != len(oids):
    raise ValueError('Local Git object inventory is incomplete')
for identity,line in zip(oids,observed):
    fields = line.split()
    if fields != [identity,'blob',str(known_blobs[identity]['bytes'])]:
        raise ValueError('Known parent archive blob is absent from the shared object database; do not fetch unbounded data')
result = {'sharedParent':base,'expectedRemoteHead':head,'commits':parts,'knownParentBlobs':known_blobs,
    'newUniqueBlobPayloadsRequired':0,'normalFetchOfExactImmutableCommitOnly':True,
    'filteredFetchAllowed':False,'automaticGcAllowed':False,'permanentGitObjectsDeleted':False,
    'blockedTemporaryBufferLeftUntouched':True,'newDOMExecuted':False}
target = source/'.cache/coordinator-sync-audit.json'
with target.open('xb') as writer:
    writer.write(json.dumps(result,indent=2).encode()+b'\n')
print(json.dumps({'metadataOnlyCommits':len(parts),'alreadyKnownBlobs':len(known_blobs),'newUniqueBlobPayloadsRequired':0,'head':head}))
