"""Hydrate the unchanged v1 ancestor and numeric package in an actual clean Git checkout."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

if sys.flags.optimize:
    raise RuntimeError('Pilot source preparation requires non-optimized Python')
SOURCE = Path(__file__).resolve().parent
REPOSITORY = SOURCE.parents[5]
POLICY = json.loads((SOURCE.parent / 'constants/capture.json').read_bytes())


def populate(repository):
    """Reuse the real Git hydrator, then require every independently pinned ancestor byte."""
    specification = importlib.util.spec_from_file_location('current_numeric_checkout',
        REPOSITORY / 'reports/benchmarks/native-class-ownership/numeric-composed-packages/checkout.py')
    checkout = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(checkout)
    checkout.populate(repository, checkout.required(repository))
    # The ancestor publication itself is a separate fixed input, never the new method's self-produced catalog.
    checkout.populate(repository, [POLICY['historicalReceipt']])
    receipt = repository / POLICY['historicalReceipt']
    raw = receipt.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == POLICY['historicalReceiptSha256']
    files = json.loads(raw)['files']
    assert len(files) == POLICY['historicalPins']
    result = checkout.populate(repository, files)
    for relative, checksum in files.items():
        assert hashlib.sha256((repository / relative).read_bytes()).hexdigest() == checksum, relative
    return {**result, 'ancestorPinsVerified': len(files), 'DOMExecuted': False}


if __name__ == '__main__':
    assert len(sys.argv) == 2, 'Provide the actual clean sparse Git source checkout'
    print(json.dumps(populate(Path(sys.argv[1]).resolve(strict=True))))
