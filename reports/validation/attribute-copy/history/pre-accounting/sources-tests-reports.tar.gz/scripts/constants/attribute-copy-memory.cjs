/** @module scripts/constants/attribute-copy-memory Repeated ownership checks for immutable native snapshots. */
'use strict';
module.exports = {
  ATTRIBUTE_COPY_NAMESPACE: 'urn:attribute-copy-memory',
  ATTRIBUTE_COPY_VALUE: 'copied\0\ud800\udfff🦀',
  ATTRIBUTE_COPY_STANDALONE_VALUE: 'standalone\0\udfff',
};
