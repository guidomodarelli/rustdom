//! Immutable Attr snapshots own Rust strings only; V8 finalization releases them independently of trees.
use super::{attribute_copy::AttributeCopyData, napi_string::string_result};
use napi::bindgen_prelude::{Either, Utf16String};
use napi_derive::napi;
use std::sync::atomic::{AtomicU64, Ordering};

static LIVE: AtomicU64 = AtomicU64::new(0);
static CREATED: AtomicU64 = AtomicU64::new(0);
static RELEASED: AtomicU64 = AtomicU64::new(0);

#[napi]
pub struct NativeAttributeCopy {
    pub(super) data: AttributeCopyData,
}

impl NativeAttributeCopy {
    pub(super) fn from_data(data: AttributeCopyData) -> Self {
        LIVE.fetch_add(1, Ordering::Relaxed);
        CREATED.fetch_add(1, Ordering::Relaxed);
        Self { data }
    }
}
impl Drop for NativeAttributeCopy {
    fn drop(&mut self) {
        LIVE.fetch_sub(1, Ordering::Relaxed);
        RELEASED.fetch_add(1, Ordering::Relaxed);
    }
}
#[napi]
impl NativeAttributeCopy {
    #[napi(getter)]
    pub fn local_name(&self) -> Either<&str, Utf16String> {
        string_result(Some(&self.data.0.name)).expect("Attr copy owns its name")
    }
    #[napi(getter)]
    pub fn namespace(&self) -> Option<Either<&str, Utf16String>> {
        string_result(self.data.0.namespace.as_ref())
    }
    #[napi(getter)]
    pub fn prefix(&self) -> Option<Either<&str, Utf16String>> {
        string_result(self.data.0.prefix.as_ref())
    }
    #[napi(getter)]
    pub fn value(&self) -> Either<&str, Utf16String> {
        string_result(Some(&self.data.0.value)).expect("Attr copy owns its value")
    }
}
#[napi(object)]
pub struct AttributeCopyStatistics {
    pub live: f64,
    pub created: f64,
    pub released: f64,
}
#[napi]
pub fn attribute_copy_statistics() -> AttributeCopyStatistics {
    AttributeCopyStatistics {
        live: LIVE.load(Ordering::Relaxed) as f64,
        created: CREATED.load(Ordering::Relaxed) as f64,
        released: RELEASED.load(Ordering::Relaxed) as f64,
    }
}
