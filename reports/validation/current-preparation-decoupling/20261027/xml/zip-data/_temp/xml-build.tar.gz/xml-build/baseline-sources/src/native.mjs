/** @module rustdom/native Exposes explicit ESM names for the real Node-API addon. */
import native from './native.cjs';
/** Reexport the canonical addon objects without allocating native instances or duplicating enum values. */
export const {
  NativeTree, NativeRange, QueryMode, AttributeField, DocumentTypeField, NodeTextWriteAction, NodeInsertionStatus,
  RangePointRelation, RangeBoundaryMode, RangeBoundaryAction, RangeComparison, RangeDeletionKind, RangeSurroundStatus,
  RangeMutationKind, RangeEndpoint,
  NativeRangeClone, RangeCloneAction,
  NativeRangeExtract, RangeExtractAction,
  NativeSlotAssignmentDriver, SlotAssignmentAction,
  NativeMutationRecord, ObservationStatus,
  NativeObserverDelivery, ObserverDeliveryAction,
  NativeEventState, EventStateFlag, EventDispatchStatus, EventInvocationEncoding,
  NativeListenerRegistry, ListenerInvocation,
  NativeAbortState,
  NativeXmlParser,
  NativeTokenList, NativeTokenSet, TokenListMethod, TokenValidation,
  DatasetNameStatus,
  NativeDomRect,
  NativeStorageArea, NativeStorageKeyCursor, StorageSetStatus,
  NativeBlobMetadata, normalizeBlobEndings, blobSliceRange, concatenateBlobBuffers,
  classReferenceStatistics,
  NativeFileReaderState, ReaderStringFormat, fileReaderString, fileReaderEncoding,
  DocumentImplementationOperation, documentImplementationOperation, documentImplementationStatistics,
  DomParserOperation, domParserOperation, domParserStatistics,
  NativeFormDataEntries,
  NativeSelectionState,
  SelectionOperation, selectionOperation, selectionOperationResult, selectionOperationStatistics,
  prepareFormDataValue, constructFormData, formDataConstructionStatistics,
  serializeXml, serializeXmlForest, xmlSerializationStatistics,
  NativeTraversal, NativeTraversalOperation, TraversalMethod, TraversalAction, TraversalMoveResult,
  parseDocumentTape, parseFragmentTape,
} = native;
export default native;
