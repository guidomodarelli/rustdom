/** @file Preserves the original test projects and redirects only their cache directory. */
import settings from './suite-settings.json' with { type: 'json' };
const original = process.env[settings.runnerEnvironment] === 'vitest-vm'
  ? './vitest.vm.config.mjs' : './vitest.config.mjs';
const { default: configuration } = await import(original);
export default { ...configuration, cacheDir: process.env[settings.cacheEnvironment] };
