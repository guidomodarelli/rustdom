"""Freeze and qualify the new CPU intervention with real official packages; do not accept performance."""
import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import tempfile
import time

repository = pathlib.Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom')
nodes = [('/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node-22/bin/node', 'v22.12.0'),
         ('/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node/bin/node', 'v24.14.1')]
root = pathlib.Path(tempfile.mkdtemp(prefix='background-affinity-qualification-', dir=repository / '.cache'))
marker = repository / '.cache/background-affinity-linux-fifo-qualification.started.json'
with marker.open('x') as output:
    json.dump({'root': str(root), 'pid': os.getpid(), 'startedAt': time.time(), 'acceptanceStudyExecuted': False}, output)
print('ROOT ' + str(root), flush=True)
restoration = json.loads((repository / '.cache/background-affinity-restoration.json').read_text())
prior = pathlib.Path('/home/guido/rustdom-validation/recorded-evidence-8g_5cu_3/row-extracted/row-isolation/study')
if not (prior / 'verification.json').is_file():
    raise ValueError('Preserved consumed row study is missing; do not regenerate it')
environment = dict(os.environ)
if 'NODE_OPTIONS' in environment:
    raise ValueError('Undeclared NODE_OPTIONS is present')
harness = json.loads(subprocess.check_output([nodes[0][0], '-e',
    "process.stdout.write(JSON.stringify(require('./reports/benchmarks/native-class-ownership/background-affinity-experiment.cjs').captureHarness()))"],
    cwd=repository, env=environment))
for entry in harness['files']:
    raw = (repository / entry['path']).read_bytes()
    if hashlib.sha256(raw).hexdigest() != entry['sha256'] or len(raw) != entry['bytes']:
        raise ValueError('Source changed before qualification: ' + entry['path'])
    target = root / 'harness' / entry['path']
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
(root / 'source-manifest.json').write_text(json.dumps(harness, indent=2) + '\n')
shutil.copyfile(__file__, root / 'qualification-driver.py')
shutil.copyfile(repository / '.cache/restore-background-preparation.py', root / 'restoration-driver.py')
shutil.copyfile(repository / '.cache/background-affinity-restoration.json', root / 'restoration.json')
receipt = {'complete': False, 'acceptanceStudyExecuted': False, 'performanceAccepted': None,
           'startedAt': time.time(), 'root': str(root), 'commands': []}


def save():
    (root / 'qualification.json').write_text(json.dumps(receipt, indent=2) + '\n')


save()
for ordinal, (node, version) in enumerate(nodes):
    label = 'node-' + version.split('.')[0][1:]
    directory = root / label
    directory.mkdir()
    workers = directory / 'workers'
    workers.mkdir()
    local = dict(environment, RUSTDOM_HOSTED_BUILD_ARCHIVE=restoration['preparation'],
                 RUSTDOM_PRIOR_ROW_ARCHIVE=str(prior), RUSTDOM_BACKGROUND_AFFINITY_TEST_OUTPUT=str(workers))
    for name, arguments in [('version', ['--version']), ('contracts', ['--test', '--test-reporter=tap', '--test-concurrency=1',
             'reports/benchmarks/native-class-ownership/background-affinity.spec.cjs'])]:
        record = {'command': [node, *arguments], 'cwd': str(root / 'harness'), 'startedAt': time.time(),
                  'environment': {key: value for key, value in local.items() if key.startswith('RUSTDOM_')},
                  'stdout': label + '/' + name + '.stdout.log', 'stderr': label + '/' + name + '.stderr.log'}
        receipt['commands'].append(record)
        save()
        with (root / record['stdout']).open('xb') as stdout, (root / record['stderr']).open('xb') as stderr:
            child = subprocess.Popen(record['command'], cwd=root / 'harness', env=local, stdout=stdout, stderr=stderr)
            record['pid'] = child.pid
            save()
            print('START ' + label + '/' + name + ' pid=' + str(child.pid), flush=True)
            record['exitCode'] = child.wait()
            record['finishedAt'] = time.time()
            save()
        print('END ' + label + '/' + name + ' exit=' + str(record['exitCode']), flush=True)
        if record['exitCode'] != 0:
            raise RuntimeError('Functional qualification failed; preserve this attempt: ' + label + '/' + name)
        if name == 'version' and (root / record['stdout']).read_text().strip() != version:
            raise ValueError('Actual Node version differs from declaration')
for entry in harness['files']:
    for base in [repository, root / 'harness']:
        raw = (base / entry['path']).read_bytes()
        if hashlib.sha256(raw).hexdigest() != entry['sha256'] or len(raw) != entry['bytes']:
            raise ValueError('Qualified source changed: ' + entry['path'])
receipt['complete'] = True
receipt['finishedAt'] = time.time()
save()
print('COMPLETE: both actual Nodes qualified; no acceptance study executed', flush=True)
