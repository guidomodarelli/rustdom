"""Restore the immutable official preparation to a fresh durable Linux directory; never build or measure."""
import hashlib
import io
import json
import pathlib
import tarfile
import tempfile
import zipfile

repository = pathlib.Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom')
receipt = json.loads((repository / 'reports/validation/native-class-ownership/hosted-build-ci/39720077911/receipt.json').read_text())
archive = repository / 'reports/validation/native-class-ownership/hosted-build-ci/39720077911/artifact-12400802735.zip'
raw = archive.read_bytes()
if hashlib.sha256(raw).hexdigest() != receipt['artifactSha256']:
    raise ValueError('Official preparation ZIP digest differs from the published receipt')
with zipfile.ZipFile(io.BytesIO(raw)) as bundle:
    raw_tar = bundle.read('ownership-build.tar.gz')
if hashlib.sha256(raw_tar).hexdigest() != receipt['tarSha256']:
    raise ValueError('Official preparation tar digest differs from the published receipt')
root = pathlib.Path(tempfile.mkdtemp(prefix='background-affinity-preparation-', dir='/home/guido/rustdom-validation'))


def confined_filter(member, destination):
    """Handle relative symlinks correctly despite the Python3.10 backport resolving them at the extraction root."""
    if member.issym():
        if pathlib.PurePosixPath(member.linkname).is_absolute():
            raise ValueError('Official archive contains an absolute symlink')
        resolved = (pathlib.Path(destination) / member.name).parent.joinpath(member.linkname).resolve()
        relative = resolved.relative_to(pathlib.Path(destination).resolve())
        filtered = tarfile.data_filter(member.replace(linkname=str(relative)), destination)
        return filtered.replace(linkname=member.linkname)
    if not member.isfile() and not member.isdir():
        raise ValueError('Official archive contains an unsupported entry')
    return tarfile.data_filter(member, destination)


with tarfile.open(fileobj=io.BytesIO(raw_tar), mode='r:gz') as bundle:
    bundle.extractall(root, filter=confined_filter)
indices = list(root.glob('*/index.json'))
if len(indices) != 1:
    raise ValueError('Official preparation did not restore one top-level index')
restoration = {'root': str(root), 'preparation': str(indices[0].parent),
               'zipSha256': receipt['artifactSha256'], 'tarSha256': receipt['tarSha256'],
               'rebuilt': False, 'measurementExecuted': False}
target = repository / '.cache/background-affinity-restoration.json'
with target.open('x') as output:
    json.dump(restoration, output, indent=2)
    output.write('\n')
print(json.dumps(restoration), flush=True)
