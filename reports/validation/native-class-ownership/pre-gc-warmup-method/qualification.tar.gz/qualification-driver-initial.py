import hashlib,json,os,pathlib,shutil,subprocess,tempfile,time
repo=pathlib.Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom')
root=pathlib.Path(tempfile.mkdtemp(prefix='rustdom-pre-gc-method-'))
(repo/'.cache/pre-gc-method-root.txt').write_text(str(root)+'\n')
harness=json.loads((repo/'.cache/pre-gc-harness.json').read_bytes())
for entry in harness['files']:
    source=repo/entry['path'];target=root/'harness'/entry['path']
    assert hashlib.sha256(source.read_bytes()).hexdigest()==entry['sha256']
    target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
(root/'source-manifest.json').write_text(json.dumps(harness,indent=2)+'\n')
nodes={'node-22':'/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node-22/bin/node','node-24':'/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node/bin/node'}
environment=dict(os.environ);environment.pop('NODE_OPTIONS',None)
environment.update({'RUSTDOM_HOSTED_BUILD_ARCHIVE':'/tmp/rustdom-ownership-results-m7jq3638/independent-order/prepared/ownership-build',
 'RUSTDOM_PRIOR_REALM_ARCHIVE':'/tmp/rustdom-realm-warmup-study-m5hpgvcr'})
receipt={'complete':False,'measurementAccepted':None,'root':str(root),'commands':[],'startedAt':time.time()}
save=lambda:(root/'qualification.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('ROOT',root,flush=True);save()
commands=[('contracts',['--test','reports/benchmarks/native-class-ownership/pre-gc-warmup.spec.cjs']),
 ('warmup',['--expose-gc','--test','tests/benchmarks/worker-warmup.spec.cjs']),
 ('default-runtime',['--expose-gc','--test','tests/benchmarks/worker-runtime.spec.cjs']),
 ('default-realms',['--expose-gc','--test','tests/benchmarks/worker-realms.spec.cjs'])]
for label,node in nodes.items():
    (root/label).mkdir();(root/label/'workers').mkdir()
    for name,arguments in commands:
        local=dict(environment)
        local['RUSTDOM_PRE_GC_WARMUP_TEST_OUTPUT']=str(root/label/'workers')
        local['RUSTDOM_BENCHMARK_PACKAGE']=environment['RUSTDOM_HOSTED_BUILD_ARCHIVE']+'/packages/B'
        if name.startswith('default-'):local['RUSTDOM_BENCHMARK_PACKAGE']='/tmp/rustdom-runner-suites-ytu9q4xb/static-prepared/packages/B'
        if name=='warmup':local['RUSTDOM_WARMUP_EVIDENCE']=str(root/label/'warmup-evidence.json')
        prefix=root/label/name
        record={'command':[node,*arguments],'cwd':str(root/'harness'),'startedAt':time.time(),
          'environment':{key:value for key,value in local.items() if key.startswith('RUSTDOM_')},
          'stdout':str(prefix.relative_to(root))+'.stdout.log','stderr':str(prefix.relative_to(root))+'.stderr.log'}
        receipt['commands'].append(record);save()
        with (root/record['stdout']).open('xb') as stdout,(root/record['stderr']).open('xb') as stderr:
            child=subprocess.Popen(record['command'],cwd=root/'harness',env=local,stdout=stdout,stderr=stderr)
            record['pid']=child.pid;save();print('START',label,name,'pid',child.pid,flush=True)
            record['exitCode']=child.wait();record['finishedAt']=time.time();save()
        print('END',label,name,'exit',record['exitCode'],flush=True)
        if record['exitCode']:raise SystemExit(record['exitCode'])
for entry in harness['files']:
    assert hashlib.sha256((repo/entry['path']).read_bytes()).hexdigest()==entry['sha256']
    assert hashlib.sha256((root/'harness'/entry['path']).read_bytes()).hexdigest()==entry['sha256']
receipt['complete']=True;receipt['finishedAt']=time.time();save()
