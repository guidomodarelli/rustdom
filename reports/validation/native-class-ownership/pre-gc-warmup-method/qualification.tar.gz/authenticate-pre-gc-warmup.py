import base64,hashlib,io,json,pathlib,subprocess,tarfile
repo=pathlib.Path(r'C:\Users\guido\.codex\worktrees\native-class-ownership\rustdom')
run=lambda args:subprocess.run(args,cwd=repo,check=True,capture_output=True).stdout
head=run(['git','rev-parse','HEAD']).decode().strip()
assert run(['git','ls-remote','origin','refs/heads/feature/native-class-ownership']).decode().split()[0]==head
prefix='reports/validation/native-class-ownership/pre-gc-warmup-method/'
harness=json.loads((repo/prefix/'harness.json').read_bytes())
review=json.loads((repo/prefix/'review.json').read_bytes())
assert review['actionableFindings']==0 and review['harnessSha256']==harness['sha256']
blob=run(['git','archive','--format=tar',head,*[entry['path'] for entry in harness['files']]])
actual={}
with tarfile.open(fileobj=io.BytesIO(blob)) as stream:
    for member in stream:
        if member.isfile():actual[member.name]={'path':member.name,'bytes':member.size,
            'sha256':hashlib.sha256(stream.extractfile(member).read()).hexdigest()}
assert [actual[entry['path']] for entry in harness['files']]==harness['files']
receiptPath=prefix+'review.json'
remote=json.loads(run(['gh','api',f'repos/guidomodarelli/rustdom/contents/{receiptPath}?ref={head}']))
assert base64.b64decode(remote['content'])==(repo/receiptPath).read_bytes()
provenance={'reviewedCommit':head,'harnessSha256':harness['sha256'],
    'receiptUrl':f'https://github.com/guidomodarelli/rustdom/blob/{head}/{receiptPath}'}
publication={'head':head,'remoteHeadMatched':True,'sourceFiles':len(harness['files']),
    'allGitBlobsMatched':True,'reviewReceiptMatchedGitHub':True,'provenance':provenance,
    'publishedHarnessTarSha256':hashlib.sha256(blob).hexdigest()}
(repo/'.cache/pre-gc-warmup-published-harness.tar').write_bytes(blob)
(repo/'.cache/pre-gc-warmup-publication.json').write_text(json.dumps(publication,indent=2)+'\n',encoding='utf-8')
print(json.dumps(publication))
