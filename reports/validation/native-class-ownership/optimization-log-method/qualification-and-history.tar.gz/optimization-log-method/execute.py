import json,pathlib,shutil,subprocess,tempfile,os
repo=pathlib.Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom')
method=repo/'reports/benchmarks/native-class-ownership/optimization-log'
base=pathlib.Path('/tmp/rustdom-ownership-results-m7jq3638/independent-order')
root=pathlib.Path(tempfile.mkdtemp(prefix='rustdom-optimization-method-'))
(repo/'.cache/optimization-method-root.txt').write_text(str(root)+'\n')
shutil.copyfile(__file__,root/'execute.py');shutil.copytree(method,root/'method')
inputs={'frozenHarness':str(base/'node-22/harness'),'preparation':str(base/'prepared/ownership-build'),
 'localManifest':'/tmp/rustdom-sampler-diagnostics-final-tktpjoet/manifest.json',
 'nodes':['/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node-22/bin/node','/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node/bin/node']}
(root/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
commands=[('contracts',['python3','-B','-m','unittest','discover','-s',str(method),'-p','test_run.py','-v']),
 ('preflight',['python3','-B',str(method/'run.py'),'--preflight',str(root/'inputs.json'),str(root/'preflight')])]
env=dict(os.environ,RUSTDOM_OPTIMIZATION_ARCHIVE=str(base),RUSTDOM_OPTIMIZATION_NODE=inputs['nodes'][0])
for name,argv in commands:
    child=subprocess.run(argv,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (root/(name+'.stdout.log')).write_bytes(child.stdout);(root/(name+'.stderr.log')).write_bytes(child.stderr)
    (root/(name+'-process.json')).write_text(json.dumps({'argv':argv,'exitCode':child.returncode},indent=2)+'\n')
    assert child.returncode==0,child.stderr.decode(errors='replace')
    print(name,child.returncode,flush=True)
print(str(root),flush=True)
