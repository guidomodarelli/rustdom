import importlib.util,json,pathlib,sys,tracemalloc
spec=importlib.util.spec_from_file_location('hash_driver',sys.argv[1]);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
tracemalloc.start();baseline=tracemalloc.get_traced_memory()[0];tracemalloc.reset_peak()
result=module.digest(sys.argv[2]);current,peak=tracemalloc.get_traced_memory()
print(json.dumps({'digest':result,'peakHeapDeltaBytes':peak-baseline,'fileBytes':pathlib.Path(sys.argv[2]).stat().st_size}))
