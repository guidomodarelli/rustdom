"""Exercise the real CI preparation, tests and rejected gate while retaining every receipt on Windows."""
import hashlib
import io
import json
import os
import pathlib
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time

if sys.flags.optimize:
    raise RuntimeError('Ownership workflow qualification: unset PYTHONOPTIMIZE before checking guards')
repository = pathlib.Path(__file__).resolve().parent.parent
base = repository / 'reports/benchmarks/native-class-ownership'
configuration = json.loads((repository / '.cache/constants/archive-row-isolation-study.json').read_bytes())
marker = repository / '.cache/recorded-workflow-qualification.started.json'
with marker.open('x') as destination:
    root = pathlib.Path(tempfile.mkdtemp(prefix='recorded-workflow-qualification-', dir=repository / '.cache'))
    json.dump({'pid': os.getpid(), 'root': str(root), 'startedAt': time.time(), 'measurementExecuted': False}, destination, indent=2)
print(json.dumps({'pid': os.getpid(), 'root': str(root), 'measurementExecuted': False}), flush=True)
names = ['.github/workflows/native-class-ownership.yml',
    'reports/benchmarks/native-class-ownership/constants/row-isolation-evidence.json',
    'reports/benchmarks/native-class-ownership/constants/recorded-fixtures.json',
    'reports/benchmarks/native-class-ownership/row-isolation-evidence.cjs',
    'reports/benchmarks/native-class-ownership/prepare-recorded-fixtures.py',
    'reports/benchmarks/native-class-ownership/recorded-workflow.spec.cjs']
sources = {}
for name in names:
    raw = (repository / name).read_bytes()
    target = root / 'sources' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    sources[name] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
(root / 'sources.json').write_text(json.dumps(sources, indent=2) + '\n')
shutil.copyfile(__file__, root / pathlib.Path(__file__).name)
frozen = json.loads((repository / 'reports/validation/native-class-ownership/row-isolation-method/source-manifest.json').read_bytes())
for entry in frozen['files']:
    raw = (repository / entry['path']).read_bytes()
    assert len(raw) == entry['bytes'] and hashlib.sha256(raw).hexdigest() == entry['sha256']
baseline = root / 'baseline'
baseline.mkdir()
roots = ['src', 'scripts', 'benchmarks', 'third-party/napi', 'package-lock.json', 'Cargo.toml', 'Cargo.lock',
         'tests/integration/read-dom-file.cjs', 'package.json', 'build.rs',
         'third-party/saxes/LICENSE', 'third-party/w3c-xmlserializer/LICENSE.md']
environment = dict(os.environ)
environment.pop('NODE_OPTIONS', None)
records = []


def execute(name, command, expected_exit=0, child_environment=environment, stdout_name=None):
    """Record original child exits, including the required failed performance gate, without remapping them."""
    record = {'command': command, 'cwd': str(repository), 'expectedExitCode': expected_exit,
              'startedAt': time.time(), 'measurementExecuted': False}
    with (root / (stdout_name or (name + '.stdout.log'))).open('xb') as stdout, (root / (name + '.stderr.log')).open('xb') as stderr:
        child = subprocess.Popen(command, cwd=repository, env=child_environment, stdout=stdout, stderr=stderr)
        record['pid'] = child.pid
        (root / (name + '.process.json')).write_text(json.dumps(record, indent=2) + '\n')
        print(f'START {name} pid={child.pid}', flush=True)
        record['exitCode'] = child.wait()
    record['finishedAt'] = time.time()
    (root / (name + '.process.json')).write_text(json.dumps(record, indent=2) + '\n')
    print(f'END {name} exit={record["exitCode"]}', flush=True)
    records.append(record)
    assert record['exitCode'] == expected_exit, f'Preserve {name} logs and fix the real workflow failure before retrying'


execute('baseline-git-archive', ['git.exe', '-C', configuration['windowsRepository'], 'archive', '--format=tar',
    'checkpoint-067-xml-serializer-controller', *roots], stdout_name='baseline-sources.tar')
with tarfile.open(fileobj=io.BytesIO((root / 'baseline-sources.tar').read_bytes())) as stream:
    for member in stream:
        if member.isdir():
            continue
        assert member.isfile()
        name = pathlib.PurePosixPath(member.name)
        assert not name.is_absolute() and '..' not in name.parts
        target = baseline / member.name
        assert target.resolve().is_relative_to(baseline.resolve())
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as destination:
            destination.write(stream.extractfile(member).read())
execute('actionlint', ['/mnt/c/Users/guido/ghq/projects/rustdom/.tools/actionlint/actionlint',
                      str(repository / '.github/workflows/native-class-ownership.yml')])
parts = repository / configuration['output']
results = []
for label, node, expected in [
    ('node-22', '/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node-22/bin/node', 'v22.12.0'),
    ('node-24', configuration['nodeExecutable'], 'v24.14.1'),
]:
    version = subprocess.check_output([node, '--version'], text=True, env=environment).strip()
    assert version == expected
    if label == 'node-22':
        historical = ['hosted-experiment.spec.cjs', 'history.spec.cjs', 'source-preflight.spec.cjs',
            'paired-main-evidence.spec.cjs', 'paired-study-configuration.spec.cjs', 'paired-inline.spec.cjs',
            'ownership-evidence.spec.cjs']
        execute('legacy-node22', [node, '--test', '--test-reporter=tap', *[str(base / name) for name in historical]])
        lines = (root / 'legacy-node22.stdout.log').read_text().splitlines()
        for line in ['# tests 43', '# pass 43', '# fail 0', '# skipped 0', '# cancelled 0']:
            assert line in lines, line
    fixtures = root / (label + '-fixtures')
    execute(label + '-prepare', [sys.executable, '-B', str(base / 'prepare-recorded-fixtures.py'),
        str(baseline), str(parts), str(fixtures)])
    child_environment = dict(environment,
        RUSTDOM_RECORDED_EVIDENCE_FIXTURE=str(fixtures / 'evidence-fixture.json'),
        RUSTDOM_RECORDED_ARCHIVE_FIXTURE=str(fixtures / 'archive-fixture.json'))
    execute(label + '-tests', [node, '--test', '--test-concurrency=1', '--test-reporter=tap',
        str(base / 'recorded-evidence.spec.cjs'), str(base / 'recorded-archive.spec.cjs'),
        str(base / 'recorded-workflow.spec.cjs')], child_environment=child_environment)
    lines = (root / (label + '-tests.stdout.log')).read_text().splitlines()
    for line in ['# tests 34', '# pass 34', '# fail 0', '# skipped 0', '# cancelled 0']:
        assert line in lines, (label, line)
    execute(label + '-gate', [node, str(base / 'row-isolation-evidence.cjs'),
        str(baseline), str(fixtures / 'row-archive')], expected_exit=1)
    gate = json.loads((root / (label + '-gate.stdout.log')).read_bytes())
    assert gate['verified'] and gate['accepted'] is False and gate['measurementExecuted'] is False
    assert [entry['processes'] for entry in gate['results']] == [1024, 1024]
    assert sum(entry['measuredDurations'] for entry in gate['results']) == 18432
    results.append({'node': version, 'tests': 34, 'passed': 34, 'skipped': 0,
                    'actualGateExitCode': 1, 'actualGateVerified': True, 'actualGateAccepted': False})
for name, entry in sources.items():
    raw = (repository / name).read_bytes()
    assert len(raw) == entry['bytes'] and hashlib.sha256(raw).hexdigest() == entry['sha256']
for entry in frozen['files']:
    raw = (repository / entry['path']).read_bytes()
    assert len(raw) == entry['bytes'] and hashlib.sha256(raw).hexdigest() == entry['sha256']
(root / 'receipt.json').write_text(json.dumps({'complete': True, 'results': results,
    'legacyNode22': {'tests': 43, 'passed': 43, 'skipped': 0}, 'frozen415Unchanged': True,
    'sourcesUnchanged': True, 'actionlintPassed': True, 'measurementExecuted': False,
    'performanceAccepted': False, 'sourceSnapshots': sources, 'steps': records}, indent=2) + '\n')
print(json.dumps({'complete': True, 'root': str(root), 'results': results, 'measurementExecuted': False}), flush=True)
