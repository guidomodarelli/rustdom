"""Preserve terminal workflow qualification outputs without duplicating immutable large input corpora."""
import hashlib
import json
import pathlib
import shutil
import tarfile
import tempfile

repository = pathlib.Path(__file__).resolve().parent.parent
cache = repository / '.cache'
marker = json.loads((cache / 'recorded-workflow-path-fix-qualification.started.json').read_bytes())
root = pathlib.Path(marker['root'].replace('/mnt/c/', 'C:/', 1))
receipt = json.loads((root / 'receipt.json').read_bytes())
assert receipt['complete'] and receipt['sourcesUnchanged'] and receipt['frozen415Unchanged']
assert receipt['actionlintPassed'] and receipt['measurementExecuted'] is False and receipt['performanceAccepted'] is False
assert receipt['results'] == [
    {'node': 'v22.12.0', 'tests': 34, 'passed': 34, 'skipped': 0,
     'actualGateExitCode': 1, 'actualGateVerified': True, 'actualGateAccepted': False},
    {'node': 'v24.14.1', 'tests': 34, 'passed': 34, 'skipped': 0,
     'actualGateExitCode': 1, 'actualGateVerified': True, 'actualGateAccepted': False},
]
sources = json.loads((root / 'sources.json').read_bytes())
for name, expected in sources.items():
    raw = (repository / name).read_bytes()
    assert len(raw) == expected['bytes'] and hashlib.sha256(raw).hexdigest() == expected['sha256'], name
shared = json.loads((repository / 'reports/validation/native-class-ownership/recorded-evidence/source-manifest.json').read_bytes())['files']
for name, expected in shared.items():
    raw = (repository / 'reports/benchmarks/native-class-ownership' / name).read_bytes()
    assert len(raw) == expected['bytes'] and hashlib.sha256(raw).hexdigest() == expected['sha256'], name
output = repository / 'reports/validation/native-class-ownership/recorded-ownership-workflow'
assert not output.exists()
stage = pathlib.Path(tempfile.mkdtemp(prefix='recorded-workflow-publication-', dir=cache))


def copy_logs(source, destination):
    """Keep every root receipt/log and qualified source snapshot, excluding derived input trees."""
    destination.mkdir(parents=True)
    for filename in source.iterdir():
        if filename.is_file():
            shutil.copyfile(filename, destination / filename.name)
    if (source / 'sources').is_dir():
        shutil.copytree(source / 'sources', destination / 'sources')


copy_logs(root, stage / 'qualified')
for label in ['node-22', 'node-24']:
    fixture = root / (label + '-fixtures')
    preserved = stage / 'qualified' / (label + '-fixtures')
    preserved.mkdir()
    for filename in fixture.glob('*.json'):
        shutil.copyfile(filename, preserved / filename.name)
    for directory in ['commands', 'evidence-output', 'transport-output']:
        assert (fixture / directory).is_dir()
        shutil.copytree(fixture / directory, preserved / directory)
    for directory in ['row-archive', 'seeded-archive']:
        (preserved / directory).mkdir()
        for filename in (fixture / directory).glob('*.json'):
            shutil.copyfile(filename, preserved / directory / filename.name)
previous_marker = json.loads((cache / 'recorded-workflow-qualification.started.json').read_bytes())
previous = pathlib.Path(previous_marker['root'].replace('/mnt/c/', 'C:/', 1))
copy_logs(previous, stage / 'historical-relative-path-candidate')
old_commands = previous / 'node-22-fixtures/commands'
if old_commands.is_dir():
    shutil.copytree(old_commands, stage / 'historical-relative-path-candidate/node-22-fixtures/commands')
for name in ['recorded-workflow-qualification.started.json', 'recorded-workflow-path-fix-qualification.started.json']:
    shutil.copyfile(cache / name, stage / name)
shutil.copyfile(__file__, stage / pathlib.Path(__file__).name)
(stage / 'large-inputs.json').write_bytes((json.dumps({
    'omittedOnlyDerivedInputs': ['baseline/', 'node-22-fixtures/extracted/', 'node-24-fixtures/extracted/',
        'node-22-fixtures/*-candidate/', 'node-24-fixtures/*-candidate/',
        'node-22-fixtures/*-archive/study.tar.gz', 'node-24-fixtures/*-archive/study.tar.gz'],
    'immutableCorpora': ['reports/benchmarks/native-class-ownership/row-isolation-results/2026-10-22/',
        'reports/benchmarks/native-class-ownership/seeded-pre-gc-results/2026-10-22/'],
    'baseline': 'checkpoint-067-xml-serializer-controller; original Git source tar is included.',
    'allTestAndGateOutputsIncluded': True, 'newPerformanceSamples': False,
    'reconstruction': 'Use the published prepare-recorded-fixtures.py CLI and retarget only filesystem paths/output directories for the host.'
}, indent=2) + '\n').encode())
entries = {}
for filename in sorted(stage.rglob('*')):
    assert not filename.is_symlink()
    if filename.is_file():
        raw = filename.read_bytes()
        entries[filename.relative_to(stage).as_posix()] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
output.mkdir(parents=True)
archive = output / 'qualification.tar.gz'
with tarfile.open(archive, 'w:gz') as stream:
    stream.add(stage, arcname='recorded-ownership-workflow')
actual = {}
with tarfile.open(archive) as stream:
    for member in stream:
        assert member.isdir() or member.isfile()
        if member.isfile():
            actual[member.name.removeprefix('recorded-ownership-workflow/')] = {
                'bytes': member.size, 'sha256': hashlib.sha256(stream.extractfile(member).read()).hexdigest()}
assert actual == entries
(output / 'raw-files.json').write_bytes((json.dumps(entries, indent=2) + '\n').encode())
(output / 'source-manifest.json').write_bytes((json.dumps({'files': sources,
    'sharedQualifiedImplementation': shared, 'frozen415Unchanged': True}, indent=2) + '\n').encode())
result = {'complete': True, 'results': receipt['results'], 'legacyNode22': receipt['legacyNode22'],
    'legacyResultsReusedWithoutRerun': True, 'actionlintPassed': True, 'frozen415Unchanged': True,
    'archiveFiles': len(entries), 'archiveBytes': archive.stat().st_size,
    'archiveSha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'archiveReadbackMatched': True,
    'allTestAndGateOutputsIncluded': True, 'measurementExecuted': False, 'performanceAccepted': False}
(output / 'receipt.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
(output / 'README.md').write_bytes('''# Integración del replay actual de ownership en CI

Los34contratos pasaron en Node22.12.0 y24.14.1: los28del verificador/transporte
y seis del binding público y preparación por CLI. Ambos gates reales terminaron
exit1 con verified=true y accepted=false; conservan los siete controles jsdom
rechazados. Esta calificación comprueba el flujo real y ese fallo esperado;
el workflow exige aceptación y no remapea el rechazo a éxito.

Actionlint pasó. Las seis fuentes y las nueve dependencias calificadas antes
coinciden con los snapshots; las415fuentes del método medido siguen intactas.
Los43contratos históricos Node22 se reutilizan desde el intento previo terminado
porque ese código no cambió; sus logs y el recibo de reutilización se conservan.

La revisión detectó variables de fixtures relativas incompatibles con hijos que
cambian cwd. El candidato incompleto se detuvo en su grupo propio, se preservó
y se corrigieron ambas rutas con github.workspace. La calificación definitiva
utiliza esas rutas absolutas y outputs nuevos. No se interrumpió ni repitió un
sampler de rendimiento.

El tar incluye todos los logs, outputs JSON, procesos, fuentes, declaraciones de
fixtures, baseline Git y antecedentes. Solo omite copias grandes de inputs ya
publicados en los dos archivos inmutables; large-inputs.json documenta su
reconstrucción. Las rutas absolutas son las del host original: adaptar rutas y
usar salidas nuevas al reproducir, conservando los mismos bytes y políticas.

El CI remoto de la integración debe verificarse sobre su SHA publicado. Estos
recibos locales no aceptan rendimiento, no equivalen a aprobación GitHub ni
agregan implementación Rust. XMLSerializer conserva su seguimiento separado.
'''.encode())
files = {}
for filename in sorted(output.iterdir()):
    raw = filename.read_bytes()
    files[filename.name] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
(output / 'files.json').write_bytes((json.dumps(files, indent=2) + '\n').encode())
(cache / 'recorded-workflow-publication.json').write_bytes((json.dumps({**result, 'stage': str(stage)}, indent=2) + '\n').encode())
print(json.dumps(result))
