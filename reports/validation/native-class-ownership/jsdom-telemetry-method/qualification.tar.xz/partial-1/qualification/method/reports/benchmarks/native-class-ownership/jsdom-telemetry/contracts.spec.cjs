/** @file Checks real diagnostic processes and the reader/orchestrator boundaries, without mock platform libraries. */
'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createHash } = require('node:crypto');
const { plan, execute, validateReport } = require('./run.cjs');
const { analyzeProcess, pointMembership } = require('./analyze.cjs');
const policy = require('./constants/protocol.json');
const settings = require('../constants/current-ownership.cjs');
const qualification = process.env.RUSTDOM_JSDOM_TELEMETRY_QUALIFICATION;
assert.ok(qualification, 'Provide the completed real qualification directory');
const index = JSON.parse(fs.readFileSync(path.join(qualification, 'index.json'), 'utf8'));
const digest = (filename) => createHash('sha256').update(fs.readFileSync(filename)).digest('hex');

test('the declared diagnostic contains every row and both physical labels at both fixed positions', () => {
  for (const nodeIndex of [0, 1]) {
    const capture = plan(nodeIndex, 'capture');
    assert.equal(capture.length, 32);
    for (const position of policy.positions) for (const label of settings.labels) {
      assert.deepEqual(capture.filter((entry) => entry.position === position && entry.label === label)
        .map((entry) => entry.rowIndex).sort((left, right) => left - right), Array.from({ length: 8 }, (unused, row) => row));
    }
    assert.equal(plan(nodeIndex, 'qualification').length, 16);
  }
});

test('all real qualified jsdom workloads retain public outputs, exact spans, CPU/GC/JIT and finite release', () => {
  assert.equal(index.mode, 'qualification'); assert.equal(index.complete, true); assert.equal(index.accepted, null);
  assert.equal(index.processes.length, 32);
  let spans = 0; let windows = 0; let documents = 0;
  for (const entry of index.processes) {
    assert.equal(entry.exitCode, 0);
    for (const [filename, expected] of Object.entries(entry.files)) assert.equal(digest(path.join(entry.directory, filename)), expected);
    const report = JSON.parse(fs.readFileSync(path.join(entry.directory, 'report.json'), 'utf8'));
    validateReport(report, index.manifest, entry.input);
    assert.equal(Object.hasOwn(report, 'nativeBaseline'), false);
    const result = analyzeProcess(entry.directory);
    assert.equal(result.accepted, null); assert.equal(result.gateReevaluated, false);
    assert.equal(result.spans.length, 12); assert.ok(result.cpuProfileTicks > 0);
    assert.ok(result.totalGcEvents > 0); assert.ok(result.jitRecordCounts.function > 0);
    assert.ok(result.spans.every((span) => span.durationMs > 0 && span.cpuUserUs >= 0 && span.cpuSystemUs >= 0));
    assert.deepEqual(result, JSON.parse(fs.readFileSync(path.join(entry.directory, 'analysis.json'), 'utf8')));
    spans += result.spans.length; windows += result.trackedOwners.window; documents += result.trackedOwners.document;
  }
  assert.equal(spans, 384); assert.equal(windows, 384); assert.equal(documents, 384);
});

test('point attribution is half-open and preserves uncertainty instead of forcing a certain intersection', () => {
  const span = { startMs: 1, durationMs: 1 };
  assert.deepEqual(pointMembership(1000, span, { min: 0, max: 0 }), { guaranteed: true, possible: true });
  assert.deepEqual(pointMembership(2000, span, { min: 0, max: 0 }), { guaranteed: false, possible: false });
  assert.deepEqual(pointMembership(999, span, { min: 0, max: 2 }), { guaranteed: false, possible: true });
  assert.deepEqual(pointMembership(1999, span, { min: 0, max: 2 }), { guaranteed: false, possible: true });
  assert.deepEqual(pointMembership(3000, span, { min: 0, max: 2 }), { guaranteed: false, possible: false });
});

test('a real failed child is retained and prevents the next child from running', (context) => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'rustdom-jsdom-telemetry-contract-'));
  context.after(() => {
    assert.equal(path.dirname(fs.realpathSync(root)), fs.realpathSync(os.tmpdir())); fs.rmSync(root, { recursive: true });
  });
  const commands = [7, 0].map((code, position) => ({ directory: path.join(root, String(position)),
    input: { position, label: 'A', rowIndex: 0 }, argv: [process.execPath, '-e', `process.exit(${code})`] }));
  const record = { processes: [], accepted: null };
  assert.throws(() => execute(commands, record, root, () => {}), /failed process/);
  assert.equal(record.processes.length, 1); assert.equal(record.processes[0].exitCode, 7);
  assert.ok(record.processes[0].files['stdout.log']); assert.equal(fs.existsSync(commands[1].directory), false);
});

test('existing output and its user file are never overwritten by a worker', (context) => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'rustdom-jsdom-telemetry-contract-'));
  context.after(() => {
    assert.equal(path.dirname(fs.realpathSync(root)), fs.realpathSync(os.tmpdir())); fs.rmSync(root, { recursive: true });
  });
  const sentinel = path.join(root, 'sentinel'); fs.writeFileSync(sentinel, 'preserved');
  const record = { processes: [] };
  assert.throws(() => execute([{ directory: root, argv: [process.execPath, '-e', 'process.exit(0)'] }], record, root, () => {}), /EEXIST/);
  assert.equal(fs.readFileSync(sentinel, 'utf8'), 'preserved'); assert.equal(record.processes.length, 0);
});
