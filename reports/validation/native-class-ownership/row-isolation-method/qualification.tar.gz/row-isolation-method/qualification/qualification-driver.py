"""Qualify a frozen row-isolation method with actual official DOM packages."""
import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import tempfile
import time

repository = pathlib.Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom')
prior = pathlib.Path('/tmp/rustdom-seeded-pre-gc-study-4zryergi')
preparation = pathlib.Path('/tmp/rustdom-ownership-results-m7jq3638/independent-order/prepared/ownership-build')
nodes = {
    'node-22': ('/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node-22/bin/node', 'v22.12.0'),
    'node-24': ('/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node/bin/node', 'v24.14.1'),
}
assert (prior / 'verification.exit-code').read_text().strip() == '0'
for label in nodes:
    process = json.loads((prior / (label + '.process.json')).read_text())
    assert process['exitCode'] == 1
    assert not pathlib.Path('/proc', str(process['pid'])).exists()
    index = json.loads((prior / label / 'index.json').read_text())
    assert index['complete'] is True and index['accepted'] is False

marker = repository / '.cache/row-isolation-method-root.txt'
with marker.open('x') as output:
    root = pathlib.Path(tempfile.mkdtemp(prefix='rustdom-row-isolation-method-'))
    output.write(str(root) + '\n')
print('ROOT ' + str(root), flush=True)

environment = dict(os.environ)
environment.pop('NODE_OPTIONS', None)
command = [nodes['node-24'][0], '-e',
           "process.stdout.write(JSON.stringify(require('./reports/benchmarks/native-class-ownership/row-isolation-experiment.cjs').captureHarness()))"]
harness = json.loads(subprocess.check_output(command, cwd=repository, env=environment))
for entry in harness['files']:
    raw = (repository / entry['path']).read_bytes()
    assert len(raw) == entry['bytes'] and hashlib.sha256(raw).hexdigest() == entry['sha256']
    destination = root / 'harness' / entry['path']
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(raw)
(root / 'source-manifest.json').write_text(json.dumps(harness, indent=2) + '\n')
shutil.copyfile(__file__, root / 'qualification-driver.py')
receipt = {'complete': False, 'performanceAcceptance': None, 'root': str(root),
           'commands': [], 'startedAt': time.time(), 'newStudyExecuted': False}

def save():
    (root / 'qualification.json').write_text(json.dumps(receipt, indent=2) + '\n')

save()
for label, (node, version) in nodes.items():
    directory = root / label
    directory.mkdir()
    (directory / 'workers').mkdir()
    local = dict(environment)
    local.update({'RUSTDOM_HOSTED_BUILD_ARCHIVE': str(preparation),
                  'RUSTDOM_PRIOR_SEEDED_ARCHIVE': str(prior),
                  'RUSTDOM_ROW_ISOLATION_TEST_OUTPUT': str(directory / 'workers')})
    for name, arguments in [('version', ['--version']), ('contracts', ['--test', '--test-reporter=tap',
            'reports/benchmarks/native-class-ownership/row-isolation.spec.cjs'])]:
        record = {'command': [node, *arguments], 'cwd': str(root / 'harness'),
                  'environment': {key: value for key, value in local.items() if key.startswith('RUSTDOM_')},
                  'startedAt': time.time(), 'stdout': label + '/' + name + '.stdout.log',
                  'stderr': label + '/' + name + '.stderr.log'}
        receipt['commands'].append(record)
        save()
        with (root / record['stdout']).open('xb') as stdout, (root / record['stderr']).open('xb') as stderr:
            child = subprocess.Popen(record['command'], cwd=root / 'harness', env=local, stdout=stdout, stderr=stderr)
            record['pid'] = child.pid
            save()
            print('START ' + label + '/' + name + ' pid=' + str(child.pid), flush=True)
            record['exitCode'] = child.wait()
            record['finishedAt'] = time.time()
            save()
        print('END ' + label + '/' + name + ' exit=' + str(record['exitCode']), flush=True)
        assert record['exitCode'] == 0
        if name == 'version':
            assert (root / record['stdout']).read_text().strip() == version

for entry in harness['files']:
    for base in [repository, root / 'harness']:
        raw = (base / entry['path']).read_bytes()
        assert len(raw) == entry['bytes'] and hashlib.sha256(raw).hexdigest() == entry['sha256'], entry['path']
receipt['complete'] = True
receipt['finishedAt'] = time.time()
save()
print('COMPLETE: both Nodes qualified; no performance acceptance study executed', flush=True)
