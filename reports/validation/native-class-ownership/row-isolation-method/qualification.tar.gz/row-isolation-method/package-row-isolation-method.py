"""Archive completed qualification without recollecting or accepting timings."""
import hashlib
import json
import pathlib
import shutil
import tarfile
import tempfile

repository = pathlib.Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom')
root = pathlib.Path('/tmp/rustdom-row-isolation-method-njkwwg5f')
output = repository / 'reports/validation/native-class-ownership/row-isolation-method'
assert not output.exists()
qualification = json.loads((root / 'qualification.json').read_text())
harness = json.loads((root / 'source-manifest.json').read_text())
assert qualification['complete'] and qualification['performanceAcceptance'] is None
assert all(command['exitCode'] == 0 for command in qualification['commands'])
for entry in harness['files']:
    for base in [repository, root / 'harness']:
        raw = (base / entry['path']).read_bytes()
        assert len(raw) == entry['bytes'] and hashlib.sha256(raw).hexdigest() == entry['sha256'], entry['path']
observations = {}
for label in ['node-22', 'node-24']:
    log = (root / label / 'contracts.stdout.log').read_text().splitlines()
    for expected in ['# tests 12', '# pass 12', '# fail 0', '# cancelled 0', '# skipped 0']:
        assert expected in log, (label, expected)
    reports = []
    for prefix in ['isolated-', 'unpartitioned-']:
        for path in (root / label / 'workers').glob(prefix + '*.json'):
            if not path.name.endswith('.process.json'):
                report = json.loads(path.read_text())
                assert report['complete']
                reports.append(report)
    assert len(reports) == 42
    batches = [batch for report in reports for batch in report['batches']]
    assert len(batches) == 56 and sum(len(batch['samplesMs']) for batch in batches) == 504
    for batch in batches:
        assert batch['complete']
        for endpoint in batch['cleanupTrace'][-2:]:
            assert endpoint['clear'] and endpoint['survivors'] == {'window': 0, 'document': 0}
    owners = {kind: sum(report['batches'][-1]['trackedOwners'][kind] for report in reports)
              for kind in ['window', 'document']}
    assert owners == {'window': 672, 'document': 672}
    observations[label] = {'node': reports[0]['node'], 'completeWorkers': len(reports),
                           'batches': len(batches), 'functionalDurationsNotBudgetEvidence': 504,
                           'observedOwners': owners, 'requiredFinalEndpointsClear': True}

bundle = pathlib.Path(tempfile.mkdtemp(prefix='rustdom-row-isolation-qualification-evidence-'))
shutil.copytree(root, bundle / 'qualification')
launchers = bundle / 'launchers'
launchers.mkdir()
launchers_sha = {}
for name in ['run-row-isolation-study.py', 'authenticate-row-isolation.py']:
    raw = (repository / '.cache' / name).read_bytes()
    (launchers / name).write_bytes(raw)
    launchers_sha[name] = hashlib.sha256(raw).hexdigest()
shutil.copyfile(__file__, bundle / 'package-row-isolation-method.py')
entries = {path.relative_to(bundle).as_posix(): {'bytes': path.stat().st_size,
           'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
           for path in sorted(bundle.rglob('*')) if path.is_file()}
output.mkdir()
archive = output / 'qualification.tar.gz'
with tarfile.open(archive, 'w:gz') as stream:
    stream.add(bundle, arcname='row-isolation-method')
actual = {}
with tarfile.open(archive) as stream:
    for member in stream:
        if member.isfile():
            actual[member.name.removeprefix('row-isolation-method/')] = {'bytes': member.size,
                'sha256': hashlib.sha256(stream.extractfile(member).read()).hexdigest()}
assert actual == entries
(output / 'raw-files.json').write_text(json.dumps(entries, indent=2) + '\n')
shutil.copyfile(root / 'source-manifest.json', output / 'source-manifest.json')
receipt = {'qualification': qualification, 'observations': observations,
           'harnessSha256': harness['sha256'], 'sourceFiles': len(harness['files']),
           'launchersSha256': launchers_sha, 'archiveBytes': archive.stat().st_size,
           'archiveSha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
           'rawFiles': len(entries), 'archiveReadbackMatched': True,
           'newStudyExecuted': False, 'performanceAccepted': None}
(output / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
memory = {'scenario': 'row-isolation-method-qualification', 'observations': observations,
          'newStudyExecuted': False, 'peakMemoryMeasured': False,
          'universalLeakFreedomClaimed': False}
(repository / 'reports/memory/native-class-ownership-row-isolation-method-2026-10-22.json').write_text(
    json.dumps(memory, indent=2) + '\n')
print(json.dumps({key: value for key, value in receipt.items() if key not in ['qualification']}), flush=True)
