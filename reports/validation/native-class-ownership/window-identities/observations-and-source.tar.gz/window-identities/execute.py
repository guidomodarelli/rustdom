import hashlib,json,pathlib,shutil,subprocess,tempfile
repo=pathlib.Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom')
base=pathlib.Path('/tmp/rustdom-ownership-results-m7jq3638/independent-order')
output=pathlib.Path(tempfile.mkdtemp(prefix='rustdom-window-identities-qualified-'))
(repo/'.cache/window-identities-qualified-root.txt').write_text(str(output)+'\n')
shutil.copyfile(__file__,output/'execute.py')
initial=pathlib.Path((repo/'.cache/window-identities-root.txt').read_text().strip())
shutil.copytree(initial,output/'initial-probe')
shutil.copyfile(repo/'.cache/inspect-window-identities.cjs',output/'initial-probe/source.cjs')
method=repo/'reports/benchmarks/native-class-ownership/window-identities'
shutil.copytree(method,output/'method')
manifest=json.loads(pathlib.Path('/tmp/rustdom-sampler-diagnostics-final-tktpjoet/manifest.json').read_bytes())
published=json.loads((repo/'reports/benchmarks/native-class-ownership/independent-order/39735778846/published-source-manifest.json').read_bytes())
summary={'measurementExecuted':False,'acceptanceChanged':False,'probeCliInvocations':0,'windows':0,'runs':[],'sourceFiles':{item.relative_to(method).as_posix():hashlib.sha256(item.read_bytes()).hexdigest() for item in method.rglob('*') if item.is_file()}}
def run(name,argv,expected=0):
    child=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (output/(name+'.stdout.log')).write_bytes(child.stdout);(output/(name+'.stderr.log')).write_bytes(child.stderr)
    (output/(name+'-process.json')).write_text(json.dumps({'argv':argv,'exitCode':child.returncode,'expectedExitCode':expected},indent=2)+'\n')
    assert child.returncode==expected,(name,child.stderr.decode(errors='replace'))
    return child.stdout
for ordinal,node in enumerate(['/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node-22/bin/node','/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node/bin/node']):
    for entry in published['files']:
        content=(base/'node-22/harness'/entry['path']).read_bytes()
        assert len(content)==entry['bytes'] and hashlib.sha256(content).hexdigest()==entry['sha256']
    helper=str(base/'node-22/harness/reports/benchmarks/native-class-ownership/hosted-main-experiment.cjs')
    preparation=[node,'-e','const study=require(process.argv[1]); process.stdout.write(JSON.stringify(study.inspectPreparation(process.argv[2])));',helper,str(base/'prepared/ownership-build')]
    before=json.loads(run(f'node-{ordinal}-preparation-before',preparation));assert before==manifest['preparationBefore']
    options=run(f'node-{ordinal}-v8-options',[node,'--v8-options']).decode()
    assert all(flag in options for flag in ['--trace-opt','--trace-deopt','--trace-deopt-verbose','--trace-file-names'])
    for physical in ['J0','J1']:
        root=manifest['copies'][physical]
        assert pathlib.Path(root).resolve()==(base/'prepared/ownership-build/packages'/physical).resolve()
        result=json.loads(run(f'node-{ordinal}-{physical}',[node,'--expose-gc',str(method/'probe.cjs'),root]))
        assert len(result['windows'])==12
        assert result['distinctFunctionIdentities']==dict(JSDOM=1,Object=1,Range=12,cloneRange=12,collapse=12,compareBoundaryPoints=12,createRange=12,startOffset=12)
        assert all(entry['objectIsHostIntrinsic'] for entry in result['windows'])
        summary['runs'].append({'node':result['node'],'physical':physical,'distinctFunctionIdentities':result['distinctFunctionIdentities']})
        summary['probeCliInvocations']+=1;summary['windows']+=len(result['windows'])
        print(result['node'],physical,'passed',flush=True)
    error=run(f'node-{ordinal}-missing-gc',[node,str(method/'probe.cjs'),manifest['copies']['J0']],1)
    assert not error
    assert 'run with --expose-gc' in (output/f'node-{ordinal}-missing-gc.stderr.log').read_text()
    after=json.loads(run(f'node-{ordinal}-preparation-after',preparation));assert after==before
for name,digest in summary['sourceFiles'].items():assert hashlib.sha256((method/name).read_bytes()).hexdigest()==digest
summary['preparationBeforeAfterMatched']=True;summary['frozenSourceFilesMatched']=len(published['files']);summary['controlledFailuresPassed']=2
(output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'root':str(output),'probeCliInvocations':summary['probeCliInvocations'],'windows':summary['windows']}),flush=True)
