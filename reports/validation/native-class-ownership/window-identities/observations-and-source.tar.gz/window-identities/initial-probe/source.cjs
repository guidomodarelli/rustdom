'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { collectGarbage } = require('../scripts/memory-endpoint.cjs');
const root = process.argv[2];
const api = require(root);
const identities = new WeakMap();
let nextId = 0;
function identity(value) {
  if (!identities.has(value)) identities.set(value, ++nextId);
  return identities.get(value);
}
function inspectWindow() {
  const dom = new api.JSDOM('<p>probe</p>');
  const weak = { window: new WeakRef(dom.window), document: new WeakRef(dom.window.document) };
  try {
    const { window } = dom;
    const range = window.document.createRange(); range.selectNodeContents(window.document.querySelector('p'));
    const clone = range.cloneRange(); clone.collapse(false);
    assert.equal(range.toString(), 'probe'); assert.equal(clone.compareBoundaryPoints(window.Range.START_TO_START, range), 1);
    return { weak, functions: Object.fromEntries(Object.entries({ JSDOM:api.JSDOM, Object:window.Object,
      Range:window.Range, cloneRange:window.Range.prototype.cloneRange, collapse:window.Range.prototype.collapse,
      compareBoundaryPoints:window.Range.prototype.compareBoundaryPoints, createRange:window.document.createRange,
      startOffset:Object.getOwnPropertyDescriptor(window.AbstractRange.prototype, 'startOffset').get }).map(([name,value])=>[name,identity(value)])),
      objectIsHostIntrinsic:window.Object===Object };
  } finally { dom.window.close(); }
}
(async()=> {
  const windows=[];
  for(let ordinal=0; ordinal<12; ordinal++) {
    const observation=inspectWindow();
    const cleanup=[];
    for(let round=0; round<3; round++) {
      await collectGarbage();
      cleanup.push({window:observation.weak.window.deref()!==undefined,document:observation.weak.document.deref()!==undefined});
    }
    assert.ok(cleanup.slice(-2).every((state)=>!state.window&&!state.document));
    windows.push({ordinal,functions:observation.functions,objectIsHostIntrinsic:observation.objectIsHostIntrinsic,cleanup});
  }
  const counts=Object.fromEntries(Object.keys(windows[0].functions).map((name)=>[name,new Set(windows.map((entry)=>entry.functions[name])).size]));
  process.stdout.write(JSON.stringify({node:process.version,jsdom:JSON.parse(fs.readFileSync(path.join(root,'package.json'))).version,
    windows,distinctFunctionIdentities:counts,measurementExecuted:false,acceptanceChanged:false},null,2)+'\n');
})().catch((error)=>{process.stderr.write(error.stack+'\n');process.exitCode=1;});
