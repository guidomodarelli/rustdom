# Preparación de paquetes para un contraste posterior en GitHub

Esta receta construye y verifica paquetes, sin medir rendimiento ni conceder
aceptación. El estudio C anterior y el ensayo hosted antiguo mantienen sus
resultados negativos. No se relanzan.

El siguiente contraste deberá declarar por separado su hipótesis, método,
paquetes exactos y condiciones del host antes de medir. El antecedente hosted
usaba afinidad de todos los hilos; el método completo actual fija solo el principal.
Preparar paquetes en CI no demuestra por sí mismo que ese cambio estabilice
el control jsdom ni resuelva su calibración.

Esta preparación utiliza fuentes completas de checkpoint067 y C, con la identidad
canónica e inputs raíz comprobados antes/después. Exige dist ausente antes de
construir. Registra Node24.14.1, npm11.11.0, Rust1.99.1, linker, compilador C,
glibc2.35, hardware, comandos, logs y resultados. Rechaza overrides heredados
de compilación no declarados. Se instala mediante npm ci --omit=dev y se ejecuta
el build real de cada raíz. Las herramientas de pruebas se validan en el CI general.

Se conservan fuentes A/C, inputs adicionales de build, arnés y preparación.
Se copian físicamente A0/A1/C/J0/J1 y todas las dependencias instaladas del
candidato, con huellas por archivo. Los enlaces a dependencias son relativos;
el tar mantiene sus symlinks para poder mover el archivo. El verificador recalcula
fuentes, logs, distribuciones, binarios nativos y dependencias sin lanzar cargas.

Las pruebas funcionales posteriores ejercen parsing, mutación, clonación, Range,
eventos, Unicode e independencia de asignaciones nativas en los cinco paquetes.
Observan Window y Document por separado y exigen dos endpoints claros y baselines
nativos exactos. Son pruebas finitas, no benchmarks ni evidencia de memoria pico.

Una preparación falla si cambian fuentes, herramientas declaradas, paquetes o
inputs durante el build. Los errores preservan logs y estado parcial; no se
sobrescribe un output existente ni se modifica una referencia congelada previa.
El artefacto oficial deberá autenticarse y fijarse antes de usar sus paquetes
en una futura receta de medición. No se adopta automáticamente como baseline.
