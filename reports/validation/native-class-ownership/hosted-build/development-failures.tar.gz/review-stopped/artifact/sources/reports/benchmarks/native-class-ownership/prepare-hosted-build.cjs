/** @file Builds complete immutable A/C packages before declaring another hosted timing experiment. */
'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { createHash } = require('node:crypto');
const { spawnSync } = require('node:child_process');
const { captureSourceIdentity } = require('../../../benchmarks/sources.cjs');
const { verifyCurrentInputs } = require('./ownership-evidence.cjs');
const study = require('./paired-inline-experiment.cjs');
const { fingerprint } = require('./paired-experiment.cjs');
const settings = require('./constants/hosted-build.cjs');
const repositoryRoot = path.resolve(__dirname, '../../..');

/** @param {Buffer} bytes - Actual file contents. @returns {string} Portable digest. */
function hash(bytes) { return createHash('sha256').update(bytes).digest('hex'); }

/** Reject inherited overrides before creating outputs, installing dependencies or invoking compilers. */
function inspectTools() {
  assert.equal(process.version, settings.node, 'Hosted build: undeclared build Node');
  assert.equal(process.platform, settings.platform); assert.equal(process.arch, settings.arch);
  assert.equal(process.report.getReport().header.glibcVersionRuntime, settings.glibc);
  for (const name of settings.forbiddenEnvironment) assert.ok(!process.env[name], `Hosted build: undeclared ${name}`);
  for (const name of Object.keys(process.env)) {
    if (settings.forbiddenEnvironmentPrefixes.some((prefix) => name.startsWith(prefix)) && name !== settings.allowedTargetEnvironment) {
      assert.ok(!process.env[name], `Hosted build: undeclared ${name}`);
    }
  }
  const tools = {};
  for (const [name, arguments_] of Object.entries({ npm: ['--version'], rustc: ['-Vv'], cargo: ['-V'], cc: ['--version'], ld: ['--version'] })) {
    const result = spawnSync(name, arguments_, { encoding: 'utf8', timeout: settings.commandTimeoutMs });
    if (result.error) throw new Error(`Hosted build: could not inspect ${name}`, { cause: result.error });
    assert.equal(result.status, 0, `Hosted build: ${name} version failed: ${result.stderr}`);
    tools[name] = { arguments: arguments_, stdout: result.stdout.trim(), stderr: result.stderr.trim() };
  }
  assert.equal(tools.npm.stdout, settings.npm, 'Hosted build: undeclared npm');
  assert.ok(tools.rustc.stdout.split('\n').includes(`release: ${settings.rustRelease}`), 'Hosted build: undeclared Rust');
  return { node: process.version, v8: process.versions.v8, executable: process.execPath,
    executableSha256: hash(fs.readFileSync(process.execPath)), tools,
    cargoTargetDirectory: process.env.CARGO_TARGET_DIR ?? null, rustupToolchain: process.env.RUSTUP_TOOLCHAIN ?? null };
}

/** Preserve exact build processes and their logs, including incomplete and failed attempts. */
function executeStep(root, output, index, label, step, save) {
  const prefix = `${label}-${step}`;
  const entry = { label, step, command: ['npm', ...settings.commands[step]], cwd: root,
    stdout: `${prefix}.stdout.log`, stderr: `${prefix}.stderr.log`, exitCode: null };
  index.commands.push(entry); save();
  const stdout = fs.openSync(path.join(output, entry.stdout), 'wx');
  const stderr = fs.openSync(path.join(output, entry.stderr), 'wx');
  let result;
  try { result = spawnSync('npm', settings.commands[step], { cwd: root, stdio: ['ignore', stdout, stderr], timeout: settings.commandTimeoutMs }); }
  finally { fs.closeSync(stdout); fs.closeSync(stderr); }
  Object.assign(entry, { exitCode: result.status, signal: result.signal, error: result.error?.message ?? null }); save();
  for (const name of [entry.stdout, entry.stderr]) index.files[name] = hash(fs.readFileSync(path.join(output, name)));
  save();
  assert.equal(result.status, 0, `Hosted build: inspect ${entry.stderr}`);
}

/** Recalculate every packaged byte after relocation, without loading a DOM or invoking build tools. */
function verify(outputArgument) {
  const output = path.resolve(outputArgument);
  const index = JSON.parse(fs.readFileSync(path.join(output, 'index.json'), 'utf8'));
  assert.equal(index.complete, true); assert.equal(index.measurementExecuted, false);
  assert.equal(index.performanceAccepted, null); assert.deepEqual(index.settings, settings);
  assert.deepEqual(index.inputsAfter, index.inputsBefore);
  assert.equal(index.tools.node, settings.node); assert.equal(index.tools.tools.npm.stdout, settings.npm);
  assert.ok(index.tools.tools.rustc.stdout.split('\n').includes(`release: ${settings.rustRelease}`));
  assert.deepEqual(index.commands.map(({ label, step, exitCode }) => ({ label, step, exitCode })),
    ['A', 'B'].flatMap((label) => ['install', 'build'].map((step) => ({ label, step, exitCode: 0 }))));
  for (const [name, expected] of Object.entries(index.files)) {
    const filename = path.resolve(output, name);
    assert.ok(filename.startsWith(`${output}${path.sep}`), 'Hosted build: file escapes archive');
    assert.equal(hash(fs.readFileSync(filename)), expected, `Hosted build: archived file changed: ${name}`);
  }
  assert.deepEqual(verifyCurrentInputs(path.join(output, 'baseline-sources'), path.join(output, 'sources')), index.inputsBefore);
  const candidateNames = [...new Set([...study.captureHarness(path.join(output, 'sources')).files.map((file) => file.path),
    ...settings.additionalBuildInputs, ...settings.preparationFiles])];
  const expectedFiles = [...new Set([...index.sourceProvenance.A.measuredSources, ...settings.additionalBuildInputs])]
    .map((name) => `baseline-sources/${name}`)
    .concat(candidateNames.map((name) => `sources/${name}`), index.commands.flatMap((entry) => [entry.stdout, entry.stderr]));
  assert.deepEqual(Object.keys(index.files).sort(), expectedFiles.sort());
  assert.deepEqual(fingerprint(output, ['dependencies']), index.dependencies);
  assert.deepEqual(Object.keys(index.distributions).sort(), ['A0', 'A1', 'B', 'J0', 'J1']);
  for (const [label, distribution] of Object.entries(index.distributions)) {
    const root = path.join(output, 'packages', label);
    assert.deepEqual(fingerprint(root, label.startsWith('J') ? ['lib', 'package.json'] : ['dist', 'package.json']), distribution);
    assert.equal(fs.realpathSync(path.join(root, 'node_modules')), fs.realpathSync(path.join(output, 'dependencies')));
    if (!label.startsWith('J')) {
      const metadata = JSON.parse(fs.readFileSync(path.join(root, 'dist/native-build.json')));
      assert.equal(metadata.binarySha256, hash(fs.readFileSync(path.join(root, 'dist/rustdom.node'))));
      assert.equal(metadata.platform, settings.platform); assert.equal(metadata.arch, settings.arch);
      assert.equal(metadata.node, settings.node); assert.equal(metadata.glibcBuildVersion, settings.glibc);
      const sources = label === 'B' ? 'sources' : 'baseline-sources';
      assert.equal(metadata.cargoLockSha256, hash(fs.readFileSync(path.join(output, sources, 'Cargo.lock'))));
    }
  }
  assert.equal(index.distributions.A0.sha256, index.distributions.A1.sha256);
  assert.equal(index.distributions.J0.sha256, index.distributions.J1.sha256);
  return { verified: true, measurementExecuted: false, performanceAccepted: null,
    inputs: index.inputsBefore, distributions: Object.fromEntries(Object.entries(index.distributions).map(([label, value]) => [label, value.sha256])),
    dependenciesSha256: index.dependencies.sha256 };
}

/**
 * Build once from fresh complete roots; preserve output and partial provenance on any failure.
 * @param {string} baselineArgument - Full checkpoint067 sources, with no existing dist directory.
 * @param {string} candidateArgument - Full C sources and unchanged measured harness, with no dist directory.
 * @param {string} outputArgument - New output directory that must not overlap either source root.
 * @returns {object} Verified package identities; performance remains undecided.
 */
function prepare(baselineArgument, candidateArgument, outputArgument) {
  const roots = { A: fs.realpathSync(baselineArgument), B: fs.realpathSync(candidateArgument) };
  const output = path.resolve(outputArgument);
  assert.equal(fs.existsSync(output), false, 'Hosted build: output already exists; preserve the previous preparation');
  assert.notEqual(roots.A, roots.B, 'Hosted build: independent source roots are required');
  for (const root of Object.values(roots)) {
    assert.ok(output !== root && !root.startsWith(`${output}${path.sep}`) && !output.startsWith(`${root}${path.sep}`),
      'Hosted build: output must not overlap either source root');
    assert.equal(fs.existsSync(path.join(root, 'dist')), false, 'Hosted build: dist must be absent before a fresh build');
  }
  const inputsBefore = verifyCurrentInputs(roots.A, roots.B);
  const tools = inspectTools();
  fs.mkdirSync(path.dirname(output), { recursive: true }); fs.mkdirSync(output);
  const index = { complete: false, measurementExecuted: false, performanceAccepted: null,
    startedAt: new Date().toISOString(), settings, roots, inputsBefore, tools, commands: [], files: {}, distributions: {},
    machine: { cpu: os.cpus()[0].model, logicalCpus: os.cpus().length, release: os.release(), totalMemoryBytes: os.totalmem() } };
  const save = () => fs.writeFileSync(path.join(output, 'index.json'), `${JSON.stringify(index, null, 2)}\n`);
  save();
  try {
    const harness = study.captureHarness(roots.B);
    index.sourceProvenance = { A: captureSourceIdentity(roots.A), B: captureSourceIdentity(roots.B) };
    for (const name of [...index.sourceProvenance.A.measuredSources, ...settings.additionalBuildInputs]) {
      const destination = path.join(output, 'baseline-sources', name);
      fs.mkdirSync(path.dirname(destination), { recursive: true }); fs.copyFileSync(path.join(roots.A, name), destination);
      index.files[`baseline-sources/${name}`] = hash(fs.readFileSync(destination));
    }
    const names = [...new Set([...harness.files.map((file) => file.path), ...settings.additionalBuildInputs, ...settings.preparationFiles])].sort();
    for (const name of names) {
      const source = settings.preparationFiles.includes(name) ? path.join(repositoryRoot, name) : path.join(roots.B, name);
      const destination = path.join(output, 'sources', name);
      fs.mkdirSync(path.dirname(destination), { recursive: true }); fs.copyFileSync(source, destination);
      index.files[`sources/${name}`] = hash(fs.readFileSync(destination));
    }
    save();
    for (const [label, root] of Object.entries(roots)) for (const step of ['install', 'build']) executeStep(root, output, index, label, step, save);
    index.inputsAfter = verifyCurrentInputs(roots.A, roots.B); assert.deepEqual(index.inputsAfter, inputsBefore);
    for (const name of settings.additionalBuildInputs) {
      assert.equal(hash(fs.readFileSync(path.join(roots.A, name))), index.files[`baseline-sources/${name}`],
        `Hosted build: baseline input changed during preparation: ${name}`);
    }
    for (const name of names) {
      const source = settings.preparationFiles.includes(name) ? path.join(repositoryRoot, name) : path.join(roots.B, name);
      assert.equal(hash(fs.readFileSync(source)), index.files[`sources/${name}`], `Hosted build: source changed during preparation: ${name}`);
    }
    fs.cpSync(path.join(roots.B, 'node_modules'), path.join(output, 'dependencies'), { recursive: true, dereference: true });
    index.dependencies = fingerprint(output, ['dependencies']);
    const reference = path.dirname(require.resolve('jsdom/package.json', { paths: [roots.B] }));
    assert.equal(JSON.parse(fs.readFileSync(path.join(reference, 'package.json'))).version, settings.referenceVersion);
    for (const [label, root] of Object.entries({ A0: roots.A, A1: roots.A, B: roots.B, J0: reference, J1: reference })) {
      const destination = path.join(output, 'packages', label); fs.mkdirSync(destination, { recursive: true });
      const parts = label.startsWith('J') ? ['lib', 'package.json'] : ['dist', 'package.json'];
      const original = fingerprint(root, parts);
      for (const part of parts) fs.cpSync(path.join(root, part), path.join(destination, part), { recursive: true });
      fs.symlinkSync('../../dependencies', path.join(destination, 'node_modules'), 'dir');
      index.distributions[label] = fingerprint(destination, parts); assert.deepEqual(index.distributions[label], original);
    }
    for (const entry of index.commands) for (const name of [entry.stdout, entry.stderr]) index.files[name] = hash(fs.readFileSync(path.join(output, name)));
    index.complete = true; index.finishedAt = new Date().toISOString(); save();
    return verify(output);
  } catch (error) { index.failure = { message: error.message, stack: error.stack }; save(); throw error; }
}

if (require.main === module) {
  try {
    const result = process.argv[2] === '--verify' ? verify(process.argv[3]) : prepare(...process.argv.slice(2));
    process.stdout.write(`${JSON.stringify(result)}\n`);
  } catch (error) { process.stderr.write(`${error.stack}\n`); process.exitCode = 2; }
}
module.exports = { inspectTools, prepare, verify };
