"""Reject changed real report/index payloads without remeasuring or altering preserved evidence."""
import hashlib
import json
import pathlib
import shutil
import subprocess
import sys
import tempfile
import time

repository = pathlib.Path(__file__).resolve().parent.parent
marker = json.loads((repository / '.cache/recorded-evidence-durable.started.json').read_bytes())
study = pathlib.Path(marker['nativeRoot']) / 'row-extracted/row-isolation/study'
index_bytes = (study / 'node-22/index.json').read_bytes()
index = json.loads(index_bytes)
first_report = index['runs'][0]['report']
producer = repository / '.cache/diagnose-row-isolation.py'
bound_output = repository / '.cache/row-isolation-diagnostics-bound.json'
before = hashlib.sha256(bound_output.read_bytes()).hexdigest()
bound = json.loads(bound_output.read_bytes())
assert bound['consumedFilesAuthenticated'] and len(bound['cells']) == 128
assert len(bound['consumedFiles']) == 2051
output = repository / '.cache/row-isolation-diagnostic-binding-qa'
output.mkdir()
shutil.copyfile(__file__, output / pathlib.Path(__file__).name)
shutil.copyfile(producer, output / producer.name)
cases = []
for kind in ['report', 'index']:
    root = pathlib.Path(tempfile.mkdtemp(prefix='diagnostic-binding-', dir=pathlib.Path.home() / 'rustdom-validation'))
    (root / 'node-22').mkdir()
    shutil.copyfile(study / 'verification.json', root / 'verification.json')
    (root / 'node-22/index.json').write_bytes(index_bytes)
    if kind == 'report':
        changed = json.loads((study / 'node-22' / first_report).read_bytes())
        changed['batches'][0]['samplesMs'][0] += 1
        (root / 'node-22' / first_report).write_text(json.dumps(changed) + '\n')
        expected = 'Preserved payload changed: node-22/' + first_report
    else:
        changed = json.loads(index_bytes)
        changed['machine']['cpu'] = 'tampered recorded hardware fixture'
        (root / 'node-22/index.json').write_text(json.dumps(changed) + '\n')
        expected = 'Preserved payload changed: node-22/index.json'
    command = [sys.executable, '-B', str(producer), '--preserved-study', str(root)]
    record = {'command': command, 'fixtureRoot': str(root), 'startedAt': time.time(), 'measurementExecuted': False}
    with (output / (kind + '.stdout.log')).open('xb') as stdout, (output / (kind + '.stderr.log')).open('xb') as stderr:
        child = subprocess.Popen(command, cwd=repository, stdout=stdout, stderr=stderr)
        record['pid'] = child.pid
        (output / (kind + '.process.json')).write_text(json.dumps(record, indent=2) + '\n')
        record['exitCode'] = child.wait()
    record['finishedAt'] = time.time()
    (output / (kind + '.process.json')).write_text(json.dumps(record, indent=2) + '\n')
    assert record['exitCode'] == 1
    assert (output / (kind + '.stdout.log')).read_bytes() == b''
    assert expected in (output / (kind + '.stderr.log')).read_text()
    assert hashlib.sha256(bound_output.read_bytes()).hexdigest() == before
    cases.append({'kind': kind, 'controlledRejection': expected, 'originalBoundResultUnchanged': True})
(output / 'receipt.json').write_text(json.dumps({'complete': True, 'cases': cases,
    'producerSha256': hashlib.sha256(producer.read_bytes()).hexdigest(), 'boundResultSha256': before,
    'positiveCaseAuthenticatedFiles': 2051, 'positiveCaseCells': 128, 'measurementExecuted': False}, indent=2) + '\n')
print(json.dumps({'complete': True, 'cases': len(cases), 'positiveAuthenticatedFiles': 2051,
                  'measurementExecuted': False}))
