import pathlib,json,hashlib
root=pathlib.Path('/tmp/rustdom-row-isolation-study-s_tqvw17'); raw=(root/'node-22/index.json').read_bytes(); index=json.loads(raw); process=json.loads((root/'node-22.process.json').read_bytes()); assert index['complete'] and process['exitCode']==1
bad=[];rust_bad=[]
for phase,rows in index['summaries'].items():
 for row in rows:
  if abs(row['jsdomControlChangePercent'])>index['settings']['controlBudgetPercent']:bad.append({'phase':phase,'key':row['key'],'jsdomControlChangePercent':row['jsdomControlChangePercent'],'rustdomChangePercent':row['rustdomChangePercent']})
  if (abs(row['rustdomChangePercent']) if phase=='AA' else row['rustdomChangePercent'])>index['settings']['rustBudgetPercent']:rust_bad.append({'phase':phase,'key':row['key'],'changePercent':row['rustdomChangePercent']})
print(json.dumps({'originalRoot':str(root),'indexSha256':hashlib.sha256(raw).hexdigest(),'node':index['node'],'complete':index['complete'],'accepted':index['accepted'],'parentExitCode':process['exitCode'],'workers':len(index['runs']),'allWorkersExit0':all(entry.get('exitCode')==0 and entry.get('signal') is None and entry.get('error') is None for entry in index['runs']),'harnessSha256':index['harness']['sha256'],'measuredCandidateSourceHash':index['harness']['identity']['sourceHash'],'failedJsdomRows':bad,'numericRustViolations':rust_bad,'summaries':index['summaries'],'scope':'Node22 terminal only; original Node24 is still active. No new measurement and no full-study acceptance.'}))
