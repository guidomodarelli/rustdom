"""Wait for the original process, then preserve and qualify its evidence exactly once."""
import hashlib
import json
import os
import pathlib
import subprocess
import sys
import tempfile
import time

if sys.flags.optimize:
    raise RuntimeError('Ownership CI followup: unset PYTHONOPTIMIZE before running guards')

repository = pathlib.Path(__file__).resolve().parent.parent
configuration = json.loads((repository / '.cache/constants/archive-row-isolation-study.json').read_bytes())
study = json.loads((repository / configuration['studyMarker']).read_bytes())
assert study['root'] == configuration['originalRoot'] and study['head'] == configuration['reviewedCommit']
marker = repository / '.cache/row-isolation-followup.started.json'
with marker.open('x') as destination:
    output = pathlib.Path(tempfile.mkdtemp(prefix='rustdom-row-isolation-ci-followup-'))
    json.dump({'pid': os.getpid(), 'root': str(output), 'originalStudy': study, 'startedAt': time.time()}, destination, indent=2)

helpers = ['archive-row-isolation-study.py', 'analyze-row-isolation.py', 'qualify-recorded-evidence.py',
           'finish-row-isolation-ci-evidence.py', 'constants/archive-row-isolation-study.json']
pins = {}
for relative in helpers:
    raw = (repository / '.cache' / relative).read_bytes()
    pins[relative] = hashlib.sha256(raw).hexdigest()
    snapshot = output / 'sources' / relative
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    snapshot.write_bytes(raw)
(output / 'sources.json').write_text(json.dumps(pins, indent=2) + '\n')
print(json.dumps({'pid': os.getpid(), 'root': str(output), 'waitingForOriginalDriver': study['driverPid']}), flush=True)

def driver_alive():
    """Observe the original command; never signal, restart or replace the measured driver."""
    directory = pathlib.Path('/proc') / str(study['driverPid'])
    try:
        command = (directory / 'cmdline').read_bytes().replace(b'\0', b' ')
        state = (directory / 'stat').read_text().split(') ', 1)[1].split()[0]
    except FileNotFoundError:
        return False
    return state != 'Z' and configuration['driverFilename'].encode() in command

while driver_alive():
    # A bounded sleeping interval uses no worker, parser, compression or DOM sampling.
    time.sleep(30)

for relative, expected in pins.items():
    assert hashlib.sha256((repository / '.cache' / relative).read_bytes()).hexdigest() == expected
steps = [
    ('terminal-guard', 'archive-row-isolation-study.py', ['--check-ready']),
    ('archive-original', 'archive-row-isolation-study.py', []),
    ('analyze-original', 'analyze-row-isolation.py', []),
    ('qualify-recorded-evidence', 'qualify-recorded-evidence.py', []),
]
records = []
for name, helper, arguments in steps:
    for relative, expected in pins.items():
        assert hashlib.sha256((repository / '.cache' / relative).read_bytes()).hexdigest() == expected
    command = [sys.executable, '-B', str(repository / '.cache' / helper), *arguments]
    record = {'name': name, 'command': command, 'cwd': str(repository),
              'startedAt': time.time(), 'measurementExecuted': False}
    with (output / (name + '.stdout.log')).open('xb') as stdout, (output / (name + '.stderr.log')).open('xb') as stderr:
        child = subprocess.Popen(command, cwd=repository, stdout=stdout, stderr=stderr)
        record['pid'] = child.pid
        (output / (name + '.process.json')).write_text(json.dumps(record, indent=2) + '\n')
        print(f'START {name} pid={child.pid}', flush=True)
        record['exitCode'] = child.wait()
    record['finishedAt'] = time.time()
    (output / (name + '.process.json')).write_text(json.dumps(record, indent=2) + '\n')
    print(f'END {name} exit={record["exitCode"]}', flush=True)
    records.append(record)
    assert record['exitCode'] == 0, f'Preserve {name} logs and inspect the failure; do not retry automatically'
(output / 'receipt.json').write_text(json.dumps({'complete': True, 'steps': records,
    'originalStudy': study, 'measurementExecuted': False, 'sourcesSha256': pins}, indent=2) + '\n')
print(json.dumps({'complete': True, 'root': str(output), 'measurementExecuted': False}), flush=True)
