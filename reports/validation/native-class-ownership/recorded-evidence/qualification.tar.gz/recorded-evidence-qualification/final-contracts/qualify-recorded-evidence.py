"""Qualify real archived-evidence contracts after the original study is terminal."""
import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import sys
import tempfile
import time

if sys.flags.optimize:
    raise RuntimeError('Recorded evidence qualification: unset PYTHONOPTIMIZE before checking guards')

repository = pathlib.Path(__file__).resolve().parent.parent
configuration = json.loads((repository / '.cache/constants/archive-row-isolation-study.json').read_bytes())
subprocess.run([sys.executable, '-B', str(repository / '.cache/archive-row-isolation-study.py'), '--check-ready'], check=True)
row_archive = repository / configuration['output']
row_receipt = json.loads((row_archive / 'receipt.json').read_bytes())
assert row_receipt['result']['verified'] and row_receipt['archiveReadbackMatched']
assert row_receipt['verificationOriginalAndRelocatedIdentical']
marker = repository / '.cache/recorded-evidence-qualification-root.txt'
with marker.open('x') as destination:
    root = pathlib.Path(tempfile.mkdtemp(prefix='rustdom-recorded-evidence-qualification-'))
    destination.write(str(root) + '\n')
print(json.dumps({'root': str(root), 'qualificationPid': os.getpid(), 'measurementExecuted': False}), flush=True)

relative_base = 'reports/benchmarks/native-class-ownership/'
names = ['constants/recorded-evidence.json', 'recorded-evidence.cjs', 'recorded-evidence-extract.py',
         'recorded-evidence-fixtures.py', 'recorded-evidence-contract-cli.cjs', 'recorded-evidence.spec.cjs']
sources = {}
for name in names:
    relative = relative_base + name
    raw = (repository / relative).read_bytes()
    target = root / 'sources' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    sources[relative] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
(root / 'sources.json').write_text(json.dumps(sources, indent=2) + '\n')
shutil.copyfile(__file__, root / pathlib.Path(__file__).name)
shutil.copyfile(repository / '.cache/constants/archive-row-isolation-study.json', root / 'archive-configuration.json')

prepared = pathlib.Path(configuration['preparedRoot'])
compiled_index = json.loads((prepared / 'index.json').read_bytes())
build_inputs = row_receipt['buildInputHashes']
baseline = root / 'baseline'
shutil.copytree(prepared / 'baseline-sources', baseline)
for name, expected in build_inputs['A'].items():
    filename = baseline / name
    assert (hashlib.sha256(filename.read_bytes()).hexdigest() if filename.is_file() else None) == expected

scenarios = []
for kind, original_root, archive, prefix, expected_files in [
    ('seeded', pathlib.Path('/tmp/rustdom-seeded-pre-gc-study-4zryergi'),
     repository / relative_base / 'seeded-pre-gc-results/2026-10-22', 'seeded-pre-gc', 409),
    ('rowIsolated', pathlib.Path(configuration['originalRoot']), row_archive, configuration['archivePrefix'], 415),
]:
    receipt = json.loads((archive / 'receipt.json').read_bytes())
    assert receipt['result']['verified'] and receipt['verificationOriginalAndRelocatedIdentical']
    assert receipt['archiveReadbackMatched']
    original_index = json.loads((original_root / 'node-22/index.json').read_bytes())
    assert len(original_index['harness']['files']) == expected_files
    assert original_index['complete']
    candidate = root / kind / 'candidate'
    candidate.mkdir(parents=True)
    for entry in original_index['harness']['files']:
        raw = (original_root / 'harness' / entry['path']).read_bytes()
        assert len(raw) == entry['bytes'] and hashlib.sha256(raw).hexdigest() == entry['sha256']
        target = candidate / entry['path']
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
    for name, expected in build_inputs['B'].items():
        filename = candidate / name
        if expected is None:
            assert not filename.exists()
            continue
        raw = (pathlib.Path(json.loads((repository / configuration['archiveMarker']).read_bytes())['bundle']) /
               'runtime-inputs/B' / name).read_bytes()
        assert hashlib.sha256(raw).hexdigest() == expected
        filename.parent.mkdir(parents=True, exist_ok=True)
        filename.write_bytes(raw)
    # Keep preserved datasets immutable; only sidecars live in this owned fixture directory.
    fixture_archive = root / kind / 'archive'
    fixture_archive.mkdir()
    for name in ['study.tar.gz', 'raw-files.json']:
        shutil.copyfile(archive / name, fixture_archive / name)
    compiled_manifest = prepared / 'sources/package.json'
    assert hashlib.sha256(compiled_manifest.read_bytes()).hexdigest() == compiled_index['files']['sources/package.json']
    shutil.copyfile(compiled_manifest, fixture_archive / 'compiled-package.json')
    assert hashlib.sha256((fixture_archive / 'study.tar.gz').read_bytes()).hexdigest() == receipt['archiveSha256']
    policy = {
        'archive': {'filename': 'study.tar.gz', 'sha256': receipt['archiveSha256']},
        'rawManifest': {'filename': 'raw-files.json', 'sha256': hashlib.sha256((fixture_archive / 'raw-files.json').read_bytes()).hexdigest()},
        'archivePrefix': prefix, 'nodeDirectories': ['study/node-22', 'study/node-24'],
        'sourceHashes': {'A': compiled_index['inputsBefore']['sources']['A'],
                         'B': original_index['harness']['identity']['sourceHash']},
        'compiledSourceHashes': compiled_index['inputsBefore']['sources'],
        'harnessSha256': original_index['harness']['sha256'], 'buildInputHashes': build_inputs,
        'compiledPackageManifest': 'compiled-package.json',
    }
    scenarios.append({'kind': kind, 'baselineRoot': str(baseline), 'candidateRoot': str(candidate),
                      'archiveRoot': str(fixture_archive), 'expectedAccepted': receipt['result']['accepted'], 'policy': policy})

assert scenarios[0]['expectedAccepted'] is False
environment = dict(os.environ)
environment.pop('NODE_OPTIONS', None)
results = []
for label, executable, expected in [
    ('node-22', '/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node-22/bin/node', 'v22.12.0'),
    ('node-24', configuration['nodeExecutable'], 'v24.14.1'),
]:
    version = subprocess.check_output([executable, '--version'], env=environment, text=True).strip()
    assert version == expected
    output = root / label
    output.mkdir()
    fixture = root / (label + '.fixture.json')
    fixture.write_text(json.dumps({'scenarios': scenarios, 'outputRoot': str(output)}, indent=2) + '\n')
    test_environment = dict(environment, RUSTDOM_RECORDED_EVIDENCE_FIXTURE=str(fixture))
    command = [executable, '--test', '--test-reporter=tap', str(repository / relative_base / 'recorded-evidence.spec.cjs')]
    record = {'command': command, 'cwd': str(repository), 'startedAt': time.time(),
              'node': version, 'fixture': str(fixture), 'measurementExecuted': False}
    with (root / (label + '.stdout.log')).open('xb') as stdout, (root / (label + '.stderr.log')).open('xb') as stderr:
        child = subprocess.Popen(command, cwd=repository, env=test_environment, stdout=stdout, stderr=stderr)
        record['pid'] = child.pid
        (root / (label + '.process.json')).write_text(json.dumps(record, indent=2) + '\n')
        print(f'START {label} pid={child.pid}', flush=True)
        record['exitCode'] = child.wait()
    record['finishedAt'] = time.time()
    (root / (label + '.process.json')).write_text(json.dumps(record, indent=2) + '\n')
    print(f'END {label} exit={record["exitCode"]}', flush=True)
    assert record['exitCode'] == 0, f'Inspect and preserve {label} failure logs before correcting the contract'
    lines = (root / (label + '.stdout.log')).read_text().splitlines()
    for expected_line in ['# tests 21', '# pass 21', '# fail 0', '# cancelled 0', '# skipped 0']:
        assert expected_line in lines, (label, expected_line)
    results.append({'label': label, 'node': version, 'tests': 21, 'passed': 21, 'skipped': 0})
for relative, entry in sources.items():
    raw = (repository / relative).read_bytes()
    assert len(raw) == entry['bytes'] and hashlib.sha256(raw).hexdigest() == entry['sha256']
(root / 'receipt.json').write_text(json.dumps({'complete': True, 'results': results,
    'sourceBytesUnchanged': True, 'measurementExecuted': False,
    'fullDatasets': [{'kind': entry['kind'], 'accepted': entry['expectedAccepted']} for entry in scenarios]}, indent=2) + '\n')
print(json.dumps({'root': str(root), 'results': results, 'measurementExecuted': False}), flush=True)
