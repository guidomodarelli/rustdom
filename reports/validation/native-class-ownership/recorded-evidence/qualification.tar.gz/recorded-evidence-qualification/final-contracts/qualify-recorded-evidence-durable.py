"""Recover immutable evidence and preserve all real contract receipts outside ephemeral /tmp."""
import hashlib
import io
import json
import os
import pathlib
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time

if sys.flags.optimize:
    raise RuntimeError('Durable evidence qualification: unset PYTHONOPTIMIZE before checking evidence')
assert sys.argv[1:] in [[], ['--resume']], 'Use no arguments or --resume for the preserved pre-test recovery'
resuming = sys.argv[1:] == ['--resume']
repository = pathlib.Path(__file__).resolve().parent.parent
configuration = json.loads((repository / '.cache/constants/archive-row-isolation-study.json').read_bytes())
base = repository / 'reports/benchmarks/native-class-ownership'
archive_settings = json.loads((base / 'constants/recorded-archive.json').read_bytes())
source_receipt = json.loads((repository / configuration['output'] / 'receipt.json').read_bytes())
assert source_receipt['archiveReadbackMatched'] and source_receipt['verificationOriginalAndRelocatedIdentical']
assert source_receipt['result']['verified'] and source_receipt['result']['accepted'] is False
for node in source_receipt['result']['results']:
    assert node['accepted'] is False and node['processes'] == 1024 and node['measuredDurations'] == 9216
native_parent = pathlib.Path.home() / 'rustdom-validation'
native_parent.mkdir(exist_ok=True)
initial_marker = repository / '.cache/recorded-evidence-durable.started.json'
previous = json.loads(initial_marker.read_bytes()) if resuming else None
marker = repository / ('.cache/recorded-evidence-durable-resume.started.json' if resuming else
                       '.cache/recorded-evidence-durable.started.json')
with marker.open('x') as destination:
    native = (pathlib.Path(previous['nativeRoot']).resolve(strict=True) if resuming else
              pathlib.Path(tempfile.mkdtemp(prefix='recorded-evidence-', dir=native_parent)))
    assert native.parent == native_parent.resolve() and native.name.startswith('recorded-evidence-')
    output = pathlib.Path(tempfile.mkdtemp(prefix='recorded-evidence-durable-', dir=repository / '.cache'))
    json.dump({'pid': os.getpid(), 'nativeRoot': str(native), 'outputRoot': str(output),
               'startedAt': time.time(), 'measurementExecuted': False}, destination, indent=2)
print(json.dumps({'pid': os.getpid(), 'nativeRoot': str(native), 'outputRoot': str(output)}), flush=True)
source_names = ['constants/recorded-evidence.json', 'recorded-evidence.cjs', 'recorded-evidence-extract.py',
    'recorded-evidence-fixtures.py', 'recorded-evidence-contract-cli.cjs', 'recorded-evidence.spec.cjs',
    'constants/recorded-archive.json', 'materialize-recorded-archive.py', 'recorded-archive.spec.cjs']
sources = {}
for name in source_names:
    raw = (base / name).read_bytes()
    target = output / 'sources' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    sources[name] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
(output / 'sources.json').write_text(json.dumps(sources, indent=2) + '\n')
for name in ['qualify-recorded-evidence-durable.py', 'split-row-isolation-archive.py',
             'qualify-recorded-archive.py', 'qualify-recorded-evidence.py', 'finish-row-isolation-ci-evidence.py']:
    shutil.copyfile(repository / '.cache' / name, output / name)
environment = dict(os.environ)
environment.pop('NODE_OPTIONS', None)
records = []


def execute(name, command, child_environment=environment, stdout_name=None):
    """Write child logs directly to the Windows workspace before allowing WSL to become idle."""
    record = {'name': name, 'command': command, 'cwd': str(repository),
              'startedAt': time.time(), 'measurementExecuted': False}
    with (output / (stdout_name or (name + '.stdout.log'))).open('xb') as stdout, (output / (name + '.stderr.log')).open('xb') as stderr:
        child = subprocess.Popen(command, cwd=repository, env=child_environment, stdout=stdout, stderr=stderr)
        record['pid'] = child.pid
        (output / (name + '.process.json')).write_text(json.dumps(record, indent=2) + '\n')
        print(f'START {name} pid={child.pid}', flush=True)
        record['exitCode'] = child.wait()
    record['finishedAt'] = time.time()
    (output / (name + '.process.json')).write_text(json.dumps(record, indent=2) + '\n')
    records.append(record)
    print(f'END {name} exit={record["exitCode"]}', flush=True)
    assert record['exitCode'] == 0, f'Preserve {name} logs and inspect the failed offline operation before retrying'


row_archive = native / 'row-archive'
if not resuming:
    execute('materialize-complete-archive', [sys.executable, '-B', str(base / 'materialize-recorded-archive.py'),
                                           str(repository / configuration['output']), str(row_archive)])
assert json.loads((row_archive / archive_settings['receiptFilename']).read_bytes())['archive']['sha256'] == source_receipt['archiveSha256']
assert hashlib.sha256((row_archive / 'study.tar.gz').read_bytes()).hexdigest() == source_receipt['archiveSha256']
row_extracted = native / 'row-extracted'
if not resuming:
    row_extracted.mkdir()
    execute('extract-row-evidence', [sys.executable, '-B', str(base / 'recorded-evidence-extract.py'),
        str(row_archive / 'study.tar.gz'), str(row_archive / 'raw-files.json'), configuration['archivePrefix'], str(row_extracted)])
row_bundle = row_extracted / configuration['archivePrefix']
row_study = row_bundle / 'study'
assert json.loads((row_study / 'verification.json').read_bytes()) == source_receipt['result']
assert (row_study / 'verification.exit-code').read_text().strip() == '0'
for label in configuration['nodeLabels']:
    assert json.loads((row_study / (label + '.process.json')).read_bytes())['exitCode'] == 1
build_inputs = json.loads((row_bundle / 'runtime-inputs/build-inputs.json').read_bytes())['buildInputHashes']
assert build_inputs == source_receipt['buildInputHashes']

seeded_source = base / 'seeded-pre-gc-results/2026-10-22'
seeded_receipt = json.loads((seeded_source / 'receipt.json').read_bytes())
seeded_archive = native / 'seeded-archive'
if not resuming:
    seeded_archive.mkdir()
    for name in ['study.tar.gz', 'raw-files.json']:
        shutil.copyfile(seeded_source / name, seeded_archive / name)
assert hashlib.sha256((seeded_archive / 'study.tar.gz').read_bytes()).hexdigest() == seeded_receipt['archiveSha256']
if not resuming:
    shutil.copyfile(row_archive / 'compiled-package.json', seeded_archive / 'compiled-package.json')
seeded_extracted = native / 'seeded-extracted'
if not resuming:
    seeded_extracted.mkdir()
    execute('extract-seeded-evidence', [sys.executable, '-B', str(base / 'recorded-evidence-extract.py'),
        str(seeded_archive / 'study.tar.gz'), str(seeded_archive / 'raw-files.json'), 'seeded-pre-gc', str(seeded_extracted)])
seeded_study = seeded_extracted / 'seeded-pre-gc/study'
assert json.loads((seeded_study / 'verification.json').read_bytes()) == seeded_receipt['result']

baseline = native / 'baseline'
if resuming:
    assert baseline.is_dir() and not any(baseline.iterdir()), 'Preserve an existing nonempty reference fixture'
else:
    baseline.mkdir()
roots = ['src', 'scripts', 'benchmarks', 'third-party/napi', 'package-lock.json', 'Cargo.toml', 'Cargo.lock',
         'tests/integration/read-dom-file.cjs', 'package.json', 'build.rs',
         'third-party/saxes/LICENSE', 'third-party/w3c-xmlserializer/LICENSE.md']
git_command = ['git.exe', '-C', configuration['windowsRepository'], 'archive', '--format=tar',
               'checkpoint-067-xml-serializer-controller', *roots]
execute('baseline-git-archive', git_command, stdout_name='baseline-sources.tar')
git_archive_bytes = (output / 'baseline-sources.tar').read_bytes()
(output / 'baseline-source.json').write_text(json.dumps({'command': git_command,
    'archiveSha256': hashlib.sha256(git_archive_bytes).hexdigest()}, indent=2) + '\n')


def owned_relative(root, name):
    """Keep every recovered source path inside its fresh owner."""
    relative = pathlib.PurePosixPath(name)
    assert isinstance(name, str) and name and '\\' not in name and ':' not in name
    assert not relative.is_absolute() and '..' not in relative.parts and relative.as_posix() == name
    result = root / name
    assert result.resolve().is_relative_to(root.resolve())
    return result


with tarfile.open(fileobj=io.BytesIO(git_archive_bytes)) as stream:
    for member in stream:
        if member.isdir():
            continue
        assert member.isfile()
        target = owned_relative(baseline, member.name)
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as destination:
            destination.write(stream.extractfile(member).read())
for name, expected in build_inputs['A'].items():
    filename = baseline / name
    assert (hashlib.sha256(filename.read_bytes()).hexdigest() if filename.is_file() else None) == expected

scenarios = []
for kind, study, archive, receipt, prefix, count in [
    ('seeded', seeded_study, seeded_archive, seeded_receipt, 'seeded-pre-gc', 409),
    ('rowIsolated', row_study, row_archive, source_receipt, configuration['archivePrefix'], 415),
]:
    index = json.loads((study / 'node-22/index.json').read_bytes())
    assert index['complete'] and len(index['harness']['files']) == count
    candidate = native / (kind + '-candidate')
    candidate.mkdir()
    for entry in index['harness']['files']:
        raw = owned_relative(study / 'harness', entry['path']).read_bytes()
        assert len(raw) == entry['bytes'] and hashlib.sha256(raw).hexdigest() == entry['sha256']
        target = owned_relative(candidate, entry['path'])
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
    for name, expected in build_inputs['B'].items():
        target = owned_relative(candidate, name)
        if expected is None:
            assert not target.exists()
            continue
        raw = owned_relative(row_bundle / 'runtime-inputs/B', name).read_bytes()
        assert hashlib.sha256(raw).hexdigest() == expected
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
    policy = {'archive': {'filename': 'study.tar.gz', 'sha256': receipt['archiveSha256']},
        'rawManifest': {'filename': 'raw-files.json', 'sha256': hashlib.sha256((archive / 'raw-files.json').read_bytes()).hexdigest()},
        'archivePrefix': prefix, 'nodeDirectories': ['study/node-22', 'study/node-24'],
        'sourceHashes': {'A': index['manifest']['preparation']['identity']['inputs']['sources']['A'],
                         'B': index['harness']['identity']['sourceHash']},
        'compiledSourceHashes': index['manifest']['preparation']['identity']['inputs']['sources'],
        'harnessSha256': index['harness']['sha256'], 'buildInputHashes': build_inputs,
        'compiledPackageManifest': 'compiled-package.json'}
    scenarios.append({'kind': kind, 'baselineRoot': str(baseline), 'candidateRoot': str(candidate),
        'archiveRoot': str(archive), 'expectedAccepted': receipt['result']['accepted'], 'policy': policy})

results = []
for label, executable, expected_version in [
    ('node-22', '/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node-22/bin/node', 'v22.12.0'),
    ('node-24', configuration['nodeExecutable'], 'v24.14.1'),
]:
    version = subprocess.check_output([executable, '--version'], text=True, env=environment).strip()
    assert version == expected_version
    node_output = output / label
    node_output.mkdir()
    evidence_output = node_output / 'evidence'
    transport_output = node_output / 'transport'
    evidence_output.mkdir()
    transport_output.mkdir()
    evidence_fixture = output / (label + '.evidence-fixture.json')
    evidence_fixture.write_text(json.dumps({'scenarios': scenarios, 'outputRoot': str(evidence_output)}, indent=2) + '\n')
    archive_fixture = output / (label + '.archive-fixture.json')
    archive_fixture.write_text(json.dumps({'sourceRoot': str(repository / configuration['output']),
        'outputRoot': str(transport_output), 'expectedArchiveSha256': source_receipt['archiveSha256']}, indent=2) + '\n')
    command = [executable, '--test', '--test-concurrency=1', '--test-reporter=tap',
               str(base / 'recorded-evidence.spec.cjs'), str(base / 'recorded-archive.spec.cjs')]
    execute(label, command, dict(environment, RUSTDOM_RECORDED_EVIDENCE_FIXTURE=str(evidence_fixture),
                                RUSTDOM_RECORDED_ARCHIVE_FIXTURE=str(archive_fixture)))
    lines = (output / (label + '.stdout.log')).read_text().splitlines()
    for expected in ['# tests 28', '# pass 28', '# fail 0', '# cancelled 0', '# skipped 0']:
        assert expected in lines, (label, expected)
    results.append({'node': version, 'tests': 28, 'passed': 28, 'skipped': 0})
for name, entry in sources.items():
    raw = (base / name).read_bytes()
    assert len(raw) == entry['bytes'] and hashlib.sha256(raw).hexdigest() == entry['sha256']
(output / 'receipt.json').write_text(json.dumps({'complete': True, 'results': results,
    'sourceBytesUnchanged': True, 'measurementExecuted': False, 'allLogsStoredOnWindowsWorkspace': True,
    'originalArchiveSha256': source_receipt['archiveSha256'], 'originalAccepted': False,
    'nativeRoot': str(native), 'steps': records}, indent=2) + '\n')
print(json.dumps({'complete': True, 'outputRoot': str(output), 'nativeRoot': str(native), 'results': results}), flush=True)
