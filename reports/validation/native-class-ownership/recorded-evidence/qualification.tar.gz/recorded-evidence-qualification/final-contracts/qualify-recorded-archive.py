"""Run real fragmented-archive contracts in both fixed Node versions, without DOM sampling."""
import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import sys
import tempfile
import time

if sys.flags.optimize:
    raise RuntimeError('Recorded archive qualification: unset PYTHONOPTIMIZE before checking guards')
repository = pathlib.Path(__file__).resolve().parent.parent
configuration = json.loads((repository / '.cache/constants/archive-row-isolation-study.json').read_bytes())
subprocess.run([sys.executable, '-B', str(repository / '.cache/archive-row-isolation-study.py'), '--check-ready'], check=True)
base = repository / 'reports/benchmarks/native-class-ownership'
settings = json.loads((base / 'constants/recorded-archive.json').read_bytes())
archive_root = repository / configuration['output']
declaration = json.loads((archive_root / settings['manifestFilename']).read_bytes())
receipt = json.loads((archive_root / 'receipt.json').read_bytes())
assert receipt['archiveReadbackMatched'] and receipt['verificationOriginalAndRelocatedIdentical']
assert declaration['archive']['sha256'] == receipt['archiveSha256']
marker = repository / '.cache/recorded-archive-qualification-root.txt'
with marker.open('x') as output:
    root = pathlib.Path(tempfile.mkdtemp(prefix='rustdom-recorded-archive-qualification-'))
    output.write(str(root) + '\n')
print(json.dumps({'root': str(root), 'pid': os.getpid(), 'measurementExecuted': False}), flush=True)
sources = {}
for name in ['constants/recorded-archive.json', 'constants/recorded-evidence.json',
             'materialize-recorded-archive.py', 'recorded-archive.spec.cjs']:
    raw = (base / name).read_bytes()
    target = root / 'sources' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    sources[name] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
(root / 'sources.json').write_text(json.dumps(sources, indent=2) + '\n')
shutil.copyfile(__file__, root / pathlib.Path(__file__).name)
shutil.copyfile(repository / '.cache/split-row-isolation-archive.py', root / 'split-row-isolation-archive.py')
assert hashlib.sha256((root / 'split-row-isolation-archive.py').read_bytes()).hexdigest() == declaration['producerSha256']
fixture_source = root / 'parts'
fixture_source.mkdir()
for entry in [*declaration['parts'], *declaration['sidecars']]:
    source = archive_root / entry['filename']
    assert source.stat().st_size == entry['bytes']
    assert hashlib.sha256(source.read_bytes()).hexdigest() == entry['sha256']
    shutil.copyfile(source, fixture_source / entry['filename'])
shutil.copyfile(archive_root / settings['manifestFilename'], fixture_source / settings['manifestFilename'])
results = []
environment = dict(os.environ)
environment.pop('NODE_OPTIONS', None)
for label, executable, expected_version in [
    ('node-22', '/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node-22/bin/node', 'v22.12.0'),
    ('node-24', configuration['nodeExecutable'], 'v24.14.1'),
]:
    version = subprocess.check_output([executable, '--version'], text=True, env=environment).strip()
    assert version == expected_version
    output = root / label
    output.mkdir()
    fixture = root / (label + '.fixture.json')
    fixture.write_text(json.dumps({'sourceRoot': str(fixture_source), 'outputRoot': str(output),
        'expectedArchiveSha256': receipt['archiveSha256']}, indent=2) + '\n')
    command = [executable, '--test', '--test-reporter=tap', str(base / 'recorded-archive.spec.cjs')]
    record = {'command': command, 'cwd': str(repository), 'fixture': str(fixture),
              'startedAt': time.time(), 'node': version, 'measurementExecuted': False}
    with (root / (label + '.stdout.log')).open('xb') as stdout, (root / (label + '.stderr.log')).open('xb') as stderr:
        child = subprocess.Popen(command, cwd=repository,
            env=dict(environment, RUSTDOM_RECORDED_ARCHIVE_FIXTURE=str(fixture)), stdout=stdout, stderr=stderr)
        record['pid'] = child.pid
        (root / (label + '.process.json')).write_text(json.dumps(record, indent=2) + '\n')
        print(f'START {label} pid={child.pid}', flush=True)
        record['exitCode'] = child.wait()
    record['finishedAt'] = time.time()
    (root / (label + '.process.json')).write_text(json.dumps(record, indent=2) + '\n')
    print(f'END {label} exit={record["exitCode"]}', flush=True)
    assert record['exitCode'] == 0, f'Preserve {label} logs and inspect the transport failure before any retry'
    lines = (root / (label + '.stdout.log')).read_text().splitlines()
    for expected in ['# tests 7', '# pass 7', '# fail 0', '# skipped 0', '# cancelled 0']:
        assert expected in lines, (label, expected)
    results.append({'label': label, 'node': version, 'tests': 7, 'passed': 7, 'skipped': 0})
for name, entry in sources.items():
    raw = (base / name).read_bytes()
    assert len(raw) == entry['bytes'] and hashlib.sha256(raw).hexdigest() == entry['sha256']
for entry in [*declaration['parts'], *declaration['sidecars']]:
    raw = (fixture_source / entry['filename']).read_bytes()
    assert len(raw) == entry['bytes'] and hashlib.sha256(raw).hexdigest() == entry['sha256']
(root / 'receipt.json').write_text(json.dumps({'complete': True, 'results': results,
    'archiveSha256': receipt['archiveSha256'], 'archiveBytes': receipt['archiveBytes'],
    'sourceBytesUnchanged': True, 'fixtureBytesUnchanged': True, 'measurementExecuted': False}, indent=2) + '\n')
print(json.dumps({'root': str(root), 'results': results, 'measurementExecuted': False}), flush=True)
