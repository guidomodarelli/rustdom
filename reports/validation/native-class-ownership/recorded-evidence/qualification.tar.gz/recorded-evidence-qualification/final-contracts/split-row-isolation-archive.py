"""Preserve the verified tar byte for byte in bounded Git-compatible parts."""
import hashlib
import json
import pathlib
import sys

if sys.flags.optimize:
    raise RuntimeError('Recorded archive producer: unset PYTHONOPTIMIZE before preserving verified evidence')
repository = pathlib.Path(__file__).resolve().parent.parent
base = repository / 'reports/benchmarks/native-class-ownership'
configuration = json.loads((repository / '.cache/constants/archive-row-isolation-study.json').read_bytes())
settings = json.loads((base / 'constants/recorded-archive.json').read_bytes())
output = repository / configuration['output']
assert output.resolve().is_relative_to(repository.resolve())
receipt_bytes = (output / 'receipt.json').read_bytes()
receipt = json.loads(receipt_bytes)
assert receipt['archiveReadbackMatched'] and receipt['verificationOriginalAndRelocatedIdentical']
assert receipt['result']['verified'] and receipt['result']['accepted'] is False
source = output / settings['archiveFilename']
assert source.stat().st_size == receipt['archiveBytes']
manifest = output / settings['manifestFilename']
assert not manifest.exists()
assert not list(output.glob(settings['archiveFilename'] + '.part-*'))
parts = []
whole_digest = hashlib.sha256()
with source.open('rb') as stream:
    while True:
        chunk = stream.read(settings['partSizeBytes'])
        if not chunk:
            break
        name = f'{settings["archiveFilename"]}.part-{len(parts):03d}'
        with (output / name).open('xb') as destination:
            destination.write(chunk)
        whole_digest.update(chunk)
        parts.append({'filename': name, 'bytes': len(chunk), 'sha256': hashlib.sha256(chunk).hexdigest()})
assert sum(part['bytes'] for part in parts) == receipt['archiveBytes']
assert whole_digest.hexdigest() == receipt['archiveSha256']
sidecars = []
for name in settings['requiredSidecars']:
    raw = (output / name).read_bytes()
    sidecars.append({'filename': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
declaration = {'archive': {'filename': settings['archiveFilename'], 'bytes': receipt['archiveBytes'],
                         'sha256': receipt['archiveSha256']}, 'parts': parts, 'sidecars': sidecars,
    'originalReceiptSha256': hashlib.sha256(receipt_bytes).hexdigest(),
    'producerSha256': hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
    'transportOnly': True, 'measurementExecuted': False, 'originalAccepted': False}
with manifest.open('x') as destination:
    json.dump(declaration, destination, indent=2)
    destination.write('\n')
print(json.dumps(declaration, indent=2))
