"""Describe every original process and row; do not recalibrate, sample or accept performance."""
import hashlib
import json
import pathlib
import statistics
import subprocess
import sys

if sys.flags.optimize:
    raise RuntimeError('Row isolation diagnostics: unset PYTHONOPTIMIZE before checking evidence')
repository = pathlib.Path(__file__).resolve().parent.parent
configuration = json.loads((repository / '.cache/constants/archive-row-isolation-study.json').read_bytes())
subprocess.run([sys.executable, '-B', str(repository / '.cache/archive-row-isolation-study.py'), '--check-ready'], check=True)
receipt = json.loads((repository / configuration['output'] / 'receipt.json').read_bytes())
assert receipt['archiveReadbackMatched'] and receipt['verificationOriginalAndRelocatedIdentical']
study = pathlib.Path(json.loads((repository / configuration['archiveMarker']).read_bytes())['bundle']) / 'study'
assert json.loads((study / 'verification.json').read_bytes()) == receipt['result']

def dispersion(values):
    """Keep all values and describe dispersion without assuming independent or steady samples."""
    median = statistics.median(values)
    return {'count': len(values), 'medianMs': median, 'minimumMs': min(values), 'maximumMs': max(values),
            'medianAbsoluteDeviationMs': statistics.median(abs(value - median) for value in values)}

def mask_contains(mask, cpu):
    """Read a recorded Linux CPU-list mask without querying or changing any process."""
    for part in mask.split(','):
        bounds = [int(value) for value in part.split('-')]
        if len(bounds) == 1 and bounds[0] == cpu:
            return True
        if len(bounds) == 2 and bounds[0] <= cpu <= bounds[1]:
            return True
    return False

def affinity_context(report):
    """Describe endpoint masks; they do not reveal CPU actually consumed within a timer."""
    main_cpu = report['settings']['cpu']
    before = report['affinity']['configured']
    after = report['affinitiesAfter']
    initial_ids = {entry['tid'] for entry in before if not entry.get('disappeared')}
    descriptions = {}
    for name, records in [('configured', before), ('after', after)]:
        main = next(entry for entry in records if entry['tid'] == report['pid'])
        assert main['mask'] == str(main_cpu)
        background = [entry for entry in records if entry['tid'] != report['pid'] and not entry.get('disappeared')]
        descriptions[name] = {'backgroundThreadsObserved': len(background),
            'backgroundMasksIncludingMainCpu': sum(mask_contains(entry['mask'], main_cpu) for entry in background),
            'backgroundMasksOnlyMainCpu': sum(entry['mask'] == str(main_cpu) for entry in background),
            'backgroundMasks': sorted({entry['mask'] for entry in background})}
    descriptions['newThreadIdsAtFinalObservation'] = sorted(entry['tid'] for entry in after
        if not entry.get('disappeared') and entry['tid'] not in initial_ids)
    return descriptions

cells = []
for node_label in configuration['nodeLabels']:
    root = study / node_label
    index = json.loads((root / 'index.json').read_bytes())
    assert index['complete'] and len(index['runs']) == configuration['workersPerNode']
    workers = []
    for entry in index['runs']:
        assert entry['exitCode'] == 0 and entry['signal'] is None and entry['error'] is None
        raw = (root / entry['report']).read_bytes()
        report = json.loads(raw)
        assert report['complete'] and len(report['batches']) == 1
        batch = report['batches'][0]
        values = batch['samplesMs']
        assert len(values) == index['settings']['measuredSamples']
        workers.append({'phase': entry['phase'], 'engine': entry['engine'], 'label': entry['label'],
            'position': entry['position'], 'rowIndex': entry['rowIndex'], 'pid': report['pid'],
            'physicalPackage': report['schedule']['physical'], 'factors': report['schedule']['factors'],
            'sourceReport': entry['report'], 'reportSha256': hashlib.sha256(raw).hexdigest(),
            'samples': dispersion(values), 'affinity': affinity_context(report)})
    for phase in index['settings']['phases']:
        for engine in index['settings']['engines']:
            for row_index, row_key in enumerate(index['settings']['rows']):
                for label in index['settings']['labels']:
                    group = [worker for worker in workers if worker['phase'] == phase and worker['engine'] == engine
                             and worker['rowIndex'] == row_index and worker['label'] == label]
                    assert sorted(worker['position'] for worker in group) == list(range(index['settings']['workerCount']))
                    assert len(group) == 16
                    physical = sorted({worker['physicalPackage'] for worker in group})
                    cells.append({'node': index['node'], 'phase': phase, 'engine': engine, 'row': row_key, 'label': label,
                        'processMedianDispersion': dispersion([worker['samples']['medianMs'] for worker in group]),
                        'withinProcessMadDispersion': dispersion([worker['samples']['medianAbsoluteDeviationMs'] for worker in group]),
                        'physicalPackages': {package: {'processes': sum(worker['physicalPackage'] == package for worker in group),
                            'processMedianDispersion': dispersion([worker['samples']['medianMs'] for worker in group
                                                                  if worker['physicalPackage'] == package])}
                            for package in physical},
                        'workers': group})

assert len(cells) == 128
report = {'complete': True, 'sourceStudyArchiveSha256': receipt['archiveSha256'],
    'officialAccepted': receipt['result']['accepted'], 'cells': cells, 'measurementExecuted': False,
    'budgetsOrEstimatorChanged': False,
    'limits': [
        'Descriptive all-process/all-row dispersion and recorded affinity endpoints only; no selected subset accepts a gate.',
        'No inference of independent samples, steady-state convergence, actual scheduler activity or causality.',
        'Physical copy and position subgroups are diagnostic; original pooled medians and complete decisions remain authoritative.',
        'Existing V8 traces were not aligned with workload timers; no trace recapture or new profile is used.',
    ],
    'methodReferences': [
        'https://kar.kent.ac.uk/33611/',
        'https://soft-dev.org/pubs/html/barrett_bolz-tereick_killick_mount_tratt__virtual_machine_warmup_blows_hot_and_cold_v6/',
    ]}
output = repository / '.cache/row-isolation-diagnostics.json'
with output.open('x') as destination:
    json.dump(report, destination, indent=2)
    destination.write('\n')
print(json.dumps({'output': str(output), 'cells': len(cells), 'officialAccepted': report['officialAccepted'],
    'measurementExecuted': False, 'budgetsOrEstimatorChanged': False}))
