"""Publish complete negative evidence and durable offline QA without another measurement."""
import hashlib
import json
import pathlib
import shutil
import subprocess
import tarfile
import tempfile

repository = pathlib.Path(__file__).resolve().parent.parent
cache = repository / '.cache'
base = repository / 'reports/benchmarks/native-class-ownership'
benchmark = base / 'row-isolation-results/2026-10-22'
qa = repository / 'reports/validation/native-class-ownership/recorded-evidence'
assert not qa.exists()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repository, text=True).strip()
assert head == 'a0346b1355e8751bc560c64e289c2c8f1be55ec2'
final_marker = json.loads((cache / 'recorded-evidence-durable-resume.started.json').read_bytes())
final_root = pathlib.Path(final_marker['outputRoot'].replace('/mnt/c/', 'C:/', 1))
initial_marker = json.loads((cache / 'recorded-evidence-durable.started.json').read_bytes())
initial_root = pathlib.Path(initial_marker['outputRoot'].replace('/mnt/c/', 'C:/', 1))
validation = json.loads((final_root / 'receipt.json').read_bytes())
assert validation['complete'] and validation['allLogsStoredOnWindowsWorkspace']
assert validation['results'] == [{'node': 'v22.12.0', 'tests': 28, 'passed': 28, 'skipped': 0},
                                 {'node': 'v24.14.1', 'tests': 28, 'passed': 28, 'skipped': 0}]
sources = json.loads((final_root / 'sources.json').read_bytes())
for name, entry in sources.items():
    raw = (base / name).read_bytes()
    assert len(raw) == entry['bytes'] and hashlib.sha256(raw).hexdigest() == entry['sha256']
frozen = json.loads((repository / 'reports/validation/native-class-ownership/row-isolation-method/source-manifest.json').read_bytes())
assert len(frozen['files']) == 415
for entry in frozen['files']:
    raw = (repository / entry['path']).read_bytes()
    assert len(raw) == entry['bytes'] and hashlib.sha256(raw).hexdigest() == entry['sha256'], entry['path']
parts = json.loads((benchmark / 'archive-parts.json').read_bytes())
whole = hashlib.sha256()
for entry in parts['parts']:
    raw = (benchmark / entry['filename']).read_bytes()
    assert len(raw) == entry['bytes'] and hashlib.sha256(raw).hexdigest() == entry['sha256']
    whole.update(raw)
assert whole.hexdigest() == parts['archive']['sha256'] == validation['originalArchiveSha256']
binding = json.loads((cache / 'row-isolation-diagnostic-binding-qa/receipt.json').read_bytes())
assert binding['complete'] and len(binding['cases']) == 2 and binding['positiveCaseAuthenticatedFiles'] == 2051
diagnostic = (cache / 'row-isolation-diagnostics-bound.json').read_bytes()
assert hashlib.sha256(diagnostic).hexdigest() == binding['boundResultSha256']

stage = pathlib.Path(tempfile.mkdtemp(prefix='recorded-evidence-publication-', dir=cache))
for name, source in [
    ('final-contracts', final_root), ('recovery-before-tests', initial_root),
    ('diagnostic-binding', cache / 'row-isolation-diagnostic-binding-qa'),
    ('live-guard-v1', cache / 'row-isolation-archive-guard-live'),
    ('live-guard-v2', cache / 'row-isolation-archive-guard-live-v2'),
    ('node22-terminal-observation', cache / 'row-isolation-node22-terminal'),
    ('ci-gate-errors', cache / 'ci-a034-gate-errors'),
]:
    shutil.copytree(source, stage / name)
tools = stage / 'tools'
tools.mkdir()
for name in ['archive-row-isolation-study.py', 'analyze-row-isolation.py', 'diagnose-row-isolation.py',
             'diagnose-row-isolation-initial.py', 'diagnose-row-isolation-unbound.py',
             'test-row-isolation-diagnostic-binding.py', 'publish-row-isolation-evidence.py',
             'qualify-recorded-evidence.py', 'qualify-recorded-archive.py', 'split-row-isolation-archive.py',
             'finish-row-isolation-ci-evidence.py', 'qualify-recorded-evidence-durable.py']:
    shutil.copyfile(cache / name, tools / name)
(tools / 'constants').mkdir()
shutil.copyfile(cache / 'constants/archive-row-isolation-study.json', tools / 'constants/archive-row-isolation-study.json')
for name in ['row-isolation-study.started.json', 'row-isolation-archive.started.json',
             'row-isolation-followup.started.json', 'recorded-evidence-durable.started.json',
             'recorded-evidence-durable-resume.started.json', 'row-isolation-publication.json']:
    shutil.copyfile(cache / name, stage / name)
shutil.copyfile(cache / 'row-isolation-diagnostics-bound.json', stage / 'diagnostics-bound.json')
shutil.copyfile(cache / 'row-isolation-diagnostics-unbound.json', stage / 'historical-diagnostics-unbound.json')
(stage / 'scope.json').write_text(json.dumps({
    'performanceMeasurementRepeated': False, 'originalAccepted': False,
    'finalContractResults': validation['results'], 'diagnosticNegativeCases': 2,
    'performanceData': 'Complete original 7429-member archive is separately published in eight parts.',
    'largeFixtures': 'Fixture paths point to preserved datasets reconstructed from the published archives; native filesystem copies are not duplicated in this QA tar.',
    'previousTmpLoss': 'Initial temporary QA receipts disappeared after WSL stopped; they are not counted as final evidence. The complete benchmark archive was already stored on Windows.',
    'recoveryAttemptFailure': 'The first durable launcher stopped before tests at a misspelled Git tag. Its source and completed extraction receipts remain in recovery-before-tests. That version did not persist Git stderr; terminal reported exit128. Resume corrected the ref and records Git PID, stderr and exit.',
    'historicalDiagnosticLimit': 'historical-diagnostics-unbound.json predates explicit consumed-file hash binding. Only diagnostics-bound.json and diagnostic-binding receipts are authoritative for diagnostic claims.'}, indent=2) + '\n', encoding='utf-8')
entries = {}
for filename in sorted(stage.rglob('*')):
    assert not filename.is_symlink()
    if filename.is_file():
        raw = filename.read_bytes()
        entries[filename.relative_to(stage).as_posix()] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
qa.mkdir(parents=True)
archive = qa / 'qualification.tar.gz'
with tarfile.open(archive, 'w:gz') as stream:
    stream.add(stage, arcname='recorded-evidence-qualification')
actual = {}
with tarfile.open(archive) as stream:
    for member in stream:
        assert member.isdir() or member.isfile()
        if member.isfile():
            actual[member.name.removeprefix('recorded-evidence-qualification/')] = {
                'bytes': member.size, 'sha256': hashlib.sha256(stream.extractfile(member).read()).hexdigest()}
assert actual == entries
(qa / 'raw-files.json').write_text(json.dumps(entries, indent=2) + '\n', encoding='utf-8')
(qa / 'source-manifest.json').write_text(json.dumps({'baseCommit': head, 'files': sources,
    'frozen415Unchanged': True, 'frozenHarnessSha256': frozen['sha256']}, indent=2) + '\n', encoding='utf-8')
result = {'complete': True, 'baseCommit': head, 'results': validation['results'],
    'qaFiles': len(entries), 'qaArchiveBytes': archive.stat().st_size,
    'qaArchiveSha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'qaArchiveReadbackMatched': True,
    'diagnosticAuthenticatedInputs': 2051, 'diagnosticCells': 128, 'diagnosticNegativeCases': 2,
    'frozen415Unchanged': True, 'measurementRepeated': False, 'performanceAccepted': False,
    'originalArchiveSha256': parts['archive']['sha256'], 'originalArchiveBytes': parts['archive']['bytes'],
    'originalArchiveParts': len(parts['parts']), 'finalReceiptsStoredOnWindowsWorkspace': True,
    'priorEphemeralReceiptsUsedForAcceptance': False}
(qa / 'receipt.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
(qa / 'README.md').write_text('''# Verificador y transporte de evidencia real

Los28contratos pasaron en Node22.12.0 y24.14.1, sin omisiones:21del replay de
datasets completos y7del transporte. Los CLI reales conservan exit1 para un
presupuesto rechazado y exit2 para inputs/integridad incompatibles. No cargan
el addon ni ejecutan nuevos tiempos DOM. También se probaron dos rechazos de
datos alterados en el diagnóstico; el caso positivo autentica2051archivos.

qualification.tar.gz conserva todos los logs finales, procesos, fixtures JSON,
fuentes exactas, recibos, baseline Git, guards originales y antecedentes fallidos.
raw-files.json identifica cada miembro; receipt.json confirma el readback.
Los datos grandes usados por las fixtures están publicados por separado en
row-isolation-results/2026-10-22/ y seeded-pre-gc-results/2026-10-22/. Las rutas
absolutas conservadas son las de la ejecución original; al reproducir en otra
máquina deben apuntar a copias de esos mismos bytes y a nuevas salidas propias.

Los logs definitivos se escribieron directamente en Windows tras recuperar los
datasets en un directorio persistente de/home. Los recibos de una calificación
anterior en/tmp se perdieron y no se usan como prueba final. Se conserva un
intento de recuperación fallido antes de los tests por un ref incorrecto,
corregido en la continuación. scope.json documenta ese límite, la ausencia de
stderrGit de aquel intento y el diagnóstico histórico sin binding de inputs.

El estudio de rendimiento completo sigue rechazado por siete controles jsdom.
Esta calificación comprueba replay, integridad, errores y transporte; no acepta
rendimiento, no agrega APIs Rust y no equivale a una aprobación GitHub remota.
''', encoding='utf-8', newline='\n')

full = benchmark / 'study.tar.gz'
preserved_full = cache / 'row-isolation-study-full-a0643d2c.tar.gz'
assert full.resolve().is_relative_to(benchmark.resolve())
assert preserved_full.parent.resolve() == cache.resolve() and not preserved_full.exists()
assert full.stat().st_size == parts['archive']['bytes']
full.rename(preserved_full)
for folder in [qa, benchmark]:
    files = {}
    for filename in sorted(folder.iterdir()):
        if filename.is_file() and filename.name not in ['files.json', 'review.json']:
            raw = filename.read_bytes()
            files[filename.name] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    (folder / 'files.json').write_text(json.dumps(files, indent=2) + '\n', encoding='utf-8')
(cache / 'row-isolation-evidence-publication.json').write_text(json.dumps({**result,
    'qaStage': str(stage), 'preservedFullArchive': str(preserved_full)}, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result))
