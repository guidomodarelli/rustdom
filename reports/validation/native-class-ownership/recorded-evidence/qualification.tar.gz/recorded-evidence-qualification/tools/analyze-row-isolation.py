"""Derive full performance and finite resource reports without running a DOM sample."""
import hashlib
import json
import pathlib
import statistics
import subprocess
import sys

if sys.flags.optimize:
    raise RuntimeError('Row isolation analysis: unset PYTHONOPTIMIZE before validating evidence')

repository = pathlib.Path(__file__).resolve().parent.parent
configuration = json.loads((repository / '.cache/constants/archive-row-isolation-study.json').read_bytes())
subprocess.run([sys.executable, '-B', str(repository / '.cache/archive-row-isolation-study.py'), '--check-ready'], check=True)
output = repository / configuration['output']
receipt = json.loads((output / 'receipt.json').read_bytes())
study = pathlib.Path(json.loads((repository / configuration['archiveMarker']).read_bytes())['bundle']) / 'study'
verification = json.loads((study / 'verification.json').read_bytes())
assert verification == receipt['result'] and verification['verified']
assert receipt['archiveReadbackMatched'] and receipt['verificationOriginalAndRelocatedIdentical']
results = []
memory_groups = []
owners = {'window': 0, 'document': 0}
warmup_owners = {'window': 0, 'document': 0}
for label, verified in zip(configuration['nodeLabels'], verification['results']):
    index_bytes = (study / label / 'index.json').read_bytes()
    index = json.loads(index_bytes)
    assert index['complete'] and len(index['runs']) == configuration['workersPerNode']
    assert verified['processes'] == len(index['runs']) and verified['measuredDurations'] == configuration['measuredDurationsPerNode']
    assert all(entry['exitCode'] == 0 and entry['signal'] is None and entry['error'] is None for entry in index['runs'])
    rows = [{'phase': phase, 'key': row['key'], 'jsdomControlChangePercent': row['jsdomControlChangePercent'],
             'rustdomChangePercent': row['rustdomChangePercent'], 'calibrated': row['calibrated'],
             'withinBudget': row['withinBudget']}
            for phase, group in verified['summaries'].items() for row in group]
    controls = [row for row in rows if abs(row['jsdomControlChangePercent']) > index['settings']['controlBudgetPercent']]
    rust = [row for row in rows if (abs(row['rustdomChangePercent']) if row['phase'] == 'AA'
                                  else row['rustdomChangePercent']) > index['settings']['rustBudgetPercent']]
    results.append({'node': verified['node'], 'complete': True, 'accepted': verified['accepted'],
                    'workers': verified['processes'], 'workerFailures': 0,
                    'measuredDurations': verified['measuredDurations'], 'rows': rows,
                    'jsdomControlFailures': controls, 'numericRustBudgetFailures': rust,
                    'machine': index['machine'], 'indexSha256': hashlib.sha256(index_bytes).hexdigest(),
                    'nodeProcess': json.loads((study / (label + '.process.json')).read_bytes())})
    for engine in index['settings']['engines']:
        for row_index, row_key in enumerate(index['settings']['rows']):
            runs = [entry for entry in index['runs'] if entry['engine'] == engine and entry['rowIndex'] == row_index]
            assert len(runs) == 64
            endpoints = []
            native_workers = 0
            for entry in runs:
                report = json.loads((study / label / entry['report']).read_bytes())
                assert report['complete'] and len(report['batches']) == 1
                batch = report['batches'][0]
                assert f'{batch["name"]}/{batch["size"]}' == row_key
                assert len(batch['samplesMs']) == index['settings']['measuredSamples']
                assert len(batch['cleanupTrace']) == index['settings']['cleanupRounds']
                for endpoint in batch['cleanupTrace'][-index['settings']['requiredClearRounds']:]:
                    assert endpoint['clear'] and endpoint['survivors'] == {'window': 0, 'document': 0}
                for kind in owners:
                    assert batch['trackedOwners'][kind] == index['settings']['warmupSamples'] + index['settings']['measuredSamples']
                    owners[kind] += batch['trackedOwners'][kind]
                    warmup_owners[kind] += index['settings']['warmupSamples']
                native_workers += int('nativeBaseline' in report)
                endpoints.append(batch['cleanupTrace'][-1]['memory'])
            memory_groups.append({'node': verified['node'], 'engine': engine, 'row': row_key,
                'workers': len(runs), 'nativeBaselineWorkers': native_workers,
                'finalSurvivors': {'window': 0, 'document': 0},
                'finalCleanupMemoryBytes': {field: {'minimum': min(endpoint[field] for endpoint in endpoints),
                    'median': statistics.median(endpoint[field] for endpoint in endpoints),
                    'maximum': max(endpoint[field] for endpoint in endpoints)}
                    for field in ['rss', 'heapTotal', 'heapUsed', 'external', 'arrayBuffers']}})

assert sum(entry['workers'] for entry in results) == 2048
assert sum(entry['measuredDurations'] for entry in results) == 18432
assert owners == {'window': 24576, 'document': 24576}
assert warmup_owners == {'window': 6144, 'document': 6144}
summary = {'complete': True, 'verified': True, 'accepted': verification['accepted'],
    'methodSourceCommit': configuration['reviewedCommit'], 'harnessSha256': receipt['harnessSha256'],
    'sourceFiles': receipt['sourceFiles'], 'rawFiles': receipt['rawFiles'],
    'archiveBytes': receipt['archiveBytes'], 'archiveSha256': receipt['archiveSha256'],
    'originalAndRelocatedVerificationIdentical': True, 'measurementRepeated': False,
    'results': results,
    'scope': 'The complete original row-isolation study; integrity and numeric Rust results do not override rejected jsdom calibration.'}
memory = {'complete': True, 'sourceStudyArchiveSha256': receipt['archiveSha256'],
    'observedOwnersByKind': owners, 'includingOuterWarmupByKind': warmup_owners,
    'finalSurvivorsByKind': {'window': 0, 'document': 0}, 'groups': memory_groups,
    'nativeEndpointScope': 'The original verifier checks lifetime fields against each Rust worker baseline and bounded reserved handles, not every cumulative statistic.',
    'limits': 'Finite pre-exit cleanup snapshots per isolated row process. No within-process growth trend, process peak, allocator reclamation, absolute leak freedom or performance acceptance is inferred.'}
for filename, value in [(output / 'summary.json', summary),
                        (repository / 'reports/memory/native-class-ownership-row-isolation-2026-10-22.json', memory)]:
    raw = (json.dumps(value, indent=2) + '\n').encode()
    filename.parent.mkdir(parents=True, exist_ok=True)
    with filename.open('xb') as destination:
        destination.write(raw)
print(json.dumps({'accepted': verification['accepted'], 'controlFailures': [len(entry['jsdomControlFailures']) for entry in results],
    'numericRustFailures': [len(entry['numericRustBudgetFailures']) for entry in results], 'ownerObservations': owners,
    'measurementExecuted': False}))
