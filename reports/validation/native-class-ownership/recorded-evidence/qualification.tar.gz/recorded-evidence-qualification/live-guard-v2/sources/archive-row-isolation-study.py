"""Preserve the original complete row-isolation sequence without starting a sampler."""
import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time

if sys.flags.optimize:
    raise RuntimeError('Row isolation archive: unset PYTHONOPTIMIZE; preservation guards must remain enabled')

configuration_path = pathlib.Path(__file__).parent / 'constants' / (pathlib.Path(__file__).stem + '.json')
configuration = json.loads(configuration_path.read_text())
repository = pathlib.Path(configuration['repository'])
original = pathlib.Path(configuration['originalRoot'])
output = repository / configuration['output']


def require_process_terminal(pid, expected_command):
    """Use real process state rather than a consumed marker as evidence of completion."""
    process = pathlib.Path('/proc') / str(pid)
    if process.exists():
        status = (process / 'stat').read_text().split(') ', 1)[1].split()[0]
        command = (process / 'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace')
        assert status == 'Z' or expected_command not in command, (
            f'Original row-isolation process is live: pid={pid}; do not copy, compress or restart it')


def require_terminal():
    """Refuse all heavy work until the original driver and both recorded Node parents finish."""
    marker = json.loads((repository / configuration['studyMarker']).read_bytes())
    assert marker['root'] == str(original) and marker['head'] == configuration['reviewedCommit']
    require_process_terminal(marker['driverPid'], configuration['driverFilename'])
    for label in configuration['nodeLabels']:
        filename = original / (label + '.process.json')
        assert filename.is_file(), f'Original {label} did not finish; preserve and inspect the original root'
        record = json.loads(filename.read_bytes())
        require_process_terminal(record['pid'], configuration['parentFilename'])
        assert record.get('exitCode') in [0, 1], f'Original {label} was not completely reaped'
    assert (original / 'verification.exit-code').read_text().strip() == '0'
    result = json.loads((original / 'verification.json').read_bytes())
    assert result['verified'] is True and len(result['results']) == len(configuration['nodeLabels'])
    return result


def preserve_build_inputs(bundle, manifest):
    """Capture original compiled inputs and the exact published test-command exception separately."""
    prepared = pathlib.Path(configuration['preparedRoot'])
    source_index = json.loads((prepared / 'index.json').read_bytes())
    declarations = json.loads((repository / 'reports/benchmarks/native-class-ownership/constants/ownership-evidence.json').read_bytes())
    program = """const path=require('node:path');const root=process.argv[1];
const build=require(path.join(root,'reports/benchmarks/native-class-ownership/constants/hosted-build.cjs'));
const old=require(path.join(root,'reports/benchmarks/native-class-ownership/constants/ownership-evidence.json'));
const method=require(path.join(root,'reports/benchmarks/native-class-ownership/constants/row-isolation-study.cjs'));
process.stdout.write(JSON.stringify({names:[...new Set([...build.additionalBuildInputs,...Object.keys(old.buildInputHashes.A)])].sort(),
preparation:method.preparation}));"""
    environment = dict(os.environ)
    environment.pop('NODE_OPTIONS', None)
    metadata = json.loads(subprocess.check_output([configuration['nodeExecutable'], '-e', program,
                                                 str(bundle / 'study/harness')], env=environment))
    names = metadata['names']
    assert source_index['inputsBefore']['sources'] == metadata['preparation']['identity']['inputs']['sources']
    git = ['git.exe', '-C', configuration['windowsRepository']]
    committed = set(subprocess.check_output([*git, 'ls-tree', '-r', '--name-only', configuration['reviewedCommit'],
                                          '--', *names], text=True).splitlines())
    inputs = {'A': {}, 'B': {}}
    compiled_package = None
    current_package = None
    for label, directory in [('A', 'baseline-sources'), ('B', 'sources')]:
        for name in names:
            compiled_source = prepared / directory / name
            raw = compiled_source.read_bytes() if compiled_source.is_file() else None
            if raw is not None:
                assert hashlib.sha256(raw).hexdigest() == source_index['files'][directory + '/' + name]
            if name in declarations['buildInputHashes'][label]:
                expected = declarations['buildInputHashes'][label][name]
                assert (hashlib.sha256(raw).hexdigest() if raw is not None else None) == expected
            if label == 'B':
                published = subprocess.check_output([*git, 'show', configuration['reviewedCommit'] + ':' + name]) if name in committed else None
                if name != 'package.json':
                    assert published == raw, f'Unmeasured build input changed: {name}'
                else:
                    compiled_package = raw
                    current_package = published
                raw = published
            inputs[label][name] = hashlib.sha256(raw).hexdigest() if raw is not None else None
            if raw is not None:
                target = bundle / 'runtime-inputs' / label / name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(raw)
    compiled_object = json.loads(compiled_package)
    current_object = json.loads(current_package)
    previous_command = compiled_object['scripts']['test:compat']
    compiled_object['scripts']['test:compat'] = current_object['scripts']['test:compat']
    assert compiled_object == current_object, 'The published package manifest changed build/runtime fields'
    (bundle / configuration['compiledPackageManifest']).write_bytes(compiled_package)
    (bundle / 'runtime-inputs/build-inputs.json').write_text(json.dumps({
        'publishedCommit': configuration['reviewedCommit'], 'buildInputHashes': inputs,
        'compiledSourceHashes': source_index['inputsBefore']['sources'],
        'measuredCandidateSourceHash': manifest['identity']['sourceHash'],
        'packageManifestException': {'field': 'scripts.test:compat', 'compiled': previous_command,
                                     'current': current_object['scripts']['test:compat']},
        'referenceArtifact': metadata['preparation'],
        'differentBuildEquivalenceClaimed': False}, indent=2) + '\n')
    return inputs


def archive():
    """Copy every original byte, verify relocation offline and preserve the original decision."""
    result = require_terminal()
    assert not output.exists(), 'Preserve an existing archive instead of overwriting it'
    with (repository / configuration['archiveMarker']).open('x') as marker:
        bundle = pathlib.Path(tempfile.mkdtemp(prefix='rustdom-row-isolation-evidence-'))
        json.dump({'originalRoot': str(original), 'bundle': str(bundle),
                   'archivePid': os.getpid(), 'startedAt': time.time()}, marker, indent=2)
    print(json.dumps({'archivePid': os.getpid(), 'bundle': str(bundle), 'originalRoot': str(original)}), flush=True)
    for filename in original.rglob('*'):
        assert not filename.is_symlink(), f'Unexpected evidence link: {filename}'
    study = bundle / 'study'
    shutil.copytree(original, study)
    for filename in original.rglob('*'):
        if filename.is_file():
            assert filename.read_bytes() == (study / filename.relative_to(original)).read_bytes()
    tools = bundle / 'tools'
    (tools / 'constants').mkdir(parents=True)
    shutil.copyfile(__file__, tools / pathlib.Path(__file__).name)
    shutil.copyfile(configuration_path, tools / 'constants' / configuration_path.name)
    for name in configuration['followupDirectories']:
        shutil.copytree(repository / '.cache' / name, bundle / 'followup-ci' / name)
    manifest = json.loads((repository / configuration['methodDirectory'] / 'source-manifest.json').read_bytes())
    assert len(manifest['files']) == configuration['sourceFiles'] and manifest['sha256'] == configuration['harnessSha256']
    for entry in manifest['files']:
        for base in [repository, original / 'harness', study / 'harness']:
            raw = (base / entry['path']).read_bytes()
            assert len(raw) == entry['bytes'] and hashlib.sha256(raw).hexdigest() == entry['sha256'], entry['path']
    for label in configuration['nodeLabels']:
        index = json.loads((study / label / 'index.json').read_bytes())
        assert index['complete'] and len(index['runs']) == configuration['workersPerNode']
        assert index['harness']['files'] == manifest['files'] and index['harness']['sha256'] == manifest['sha256']
        assert all(entry['exitCode'] == 0 and entry['signal'] is None and entry['error'] is None for entry in index['runs'])
        verified = next(entry for entry in result['results'] if entry['node'] == index['node'])
        assert verified['processes'] == configuration['workersPerNode']
        assert verified['measuredDurations'] == configuration['measuredDurationsPerNode']
        assert index['accepted'] == verified['accepted']
        process = json.loads((study / (label + '.process.json')).read_bytes())
        assert process['exitCode'] == (0 if verified['accepted'] else 1)
    inputs = preserve_build_inputs(bundle, manifest)
    command = [configuration['nodeExecutable'], str(study / 'harness/reports/benchmarks/native-class-ownership' / configuration['parentFilename']),
               '--verify-set', *[str(study / label) for label in configuration['nodeLabels']]]
    record = {'command': command, 'cwd': str(study / 'harness'), 'startedAt': time.time(), 'measurementExecuted': False}
    environment = dict(os.environ)
    environment.pop('NODE_OPTIONS', None)
    with (bundle / 'offline-verification.stdout.log').open('xb') as stdout, (bundle / 'offline-verification.stderr.log').open('xb') as stderr:
        child = subprocess.Popen(command, cwd=record['cwd'], env=environment, stdout=stdout, stderr=stderr)
        record['pid'] = child.pid
        (bundle / 'offline-verification.process.json').write_text(json.dumps(record, indent=2) + '\n')
        print(f'START offline-verification pid={child.pid}', flush=True)
        record['exitCode'] = child.wait()
    record['finishedAt'] = time.time()
    (bundle / 'offline-verification.process.json').write_text(json.dumps(record, indent=2) + '\n')
    assert record['exitCode'] == 0
    assert json.loads((bundle / 'offline-verification.stdout.log').read_bytes()) == result
    entries = {}
    for filename in sorted(bundle.rglob('*')):
        assert not filename.is_symlink(), f'Unexpected link in preserved evidence: {filename}'
        if filename.is_file():
            raw = filename.read_bytes()
            entries[filename.relative_to(bundle).as_posix()] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    output.mkdir(parents=True, exist_ok=False)
    archive_path = output / 'study.tar.gz'
    with tarfile.open(archive_path, 'w:gz') as stream:
        stream.add(bundle, arcname=configuration['archivePrefix'])
    actual = {}
    with tarfile.open(archive_path) as stream:
        for member in stream:
            if member.isfile():
                actual[member.name.removeprefix(configuration['archivePrefix'] + '/')] = {
                    'bytes': member.size, 'sha256': hashlib.sha256(stream.extractfile(member).read()).hexdigest()}
    assert actual == entries
    (output / 'raw-files.json').write_text(json.dumps(entries, indent=2) + '\n')
    shutil.copyfile(bundle / configuration['compiledPackageManifest'], output / configuration['compiledPackageManifest'])
    shutil.copyfile(bundle / 'runtime-inputs/build-inputs.json', output / 'build-inputs.json')
    receipt = {'originalRoot': str(original), 'allOriginalBytesPreserved': True, 'rawFiles': len(entries),
               'archiveReadbackMatched': True, 'archiveBytes': archive_path.stat().st_size,
               'archiveSha256': hashlib.sha256(archive_path.read_bytes()).hexdigest(),
               'verificationOriginalAndRelocatedIdentical': True, 'archiveOperationMeasuredDOM': False,
               'sourceFiles': len(manifest['files']), 'harnessSha256': manifest['sha256'],
               'publishedCommit': configuration['reviewedCommit'], 'buildInputHashes': inputs, 'result': result}
    (output / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({key: value for key, value in receipt.items() if key != 'result'}, indent=2))


if __name__ == '__main__':
    if sys.argv[1:] == ['--check-ready']:
        require_terminal()
        print('Original driver and both Nodes terminal and verified; archival may begin')
    else:
        assert not sys.argv[1:], 'Use no arguments or --check-ready'
        archive()
