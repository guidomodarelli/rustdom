"""Read only the current method/general CI and update its own operational observation; never activate a study."""
import concurrent.futures,datetime,json,subprocess
from pathlib import Path
repository=Path(__file__).resolve().parent.parent
head='02291d6b7a234a26ffaf364a1f377766e2338e7a'
policy=json.loads((repository/'reports/benchmarks/native-class-ownership/range-collapse-study/constants/protocol.json').read_bytes())
root=repository/'.cache/range-method-ci-02291d6b'; root.mkdir(exist_ok=True)
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
folder=root/stamp; folder.mkdir()
endpoints={'method-run.json':'actions/runs/40135020053','method-jobs.json':'actions/runs/40135020053/jobs?per_page=100',
 'general-run.json':'actions/runs/40135020046','general-jobs.json':'actions/runs/40135020046/jobs?per_page=100',
 'checks.json':'commits/'+head+'/check-runs?per_page=100'}
def get(item):
 name,endpoint=item
 raw=subprocess.check_output(['gh','api','repos/guidomodarelli/rustdom/'+endpoint],cwd=repository)
 (folder/name).write_bytes(raw); return name,json.loads(raw)
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as workers:
 records=dict(workers.map(get,endpoints.items()))
for name,run_id,path in [('method-run.json',40135020053,policy['contractsWorkflow']),('general-run.json',40135020046,'.github/workflows/ci.yml')]:
 record=records[name]; assert record['id']==run_id and record['head_sha']==head and record['run_attempt']==1 and record['path'].split('@',1)[0]==path
selected={name:[check for check in records['checks.json']['check_runs'] if check['name']==name and check['head_sha']==head] for name in policy['requiredChecks']}
passed={name:len(checks)==1 and checks[0]['status']=='completed' and checks[0]['conclusion']=='success' for name,checks in selected.items()}
state={'head':head,'observedAtUTC':stamp,'methodRunId':40135020053,'methodStatus':records['method-run.json']['status'],'methodConclusion':records['method-run.json']['conclusion'],
 'generalCiRunId':40135020046,'generalCiStatus':records['general-run.json']['status'],'generalCiConclusion':records['general-run.json']['conclusion'],
 'requiredChecksPassed':passed,'allRequiredChecksPassed':all(passed.values()),'requiredChecksPassedCount':sum(passed.values()),
 'observationDirectory':str(folder.relative_to(repository)).replace('\\','/'),'observerExecutedDOM':False,
 'sharedWatchModified':False,'activationJournal':'.cache/range-study-trigger-02291d6b'}
(folder/'observation.json').write_bytes((json.dumps(state,indent=2)+'\n').encode())
(root/'observation.json').write_bytes((json.dumps(state,indent=2)+'\n').encode())
print(json.dumps(state))
