"""Exercise real collected report data and owned rejection boundaries, without GitHub or DOM mocks."""
import copy
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
import zipfile

ROOT = Path(__file__).resolve().parent.parent
SOURCE = ROOT / '.cache/collect-range-general-ci-40135020046.py'
specification = importlib.util.spec_from_file_location('general_reader', SOURCE)
reader = importlib.util.module_from_spec(specification)
specification.loader.exec_module(reader)
DIRECTORIES = sorted(filename.parent for filename in reader.OUTPUT.glob('*/artifact.zip'))
assert len(DIRECTORIES) >= 6
EXAMPLE = next(directory for directory in DIRECTORIES if directory.name == 'benchmark-linux-0')
METADATA = json.loads((EXAMPLE / 'artifact.json').read_bytes())


class CiReportReader(unittest.TestCase):
    def test_every_actual_archive_and_report_member_authenticates(self):
        for directory in DIRECTORIES:
            with self.subTest(artifact=directory.name):
                reader.authenticate_artifact(json.loads((directory / 'artifact.json').read_bytes()), directory / 'artifact.zip')
                with zipfile.ZipFile(directory / 'artifact.zip') as archive:
                    reader.verify_manifest(archive, json.loads(archive.read('artifact-manifest.json')))

    def test_another_source_or_run_cannot_borrow_the_digest(self):
        for field, value in [('id', reader.RUN_ID + 1), ('head_sha', '0' * 40)]:
            changed = copy.deepcopy(METADATA)
            changed['workflow_run'][field] = value
            with self.assertRaises(AssertionError):
                reader.authenticate_artifact(changed, EXAMPLE / 'artifact.zip')

    def test_another_digest_or_size_cannot_describe_the_same_file(self):
        for field, value in [('size_in_bytes', METADATA['size_in_bytes'] + 1), ('digest', 'sha256:' + '0' * 64)]:
            with self.assertRaises(AssertionError):
                reader.authenticate_artifact({**METADATA, field: value}, EXAMPLE / 'artifact.zip')

    def test_a_changed_sample_hash_is_rejected(self):
        with zipfile.ZipFile(EXAMPLE / 'artifact.zip') as archive:
            manifest = json.loads(archive.read('artifact-manifest.json'))
            entry = next(entry for entry in manifest['entries'] if entry['kind'] == 'file')
            entry['sha256'] = '0' * 64
            with self.assertRaises(AssertionError):
                reader.verify_manifest(archive, manifest)

    def test_incomplete_or_differently_attributed_report_dto_is_rejected(self):
        with zipfile.ZipFile(EXAMPLE / 'artifact.zip') as archive:
            original = json.loads(archive.read('artifact-manifest.json'))
            for field, value in [('complete', False), ('complete', 'true'), ('complete', 1), ('githubRunId', '1'), ('githubRunAttempt', '2'), ('filesCopied', 0), ('bytesCopied', 0)]:
                with self.subTest(field=field), self.assertRaises(AssertionError):
                    reader.verify_manifest(archive, {**original, field: value})

    def test_duplicated_manifest_entries_cannot_inflate_copy_totals(self):
        with zipfile.ZipFile(EXAMPLE / 'artifact.zip') as archive:
            manifest = json.loads(archive.read('artifact-manifest.json'))
            entry = next(entry for entry in manifest['entries'] if entry['kind'] == 'file')
            manifest['entries'].append(copy.deepcopy(entry))
            manifest['filesCopied'] += 1
            manifest['bytesCopied'] += entry['bytes']
            with self.assertRaises(AssertionError):
                reader.verify_manifest(archive, manifest)

    def test_exclusive_preservation_never_replaces_different_original_bytes(self):
        parent = (ROOT / '.cache').resolve(strict=True)
        directory = Path(tempfile.mkdtemp(prefix='range-ci-reader-owned-', dir=parent)).resolve(strict=True)
        try:
            filename = directory / 'data'
            reader.preserve(filename, b'original')
            reader.preserve(filename, b'original')
            with self.assertRaises(AssertionError):
                reader.preserve(filename, b'replacement')
            self.assertEqual(filename.read_bytes(), b'original')
        finally:
            self.assertEqual(directory.resolve(strict=True), directory)
            self.assertEqual(directory.parent, parent)
            self.assertTrue(directory.name.startswith('range-ci-reader-owned-'))
            self.assertFalse(directory.is_symlink())
            shutil.rmtree(directory)

    def test_optimized_cli_stops_before_transport(self):
        result = subprocess.run([sys.executable, '-O', '-B', str(SOURCE)], cwd=ROOT, capture_output=True, text=True)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('requires non-optimized Python', result.stderr)


if __name__ == '__main__':
    unittest.main(verbosity=2)
