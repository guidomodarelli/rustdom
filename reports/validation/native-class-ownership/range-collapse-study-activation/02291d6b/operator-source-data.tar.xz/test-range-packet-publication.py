"""Verify the real publication CLI refuses disabled assertions before modifying evidence or HANDOFF."""
import hashlib
import os
from pathlib import Path
import subprocess
import sys
import unittest

ROOT = Path(__file__).resolve().parent.parent
SCRIPT = ROOT / '.cache/publish-range-activation-packet.py'
PACKET = ROOT / 'reports/validation/native-class-ownership/range-collapse-study-activation/02291d6b'


def identity():
    files = [ROOT / 'reports/progress/HANDOFF.md']
    if PACKET.exists():
        files.extend(filename for filename in PACKET.rglob('*') if filename.is_file())
    return {str(filename.relative_to(ROOT)): hashlib.sha256(filename.read_bytes()).hexdigest() for filename in files}


class PublicationSafety(unittest.TestCase):
    def verify_refusal(self, arguments, environment):
        original = identity()
        existed = PACKET.exists()
        result = subprocess.run([sys.executable, *arguments, '-B', str(SCRIPT)], cwd=ROOT, env=environment,
                                capture_output=True, text=True)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('requires non-optimized Python; no evidence or HANDOFF was modified', result.stderr)
        self.assertEqual(identity(), original)
        self.assertEqual(PACKET.exists(), existed)

    def test_explicit_optimization_is_rejected(self):
        self.verify_refusal(['-O'], os.environ.copy())

    def test_environment_optimization_is_rejected(self):
        self.verify_refusal([], {**os.environ, 'PYTHONOPTIMIZE': '1'})


if __name__ == '__main__':
    unittest.main(verbosity=2)
