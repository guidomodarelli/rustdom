"""Exercise the owned activation DTO and exclusive intent with real files; never fake gh, call activation, or run a sampler."""
import copy
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

repository=Path(__file__).resolve().parent.parent
filename=repository/'.cache/activate-range-study-02291d6b.py'
spec=importlib.util.spec_from_file_location('current_range_activation',filename)
activation=importlib.util.module_from_spec(spec);spec.loader.exec_module(activation)
latest=json.loads((activation.OBSERVATIONS/'latest.json').read_bytes())
# Explicitly synthetic OWNED DTO, not an upstream response or evidence that CI passed.
fixture=copy.deepcopy(latest)
for field in ['primaryClean','sourcePinsVerified','foreignChangesPreserved','standingAuthorization','currentPullOpen',
 'currentPullHeadMatches','labelAbsent','labelDefined','noEarlierStudyAtThisHead','watchUnconsumed','intentAbsent','methodCiPassed','generalCiPassed']:
 fixture[field]=True
fixture['requiredChecksPassed']={name:True for name in activation.POLICY['requiredChecks']}
fixture['syntheticFixture']=True


class ActivationBoundary(unittest.TestCase):
 def test_optimized_cli_refuses_before_readiness_or_activation(self):
  for mode in ['--inspect','--activate']:
   result=subprocess.run([sys.executable,'-O','-B',str(filename),mode],cwd=repository,capture_output=True,text=True)
   self.assertNotEqual(result.returncode,0)
   self.assertIn('requires non-optimized Python; no mutation was attempted',result.stderr)

 def test_complete_owned_fixture_is_accepted_by_the_pure_gate(self):
  activation.assert_ready(fixture)

 def test_an_aggregate_ready_flag_cannot_replace_pending_observations(self):
  changed=copy.deepcopy(latest); changed['ready']=True
  if not latest['ready']:
   with self.assertRaises(AssertionError): activation.assert_ready(changed)
  else:
   changed['generalCiPassed']=False
   with self.assertRaises(AssertionError): activation.assert_ready(changed)

 def test_every_required_condition_rejects_false_and_truthy_nonbooleans(self):
  for field,value in fixture.items():
   if value is not True or field in ['syntheticFixture','ready']: continue
   for invalid in [False,'true',1]:
    with self.subTest(field=field,invalid=invalid):
     changed=copy.deepcopy(fixture);changed[field]=invalid
     with self.assertRaises(AssertionError): activation.assert_ready(changed)

 def test_another_head_cannot_consume_this_authorization(self):
  changed=copy.deepcopy(fixture);changed['head']='0'*40
  with self.assertRaises(AssertionError): activation.assert_ready(changed)

 def test_missing_extra_and_non_successful_checks_are_rejected(self):
  for action in ['missing','extra','failed','truthy']:
   changed=copy.deepcopy(fixture);name=next(iter(changed['requiredChecksPassed']))
   if action=='missing':del changed['requiredChecksPassed'][name]
   if action=='extra':changed['requiredChecksPassed']['different-workflow']=True
   if action=='failed':changed['requiredChecksPassed'][name]=False
   if action=='truthy':changed['requiredChecksPassed'][name]='success'
   with self.subTest(action=action), self.assertRaises(AssertionError):activation.assert_ready(changed)

 def test_exclusive_intent_preserves_the_first_claim_and_refuses_pending_state(self):
  parent=(repository/'.cache').resolve(strict=True)
  directory=Path(tempfile.mkdtemp(prefix='range-activation-owned-test-',dir=parent)).resolve(strict=True)
  try:
   intent=directory/'claim'
   activation.claim_intent(intent,fixture)
   marker=intent/'activation-intent.json';original=marker.read_bytes()
   self.assertTrue(json.loads(original)['readiness']['syntheticFixture'])
   with self.assertRaises(FileExistsError):activation.claim_intent(intent,fixture)
   self.assertEqual(marker.read_bytes(),original)
   activation.preserve(intent,'mutation-issued.json',{'syntheticFixture':True,'activationMutationCount':1})
   issued=(intent/'mutation-issued.json').read_bytes()
   with self.assertRaises(FileExistsError):activation.preserve(intent,'mutation-issued.json',{'activationMutationCount':2})
   self.assertEqual((intent/'mutation-issued.json').read_bytes(),issued)
   changed=copy.deepcopy(fixture);changed['generalCiPassed']=False
   rejected=directory/'not-claimed'
   with self.assertRaises(AssertionError):activation.claim_intent(rejected,changed)
   self.assertFalse(rejected.exists())
  finally:
   self.assertEqual(directory.resolve(strict=True),directory);self.assertEqual(directory.parent,parent)
   self.assertTrue(directory.name.startswith('range-activation-owned-test-'))
   self.assertFalse(directory.is_symlink());shutil.rmtree(directory)


if __name__=='__main__':unittest.main(verbosity=2)
