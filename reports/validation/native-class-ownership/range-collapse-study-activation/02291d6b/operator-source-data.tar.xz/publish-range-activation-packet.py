"""Preserve already verified QA and the single actual activation, without changing any scientific pin."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile

if sys.flags.optimize:
    raise RuntimeError('Range packet publication requires non-optimized Python; no evidence or HANDOFF was modified')

ROOT = Path(__file__).resolve().parent.parent
HEAD = '02291d6b7a234a26ffaf364a1f377766e2338e7a'
JOURNAL = ROOT / '.cache/range-study-trigger-02291d6b'
PACKET = ROOT / 'reports/validation/native-class-ownership/range-collapse-study-activation/02291d6b'


def digest(filename):
    return hashlib.sha256(filename.read_bytes()).hexdigest()


def main():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == HEAD
    assert not subprocess.check_output(['git', 'status', '--short'], cwd=ROOT, text=True).strip()
    run = json.loads((JOURNAL / 'run-pin.json').read_bytes())
    job = json.loads((JOURNAL / 'job-pin.json').read_bytes())
    assert run['head'] == HEAD and job['runId'] == run['runId'] and job['attempt'] == 1
    issued = json.loads((JOURNAL / 'mutation-issued.json').read_bytes())
    applied = json.loads((JOURNAL / 'label-applied.json').read_bytes())
    assert issued['activationMutationCount'] == applied['labelApplications'] == 1
    readiness = json.loads((JOURNAL / 'activation-intent.json').read_bytes())['readiness']
    assert readiness['ready'] and all(readiness['requiredChecksPassed'].values())
    qa = ROOT / '.cache/range-activation-qa-02291d6b'
    for name in ['review.json', 'observer-review.json']:
        review = json.loads((qa / name).read_bytes())
        assert review['actionableFindings'] == 0
        for filename, expected in review['files'].items():
            assert digest(ROOT / '.cache' / filename) == expected
    method = ROOT / '.cache/range-method-ci-collection-40135020053'
    verified = json.loads((method / 'verified-method-qa.json').read_bytes())
    assert verified['head'] == HEAD and verified['methodPins'] == 563
    general = ROOT / '.cache/range-general-ci-collection-40135020046'
    general_qa = json.loads((general / 'latest.json').read_bytes())
    assert general_qa['status'] == 'completed' and general_qa['conclusion'] == 'success'
    assert len(general_qa['artifacts']) == 7
    pins = json.loads((ROOT / 'reports/validation/native-class-ownership/range-collapse-study-method/review.json').read_bytes())['files']
    for name, expected in pins.items():
        assert digest(ROOT / name) == expected, name
    assert not PACKET.exists()
    PACKET.mkdir(parents=True)
    shutil.copytree(JOURNAL, PACKET / 'activation')
    shutil.copytree(qa, PACKET / 'operator-qa')
    shutil.copytree(method, PACKET / 'method-ci')
    shutil.copytree(general, PACKET / 'general-ci')
    observations = ROOT / '.cache/range-capture-observations-02291d6b'
    first = json.loads((observations / 'latest.json').read_bytes())
    assert first['runId'] == run['runId'] and first['jobId'] == job['jobId']
    first_directory = ROOT / first['observationDirectory']
    shutil.copytree(first_directory, PACKET / 'first-capture-observation')
    checked = ROOT / readiness['observationDirectory']
    shutil.copytree(checked, PACKET / 'preactivation-checks')
    source_qa = Path('//wsl.localhost/Ubuntu-22.04/home/guido/rustdom-validation/range-collapse-source-qa-02291d6b')
    shutil.copytree(source_qa, PACKET / 'linux-source-qa')
    source_receipt = json.loads((PACKET / 'linux-source-qa/verification.json').read_bytes())
    assert source_receipt['sourceCommit'] == HEAD and source_receipt['clean'] and source_receipt['samplerInvoked'] is False
    scripts = ['activate-range-study-02291d6b.py', 'test-range-activation.py', 'observe-range-method-02291d6b.py',
        'observe-range-capture-02291d6b.py', 'test-range-capture-observer.py', 'collect-range-method-ci-40135020053.py',
        'verify-range-hosted-method-40135020053.py', 'prepare-range-replay-source-02291d6b.py',
        'collect-range-general-ci-40135020046.py', 'test-range-general-ci-reader.py',
        'test-range-packet-publication.py', 'publish-range-activation-packet.py']
    with tarfile.open(PACKET / 'operator-source-data.tar.xz', 'x:xz') as archive:
        for name in scripts:
            archive.add(ROOT / '.cache' / name, arcname=name)
    receipt = {'sourceCommit': HEAD, 'runId': run['runId'], 'jobId': job['jobId'], 'attempt': 1,
        'label': 'ownership-range-collapse-v1', 'labelApplications': 1, 'activationMutationCount': 1,
        'authorization': 'standingProjectAuthorization', 'requiresNewOperationalApproval': False,
        'sharedWatchModified': False, 'activationJournalAuthoritative': True,
        'methodCiRunId': 40135020053, 'generalCiRunId': 40135020046, 'allEightRequiredChecksPassed': True,
        'operatorTestsPassed': 7, 'observerTestsPassed': 8, 'operatorReviewFindings': 0,
        'hostedPackageTestsPerNode': 14, 'hostedMethodTestsPerNode': 19,
        'generalCiReportArtifacts': 7,
        'methodPinsPreserved': 563, 'historicalPinsPreserved': 511, 'sourceHarnessFiles': 434,
        'captureResultPending': True, 'performanceAccepted': None, 'historicalGateReevaluated': False,
        'runtime': 'hybrid', 'migrationComplete': False, 'tagCreated': False, 'merged': False}
    (PACKET / 'activation.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
    document = f'''# Captura única de collapse activada

El SHA `{HEAD}` aprobó los ocho checks requeridos antes de aplicar una sola vez
`ownership-range-collapse-v1`. Run [{run['runId']}](https://github.com/guidomodarelli/rustdom/actions/runs/{run['runId']}),
job `{job['jobId']}`, intento1. Autorización permanente: no pedir permiso ni
reaplicar etiquetas, relanzar o completar muestras. Presupuestos ±2%/±5%, captura
de 175 minutos dentro de un job de 180 minutos y todos los pins permanecen intactos.

Los cuatro ZIP del CI de contratos40135020053 se conservan íntegros con API,
logs, CRC, tamaño/digest y manifiestos completos: 14 tests de paquetes y 19 del método
por Node 22.12.0/24.14.1. El checkout Linux real del SHA publicado está limpio;
`--plan`/`--preflight` dan resultados idénticos entre los dos Node fijados, sin
invocar el sampler. Las identidades originales de las preparaciones se conservan.

También se conservan los siete ZIP de reportes del CI general: validación en
tres sistemas y los cuatro shards de benchmarks, con API, logs, CRC, manifiestos
y cada miembro autenticado. El checkout de ese CI es el merge sintético
`28236ed8b1da003a9770c6c20ae3945767c12267`, vinculado por sus padres al head
`02291d6b`; se preserva sin normalizarlo. Son muestras del CI existente, no
una repetición ni aceptación del nuevo estudio.

El activador pasó 7 contratos y el observador 8. Revisión aislada final sin
hallazgos: se cerraron el reemplazo no atómico del watch y el pin prematuro de
runs omitidos de otras etiquetas. La intención y los eventos exclusivos impiden
repetir el POST incluso ante una respuesta incierta. El observador exige PR80,
SHA, fecha del journal y job `compare` iniciado antes de fijar un run; después
consulta exclusivamente ese run/job y conserva fallos o rechazos.

El estado de activación autoritativo es `activation/`, respaldado por el sidecar
privado `watch-80.range-collapse-02291d6b.json`. No se reemplazó el watch compartido
ni sus autorizaciones/cambios concurrentes: sus contadores anteriores no revocan
los eventos del journal. `operator-source-data.tar.xz` preserva código operativo
como datos históricos; no ejecutarlo para activar otra secuencia.

El resultado está pendiente. No hay aceptación de rendimiento, reevaluación del
gate histórico, tag ni merge de ownership. Preservar ZIP/tar y parciales aun
ante fallo/rechazo; leer con código actual y ambos Node fijados. Los snapshots y
pruebas finitas no miden memoria pico ni garantizan ausencia universal de fugas.
Runtime híbrido; migración general pendiente; 48 entradas ajenas preservadas.
'''
    (PACKET / 'README.md').write_text(document, encoding='utf-8')
    files = [{'path': str(filename.relative_to(ROOT)).replace('\\', '/'), 'bytes': filename.stat().st_size, 'sha256': digest(filename)}
             for filename in sorted(PACKET.rglob('*')) if filename.is_file()]
    (PACKET / 'files.json').write_text(json.dumps({'files': files}, indent=2) + '\n', encoding='utf-8')
    handoff = ROOT / 'reports/progress/HANDOFF.md'
    assert str(handoff.relative_to(ROOT)).replace('\\', '/') not in pins
    prefix = f'''## Captura única de collapse activada — 2026-10-24

SHA fuente 02291d6b; run {run['runId']}/job {job['jobId']}/intento 1. Se aplicó
UNA vez ownership-range-collapse-v1 después de los ocho checks aprobados.
Evidencia operativa y CI: reports/validation/native-class-ownership/range-collapse-study-activation/02291d6b/.
Método de 563 pins, incluidos 511 históricos y arnés de 434 archivos, intactos. No repetir secuencia,
reaplicar etiqueta ni completar muestras. Captura de 175 min/job de 180 min/worker de 180000 ms,
presupuestos ±2%/±5%; conservar íntegros resultados, rechazos y parciales.

El journal exclusivo de activación y el sidecar watch-80.range-collapse-02291d6b.json
son autoritativos para esta ejecución; los campos anteriores del watch compartido
no se sobrescribieron para preservar autorizaciones y cambios concurrentes.
Activador con 7 tests/observador con 8 tests y reviews aisladas sin hallazgos. Cuatro artifacts
de contratos autenticados: 14 tests de paquetes/19 del método por Node 22.12.0/24.14.1. Checkout
Linux real limpio de 022 preparado para replay actual, sin ejecutar código archivado.

Próximo paso: observar solo este run/job. Al terminar autenticar ZIP/tar por
ID/run/head/intento/nombre/tamaño/digest; preservar logs, manifiesto completo y
todos los datos. Replay actual study.cjs --verify con los dos Node fijados.
Plan de 2048 procesos/18432 medidas/6144 warmup, 24576 Window y 24576 Document separados,
3 rondas/2 estados finales claros por proceso, baselines y 3 snapshots del padre.
No hay resultado ni aceptación todavía; sin tag/merge hasta decisión íntegra e
integración probada del gate. Autorización permanente, sin nuevas preguntas.
Runtime híbrido; migración general pendiente; 48 entradas ajenas preservadas.

'''
    content = handoff.read_bytes()
    title = b'# Continuar rustdom en otra m\xc3\xa1quina\n\n'
    assert content.startswith(title)
    handoff.write_bytes(title + prefix.encode() + content[len(title):])
    for name, expected in pins.items():
        assert digest(ROOT / name) == expected, name
    print(json.dumps(receipt))


if __name__ == '__main__':
    main()
