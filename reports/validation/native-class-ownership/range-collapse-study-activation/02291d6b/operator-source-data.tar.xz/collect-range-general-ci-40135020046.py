"""Preserve every completed report artifact of the exact general CI, without running benchmarks or archived code."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent.parent
OUTPUT = ROOT / '.cache/range-general-ci-collection-40135020046'
HEAD = '02291d6b7a234a26ffaf364a1f377766e2338e7a'
RUN_ID = 40135020046
JOBS = {'validation-ubuntu-22.04': 120994598803, 'validation-windows-latest': 120994598938,
    'validation-macos-latest': 120994599002, 'benchmark-linux-0': 120994598955,
    'benchmark-linux-1': 120994599077, 'benchmark-linux-2': 120994598931, 'benchmark-linux-3': 120994599076}
if not __debug__:
    raise RuntimeError('General CI collection requires non-optimized Python')


def preserve(filename, content):
    """Repeated transport may authenticate the same object but cannot replace its original bytes."""
    if filename.exists():
        assert filename.read_bytes() == content, str(filename)
    else:
        with filename.open('xb') as output:
            output.write(content)


def authenticate_artifact(artifact, filename):
    """Bind the exact source run to the API size/digest and ZIP CRC, without revalidating unrelated provider fields."""
    assert artifact['workflow_run']['id'] == RUN_ID and artifact['workflow_run']['head_sha'] == HEAD
    assert filename.stat().st_size == artifact['size_in_bytes']
    assert 'sha256:' + hashlib.sha256(filename.read_bytes()).hexdigest() == artifact['digest']
    with zipfile.ZipFile(filename) as archive:
        assert archive.testzip() is None


def verify_manifest(archive, manifest):
    """Validate this project's own artifact DTO against every real ZIP member and preserved sample byte."""
    assert manifest['complete'] is True and manifest['githubRunId'] == str(RUN_ID) and manifest['githubRunAttempt'] == '1'
    entries = [entry for entry in manifest['entries'] if entry['kind'] == 'file']
    assert len({entry['artifactPath'] for entry in entries}) == len(entries)
    actual = {member.filename for member in archive.infolist() if not member.is_dir()}
    assert actual == {'artifact-manifest.json', *[entry['artifactPath'] for entry in entries]}
    for entry in entries:
        content = archive.read(entry['artifactPath'])
        assert len(content) == entry['bytes'] and hashlib.sha256(content).hexdigest() == entry['sha256']
    assert manifest['filesCopied'] == len(entries) and manifest['bytesCopied'] == sum(entry['bytes'] for entry in entries)
    return entries


def main():
    owner = {'runId': RUN_ID, 'head': HEAD, 'attempt': 1, 'purpose': 'general-ci-report-preservation-v1'}
    if not OUTPUT.exists():
        OUTPUT.mkdir()
    marker = OUTPUT / 'owner.json'
    if marker.exists():
        assert json.loads(marker.read_bytes()) == owner
    else:
        assert not any(OUTPUT.iterdir()), 'Preserve unowned output'
        preserve(marker, (json.dumps(owner, indent=2) + '\n').encode())
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    observation = OUTPUT / 'observations' / stamp
    observation.mkdir(parents=True)
    def api(endpoint):
        return subprocess.check_output(['gh', 'api', 'repos/guidomodarelli/rustdom/' + endpoint], cwd=ROOT)
    records = {}
    for name, suffix in [('run', ''), ('jobs', '/jobs?per_page=100'), ('artifacts', '/artifacts?per_page=100')]:
        raw = api(f'actions/runs/{RUN_ID}' + suffix)
        preserve(observation / (name + '.json'), raw)
        records[name] = json.loads(raw)
    run = records['run']
    assert run['id'] == RUN_ID and run['head_sha'] == HEAD and run['run_attempt'] == 1
    assert run['path'].split('@', 1)[0] == '.github/workflows/ci.yml'
    jobs = {job['id']: job for job in records['jobs']['jobs']}
    results = []
    for artifact in records['artifacts']['artifacts']:
        name = artifact['name']
        if name not in JOBS or jobs[JOBS[name]]['status'] != 'completed':
            continue
        assert artifact['workflow_run']['id'] == RUN_ID and artifact['workflow_run']['head_sha'] == HEAD
        directory = OUTPUT / name
        directory.mkdir(exist_ok=True)
        preserve(directory / 'artifact.json', (json.dumps(artifact, indent=2) + '\n').encode())
        filename = directory / 'artifact.zip'
        if not filename.exists():
            partial = directory / (stamp + '.zip.part')
            with partial.open('xb') as destination:
                subprocess.run(['gh', 'api', f'repos/guidomodarelli/rustdom/actions/artifacts/{artifact["id"]}/zip'],
                               cwd=ROOT, stdout=destination, check=True)
            authenticate_artifact(artifact, partial)
            partial.rename(filename)
        authenticate_artifact(artifact, filename)
        if not (directory / 'job.log').exists():
            preserve(directory / 'job.log', api(f'actions/jobs/{JOBS[name]}/logs'))
        log = (directory / 'job.log').read_bytes()
        with zipfile.ZipFile(filename) as archive:
            assert archive.testzip() is None
            manifest = json.loads(archive.read('artifact-manifest.json'))
            entries = verify_manifest(archive, manifest)
            assert manifest['sourceCommit'].encode() in log
            checkout_path = directory / 'checkout-commit.json'
            if not checkout_path.exists():
                preserve(checkout_path, api('git/commits/' + manifest['sourceCommit']))
            checkout = json.loads(checkout_path.read_bytes())
            assert checkout['sha'] == manifest['sourceCommit']
            assert HEAD in [parent['sha'] for parent in checkout['parents']]
            preserve(directory / 'manifest.json', (json.dumps(manifest, indent=2) + '\n').encode())
            members = [{'path': member.filename, 'bytes': member.file_size,
                        'sha256': hashlib.sha256(archive.read(member)).hexdigest()} for member in archive.infolist() if not member.is_dir()]
            preserve(directory / 'members.json', (json.dumps(members, indent=2) + '\n').encode())
        results.append({'name': name, 'jobId': JOBS[name], 'jobConclusion': jobs[JOBS[name]]['conclusion'],
                        'artifactId': artifact['id'], 'zipBytes': artifact['size_in_bytes'], 'digest': artifact['digest'],
                        'files': len(entries), 'actualCheckoutCommit': manifest['sourceCommit']})
    summary = {**owner, 'status': run['status'], 'conclusion': run['conclusion'], 'observedAtUTC': stamp,
               'artifacts': results, 'collectorExecutedDOM': False, 'performanceAccepted': None,
               'benchmarkSamplesAreFromExistingCi': True}
    preserve(observation / 'collection.json', (json.dumps(summary, indent=2) + '\n').encode())
    (OUTPUT / 'latest.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
