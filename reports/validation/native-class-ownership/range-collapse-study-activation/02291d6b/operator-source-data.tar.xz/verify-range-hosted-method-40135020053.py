"""Read complete hosted QA with current source expectations, retaining original source identities and reports."""
import hashlib
import json
from pathlib import Path
import re
import zipfile

ROOT = Path(__file__).resolve().parent.parent
HEAD = '02291d6b7a234a26ffaf364a1f377766e2338e7a'
COLLECTION = ROOT / '.cache/range-method-ci-collection-40135020053'
review = json.loads((ROOT / 'reports/validation/native-class-ownership/range-collapse-study-method/review.json').read_bytes())
results = []
preflights = []
for key, expected_count in [('packages-node22', 14), ('packages-node24', 14), ('method-node22', 19), ('method-node24', 19)]:
    directory = COLLECTION / key
    metadata = json.loads((directory / 'artifact.json').read_bytes())
    assert metadata['workflow_run']['id'] == 40135020053 and metadata['workflow_run']['head_sha'] == HEAD
    assert metadata['size_in_bytes'] == (directory / 'artifact.zip').stat().st_size
    assert metadata['digest'] == 'sha256:' + hashlib.sha256((directory / 'artifact.zip').read_bytes()).hexdigest()
    with zipfile.ZipFile(directory / 'artifact.zip') as archive:
        assert archive.testzip() is None
        name = 'range-method-contracts.log' if key.startswith('method-') else 'range-packages-contracts.log'
        report = archive.read(name).decode('utf-8')
        def summary(field):
            values = re.findall(r'^(?:#|ℹ) ' + field + r' (\d+)\s*$', report, re.MULTILINE)
            assert len(values) == 1, (key, field)
            return int(values[0])
        assert summary('tests') == summary('pass') == expected_count
        for field in ['fail', 'cancelled', 'skipped', 'todo']:
            assert summary(field) == 0
        if key.startswith('method-'):
            value = json.loads(archive.read('range-method-preflight.json'))
            assert value['revision'] == 'ownership-range-collapse-v1'
            assert value['samplerInvoked'] is False and value['performanceAccepted'] is None
            assert value['historicalGateReevaluated'] is False and value['scheduleLayout'] == 'adjacent-paired-row-v1'
            assert value['files'] == review['files'] and len(value['files']) == 563
            identity = value['harness']['identity']
            assert identity['sourceCommit'] == HEAD and identity['sourceChanges'] == identity['sourceGitErrors'] == []
            assert len(value['harness']['files']) == 434
            assert value['harness']['sha256'] == '97284800087ef5e3a1e53d87a338a1e366cec220e654fd289d6b02bc8d812c7b'
            preflights.append(value)
        results.append({'key': key, 'artifactId': metadata['id'], 'passed': expected_count, 'failed': 0,
                        'zipBytes': metadata['size_in_bytes'], 'digest': metadata['digest']})
# Only independently meaningful identity fields are compared; no archived provenance is rewritten.
for field in ['revision', 'settings', 'files', 'harness', 'scheduleLayout']:
    assert preflights[0][field] == preflights[1][field], field
result = {'runId': 40135020053, 'head': HEAD, 'attempt': 1, 'results': results,
          'methodPins': 563, 'harnessFiles': 434, 'hostedSourceClean': True,
          'crossNodeMethodIdentityEqual': True, 'samplerInvoked': False, 'performanceAccepted': None}
with (COLLECTION / 'verified-method-qa.json').open('x', encoding='utf-8') as output:
    json.dump(result, output, indent=2)
print(json.dumps(result))
