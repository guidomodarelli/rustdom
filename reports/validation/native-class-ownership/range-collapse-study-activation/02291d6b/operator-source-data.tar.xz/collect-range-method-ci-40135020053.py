"""Configure the published read-only transport for the exact four completed method jobs; never execute archived code."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import zipfile

if sys.flags.optimize:
    raise RuntimeError('Method collection requires non-optimized Python')

ROOT = Path(__file__).resolve().parent.parent
HEAD = '02291d6b7a234a26ffaf364a1f377766e2338e7a'
RUN_ID = 40135020053
SOURCE = ROOT / 'reports/validation/native-class-ownership/range-collapse-hosted/40128890776/tools/collect.py'
OUTPUT = ROOT / '.cache/range-method-ci-collection-40135020053'
JOBS = [
    ('packages-node22', 120994598883, 'range-packages-contracts-node22.12.0-', 12576607510, 1647, 'a6b690555200d37a87eeb28937cd6ba238e1207394dd56ad21b78f5fb0e2c464'),
    ('packages-node24', 120994598680, 'range-packages-contracts-node24.14.1-', 12575858906, 1276, '54df9176d0fbc49614f4461b5bbc6da2d7d97ab7154f179af0b08dbfc8e42de3'),
    ('method-node22', 120994932585, 'range-method-contracts-node22.12.0-', 12576822616, 195313, 'ff1207f08d7fb10d8705740bbc80e52283e2facc034dc2f786085c0e0ab5d8bd'),
    ('method-node24', 120994932580, 'range-method-contracts-node24.14.1-', 12576622811, 195110, '6f797be0a4153def4b36ed78ed94596ec4a0796853d141a42e2d4b4265abe5c2'),
]


def collect():
    """Use current published source with explicit owned configuration and authenticate the entire real archive."""
    specification = importlib.util.spec_from_file_location('range_method_current_transport', SOURCE)
    transport = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(transport)
    transport.POLICY = {'revision': 'range-method-ci-transport-v1', 'repository': 'guidomodarelli/rustdom',
        'runId': RUN_ID, 'head': HEAD, 'attempt': 1, 'ownerFile': 'collector-owner.json',
        'workflow': '.github/workflows/range-collapse-study-contracts.yml',
        'jobs': [{'key': key, 'id': job_id, 'artifactName': prefix + HEAD,
                  'artifactPin': {'id': artifact_id, 'zipBytes': size, 'zipSha256': checksum}}
                 for key, job_id, prefix, artifact_id, size, checksum in JOBS]}
    result = transport.collect(ROOT, OUTPUT, True)
    run = json.loads((OUTPUT / 'run.json').read_bytes())
    assert run['run_attempt'] == 1 and run['status'] == 'completed' and run['conclusion'] == 'success'
    assert result['authenticatedArtifacts'] == 4 and result['allJobsSucceeded'] is True
    manifests = {}
    for job in transport.POLICY['jobs']:
        directory = OUTPUT / job['key']
        members = []
        seen = set()
        with zipfile.ZipFile(directory / 'artifact.zip') as archive:
            for member in archive.infolist():
                assert member.filename not in seen
                seen.add(member.filename)
                checksum = hashlib.sha256()
                with archive.open(member) as content:
                    for chunk in iter(lambda: content.read(1024 * 1024), b''):
                        checksum.update(chunk)
                members.append({'path': member.filename, 'directory': member.is_dir(),
                                'bytes': member.file_size, 'sha256': checksum.hexdigest()})
            if job['key'].startswith('method-'):
                preflight = json.loads(archive.read('range-method-preflight.json'))
                (directory / 'preflight.json').write_text(json.dumps(preflight, indent=2) + '\n', encoding='utf-8')
        manifest = {'runId': RUN_ID, 'jobId': job['id'], 'attempt': 1, 'head': HEAD,
                    'artifact': job['artifactPin'], 'members': members, 'archivedCodeExecuted': False}
        filename = directory / 'members.json'
        encoded = (json.dumps(manifest, indent=2) + '\n').encode()
        if filename.exists():
            assert filename.read_bytes() == encoded, 'Preserve the first verified full manifest'
        else:
            filename.write_bytes(encoded)
        manifests[job['key']] = len(members)
    return {'runId': RUN_ID, 'attempt': 1, 'head': HEAD, 'authenticatedArtifacts': 4,
            'members': manifests, 'currentTransportSha256': transport.digest(SOURCE), 'archivedCodeExecuted': False}


if __name__ == '__main__':
    print(json.dumps(collect()))
