"""Create a real clean Linux Git checkout for current-code offline replay; never build packages or invoke DOM."""
import hashlib
import json
from pathlib import Path
import subprocess

WORKING = Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom')
SOURCE = Path('/home/guido/rustdom-validation/range-collapse-study-source-02291d6b')
OUTPUT = Path('/home/guido/rustdom-validation/range-collapse-source-qa-02291d6b')
HEAD = '02291d6b7a234a26ffaf364a1f377766e2338e7a'
RECEIPT = 'reports/validation/native-class-ownership/range-collapse-study-method/review.json'
PREPARATION = '/home/guido/rustdom-validation/range-collapse-study-qa/extracted-final/range-collapse-packages'
NODES = [
    ('node22', Path('/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node-22/bin/node'), 'v22.12.0', '177208bfc4a9403121a40c72d038c670f4fd937fa16ca7df0a720e90be0fe2d9'),
    ('node24', Path('/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node/bin/node'), 'v24.14.1', 'bf9112eb83a827dc9f9c8d19bb7bddcbf00f7b2fedae18fdcaee05406981f20a'),
]

assert not SOURCE.exists() and not OUTPUT.exists(), 'Preserve existing source or QA'
review = json.loads((WORKING / RECEIPT).read_bytes())
assert len(review['files']) == 563 and review['actionableFindings'] == 0
common = Path('/mnt/c/Users/guido/ghq/projects/rustdom/.git')
assert common.is_dir() and (common / 'objects').is_dir()
subprocess.run(['git', 'clone', '--shared', '--no-checkout', str(common), str(SOURCE)], check=True)
subprocess.run(['git', 'config', 'core.autocrlf', 'false'], cwd=SOURCE, check=True)
subprocess.run(['git', 'config', 'core.sparseCheckout', 'true'], cwd=SOURCE, check=True)
(SOURCE / '.git/info/sparse-checkout').write_text('\n'.join('/' + name for name in sorted([*review['files'], RECEIPT])) + '\n')
subprocess.run(['git', 'checkout', '--detach', HEAD], cwd=SOURCE, check=True)
assert (SOURCE / '.git').is_dir()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SOURCE, text=True).strip() == HEAD
assert not subprocess.check_output(['git', 'status', '--short'], cwd=SOURCE, text=True).strip()
for name, expected in review['files'].items():
    assert hashlib.sha256((SOURCE / name).read_bytes()).hexdigest() == expected, name
assert (SOURCE / RECEIPT).read_bytes() == (WORKING / RECEIPT).read_bytes()
OUTPUT.mkdir()
for key, node, version, expected in NODES:
    assert hashlib.sha256(node.read_bytes()).hexdigest() == expected
    assert subprocess.check_output([node, '--version'], text=True).strip() == version
    for operation in ['--plan', '--preflight']:
        command = [str(node), 'reports/benchmarks/native-class-ownership/range-collapse-study/study.cjs', operation]
        if operation == '--preflight':
            command.append(PREPARATION)
        stem = key + '-' + operation[2:]
        result = subprocess.run(command, cwd=SOURCE, capture_output=True)
        (OUTPUT / (stem + '.stdout.json')).write_bytes(result.stdout)
        (OUTPUT / (stem + '.stderr.log')).write_bytes(result.stderr)
        (OUTPUT / (stem + '.command.json')).write_text(json.dumps({'argv': command, 'exitCode': result.returncode,
            'nodeVersion': version, 'nodeSha256': expected, 'sourceCommit': HEAD, 'sourceChanges': [],
            'sourceGitErrors': [], 'samplerInvoked': False}, indent=2) + '\n')
        assert result.returncode == 0, result.stderr.decode()
for operation in ['plan', 'preflight']:
    assert (OUTPUT / ('node22-' + operation + '.stdout.json')).read_bytes() == (OUTPUT / ('node24-' + operation + '.stdout.json')).read_bytes()
assert not subprocess.check_output(['git', 'status', '--short'], cwd=SOURCE, text=True).strip()
receipt = {'sourceCommit': HEAD, 'source': str(SOURCE), 'realLinuxGitDirectory': True, 'clean': True,
    'methodPins': 563, 'nodeVersions': [entry[2] for entry in NODES], 'bothOperationsByteIdentical': True, 'samplerInvoked': False}
(OUTPUT / 'verification.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
