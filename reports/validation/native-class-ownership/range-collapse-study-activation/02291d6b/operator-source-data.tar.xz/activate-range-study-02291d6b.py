"""Inspect current readiness or issue one standing-authorized label mutation, with exclusive intent and no retries."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

if sys.flags.optimize:
    raise RuntimeError('Range activation requires non-optimized Python; no mutation was attempted')

ROOT = Path(__file__).resolve().parent.parent
HEAD = '02291d6b7a234a26ffaf364a1f377766e2338e7a'
REPOSITORY = 'guidomodarelli/rustdom'
POLICY = json.loads((ROOT / 'reports/benchmarks/native-class-ownership/range-collapse-study/constants/protocol.json').read_bytes())
WATCH = Path('C:/Users/guido/ghq/projects/rustdom/.codex-autofix/watch-80.json')
INTENT = ROOT / '.cache/range-study-trigger-02291d6b'
OBSERVATIONS = ROOT / '.cache/range-study-readiness-02291d6b'


def now():
    return datetime.now(timezone.utc).isoformat()


def api(endpoint, *arguments):
    return json.loads(subprocess.check_output(['gh', 'api', endpoint, *arguments], cwd=ROOT))


def preserve(directory, name, value):
    with (directory / name).open('x', encoding='utf-8', newline='\n') as destination:
        json.dump(value, destination, indent=2, ensure_ascii=False)
        destination.write('\n')


def assert_ready(readiness):
    """Only this owned DTO is validated; activation always constructs it from fresh local/API observations."""
    assert readiness['head'] == HEAD
    for condition in ['primaryClean', 'sourcePinsVerified', 'foreignChangesPreserved', 'standingAuthorization',
                      'currentPullOpen', 'currentPullHeadMatches', 'labelAbsent', 'labelDefined',
                      'noEarlierStudyAtThisHead', 'watchUnconsumed', 'intentAbsent', 'methodCiPassed', 'generalCiPassed']:
        assert readiness[condition] is True, 'Range activation: readiness condition pending: ' + condition
    checks = readiness['requiredChecksPassed']
    assert set(checks) == set(POLICY['requiredChecks'])
    assert all(value is True for value in checks.values()), 'Range activation: wait for every current-source check'


def inspect():
    """GET only, preserving all observations; no label or workflow operation is issued."""
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    clean = not subprocess.check_output(['git', 'status', '--short'], cwd=ROOT, text=True).strip()
    review = json.loads((ROOT / POLICY['publicationReceipt']).read_bytes())
    assert review['actionableFindings'] == 0 and review['revision'] == POLICY['revision'] and len(review['files']) == 563
    for name, expected in review['files'].items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == expected, name
    foreign = subprocess.check_output(['git', 'status', '--short'], cwd='C:/Users/guido/.codex/worktrees/native-collection-queries/rustdom', text=True)
    assert foreign.splitlines() == (ROOT / '.cache/jsdom-telemetry-foreign-wip-preserved.txt').read_text(encoding='utf-8-sig').splitlines()
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    directory = OBSERVATIONS / stamp
    directory.mkdir(parents=True)
    pull = api(f'repos/{REPOSITORY}/pulls/80'); preserve(directory, 'pull.json', pull)
    checks = api(f'repos/{REPOSITORY}/commits/{HEAD}/check-runs?per_page=100'); preserve(directory, 'checks.json', checks)
    method = api(f'repos/{REPOSITORY}/actions/runs/40135020053'); preserve(directory, 'method-run.json', method)
    general = api(f'repos/{REPOSITORY}/actions/runs/40135020046'); preserve(directory, 'general-run.json', general)
    labels = json.loads(subprocess.check_output(['gh', 'api', '--paginate', '--slurp', f'repos/{REPOSITORY}/labels?per_page=100'], cwd=ROOT))
    preserve(directory, 'repository-labels.json', labels)
    # The new workflow is not registered before its first labeled event. This complete head-bound
    # query checks that event history; the workflow itself enforces its complete global history before sampling.
    runs = json.loads(subprocess.check_output(['gh', 'api', '--paginate', '--slurp',
        f'repos/{REPOSITORY}/actions/runs?event=pull_request&head_sha={HEAD}&per_page=100'], cwd=ROOT))
    preserve(directory, 'head-runs.json', runs)
    for record, run_id, path in [(method, 40135020053, POLICY['contractsWorkflow']), (general, 40135020046, '.github/workflows/ci.yml')]:
        assert record['id'] == run_id and record['head_sha'] == HEAD and record['path'].split('@', 1)[0] == path
    state = json.loads(WATCH.read_bytes()); source = state['rangeCollapseStudyMethod']; grant = state['standingProjectAuthorization']
    current_checks = {name: [check for check in checks['check_runs'] if check['name'] == name and check['head_sha'] == HEAD]
                      for name in POLICY['requiredChecks']}
    passed = {name: len(selected) == 1 and selected[0]['status'] == 'completed' and selected[0]['conclusion'] == 'success'
              for name, selected in current_checks.items()}
    earlier = [run for page in runs for run in page['workflow_runs'] if run['path'].split('@', 1)[0] == POLICY['workflow'] and run['conclusion'] != 'skipped']
    readiness = {'head': head, 'primaryClean': clean, 'sourcePinsVerified': True, 'foreignChangesPreserved': True,
        'standingAuthorization': grant['requiresNewOperationalApproval'] is False and grant['instructionsCommit'] == 'fb18f6a0b911ec520f674a953edde9d4bbb132ce',
        'currentPullOpen': pull['state'] == 'open', 'currentPullHeadMatches': pull['head']['sha'] == HEAD,
        'labelAbsent': POLICY['label'] not in {entry['name'] for entry in pull['labels']},
        'labelDefined': POLICY['label'] in {entry['name'] for page in labels for entry in page},
        'noEarlierStudyAtThisHead': not earlier, 'historyScope': {'head': HEAD, 'workflow': POLICY['workflow'], 'event': 'pull_request'},
        'watchUnconsumed': source['publishedCommit'] == HEAD and source['labelApplications'] == 0 and source['captureActivated'] is False and source.get('activationMutationCount', 0) == 0,
        'intentAbsent': not INTENT.exists(), 'methodCiPassed': method['status'] == 'completed' and method['conclusion'] == 'success',
        'generalCiPassed': general['status'] == 'completed' and general['conclusion'] == 'success',
        'requiredChecksPassed': passed, 'observedAtUTC': now(), 'observationDirectory': str(directory.relative_to(ROOT)).replace('\\', '/')}
    try:
        assert_ready(readiness); readiness['ready'] = True
    except AssertionError as error:
        readiness['ready'] = False; readiness['pending'] = str(error)
    preserve(directory, 'readiness.json', readiness)
    (OBSERVATIONS / 'latest.json').write_text(json.dumps(readiness, indent=2) + '\n', encoding='utf-8')
    return readiness


def claim_intent(directory, readiness):
    """Atomically claim a fresh directory; even a crashed activation cannot silently issue another request."""
    assert_ready(readiness)
    directory.mkdir()
    preserve(directory, 'activation-intent.json', {'head': HEAD, 'revision': POLICY['revision'], 'pr': 80,
        'maximumLabelMutations': 1, 'authorization': 'standingProjectAuthorization', 'createdAtUTC': now(),
        'requestSemantics': 'POST the pull-request label once; after any uncertain response observe only, never retry',
        'readiness': readiness})


def activate():
    readiness = inspect(); assert_ready(readiness)
    claim_intent(INTENT, readiness)
    raw = WATCH.read_bytes(); state = json.loads(raw)
    method = state['rangeCollapseStudyMethod']
    assert method['labelApplications'] == 0 and method.get('activationMutationCount', 0) == 0
    # Refresh the remotely mutable head/label after persisting the intent, immediately before the only mutation.
    pull = api(f'repos/{REPOSITORY}/pulls/80')
    assert pull['state'] == 'open' and pull['head']['sha'] == HEAD
    assert POLICY['label'] not in {entry['name'] for entry in pull['labels']}
    grant = state['standingProjectAuthorization']
    assert grant['requiresNewOperationalApproval'] is False and grant['instructionsCommit'] == 'fb18f6a0b911ec520f674a953edde9d4bbb132ce'
    # Append only to this invocation's exclusively claimed journal. Never replace the shared watch:
    # a compare-then-replace sequence could lose unrelated concurrent updates.
    preserve(INTENT, 'mutation-issued.json', {'head': HEAD, 'activationMutationCount': 1,
        'activationStatus': 'mutation_issued_once_outcome_pending', 'issuedAtUTC': now(),
        'authorization': 'standingProjectAuthorization', 'requiresNewOperationalApproval': False,
        'sharedWatchObservedSha256': hashlib.sha256(raw).hexdigest(), 'sharedWatchModified': False})
    command = ['gh', 'api', f'repos/{REPOSITORY}/issues/80/labels', '--method', 'POST', '-f', f'labels[]={POLICY["label"]}']
    with (INTENT / 'activation.stdout.json').open('xb') as stdout, (INTENT / 'activation.stderr.log').open('xb') as stderr:
        result = subprocess.run(command, cwd=ROOT, stdout=stdout, stderr=stderr)
    preserve(INTENT, 'activation-command.json', {'argv': command, 'exitCode': result.returncode, 'issuedExactlyOnce': True})
    assert result.returncode == 0, 'Range activation: uncertain request outcome; observe read-only and never issue another label mutation'
    response = json.loads((INTENT / 'activation.stdout.json').read_bytes())
    assert POLICY['label'] in {entry['name'] for entry in response}
    preserve(INTENT, 'label-applied.json', {'head': HEAD, 'labelApplications': 1, 'captureActivated': True,
        'activationMutationCount': 1, 'activationStatus': 'label_applied_once_waiting_for_run', 'activatedAtUTC': now(),
        'nextAction': 'Observar únicamente el run resultante de02291d6b/intento1; no reaplicar etiqueta ni relanzar.',
        'sharedWatchModified': False})
    return {'head': HEAD, 'labelAppliedOnce': True, 'captureRunNotObservedYet': True, 'maximumSequences': 1}


if __name__ == '__main__':
    assert len(sys.argv) == 2 and sys.argv[1] in ['--inspect', '--activate']
    print(json.dumps(inspect() if sys.argv[1] == '--inspect' else activate()))
