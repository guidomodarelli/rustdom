import json, os, pathlib, shutil, subprocess, tempfile, time
repo = pathlib.Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom')
pointer = repo / '.cache/suite-timing-study-root.txt'
if pointer.exists(): raise SystemExit('Formal study pointer already exists; inspect its existing process, do not restart')
root = pathlib.Path(tempfile.mkdtemp(prefix='rustdom-runner-suite-timing-'))
pointer.write_text(str(root)+'\n')
shutil.copyfile(repo / '.cache/suite-timing-publication.json', root / 'publication.json')
shutil.copyfile(repo / '.cache/suite-timing-publication-verification.json', root / 'publication-verification.json')
nodes = ['/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node-22/bin/node', '/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node/bin/node']
argv = [nodes[1], str(repo / 'reports/benchmarks/native-class-ownership/runner-suite-timing/study.cjs'),
 '/tmp/rustdom-runner-suites-ytu9q4xb/static-prepared', str(root / 'publication.json'), str(root / 'results'), *nodes]
record = {'argv':argv,'root':str(root),'wrapperPid':os.getpid(),'terminal':False,'startedAtUnix':time.time()}
def save(): (root / 'driver-process.json').write_text(json.dumps(record,indent=2)+'\n')
save()
print(json.dumps(record),flush=True)
with open(root / 'driver.stdout.log','wb') as stdout, open(root / 'driver.stderr.log','wb') as stderr:
    child = subprocess.Popen(argv,cwd=repo,stdout=stdout,stderr=stderr)
    record['driverPid']=child.pid; save()
    print('driverPid='+str(child.pid),flush=True)
    exit_code=child.wait()
record.update(terminal=True,exitCode=exit_code,finishedAtUnix=time.time());save()
print(json.dumps(record),flush=True)
raise SystemExit(exit_code)
