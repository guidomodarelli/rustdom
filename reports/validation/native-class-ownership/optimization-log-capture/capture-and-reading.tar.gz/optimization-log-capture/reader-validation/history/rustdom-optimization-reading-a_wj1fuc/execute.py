import json,os,pathlib,shutil,subprocess,tempfile
repo=pathlib.Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom')
method=repo/'reports/benchmarks/native-class-ownership/optimization-log-results'
root=pathlib.Path('/tmp/rustdom-optimization-capture-zyog41xf')
validation=pathlib.Path(tempfile.mkdtemp(prefix='rustdom-optimization-reading-'))
(repo/'.cache/optimization-reading-root.txt').write_text(str(validation)+'\n',encoding='utf-8')
shutil.copytree(method,validation/'reader-source');shutil.copyfile(__file__,validation/'execute.py')
env=dict(os.environ,RUSTDOM_OPTIMIZATION_CAPTURE=str(root/'capture'))
commands=[('tests',['python3','-B','-m','unittest','discover','-s',str(method),'-p','test_read.py','-v']),
 ('reading',['python3','-B',str(method/'read.py'),str(root/'capture'),str(root/'reading-v2')])]
for name,argv in commands:
    child=subprocess.run(argv,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (validation/(name+'.stdout.log')).write_bytes(child.stdout);(validation/(name+'.stderr.log')).write_bytes(child.stderr)
    (validation/(name+'-process.json')).write_text(json.dumps({'argv':argv,'exitCode':child.returncode},indent=2)+'\n',encoding='utf-8')
    assert child.returncode==0,child.stderr.decode(errors='replace')
    print(name,child.returncode,child.stdout.decode()[:500],flush=True)
print(str(validation))
