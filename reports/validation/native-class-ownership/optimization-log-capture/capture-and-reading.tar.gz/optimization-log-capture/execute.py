import json,os,pathlib,shutil,subprocess,sys,tempfile,time
repo=pathlib.Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom')
pointer=repo/'.cache/optimization-capture-root.txt'
if pointer.exists():raise SystemExit('Capture pointer exists: inspect its existing handle, do not restart')
if (repo/'.cache/optimization-log-capture.started.json').exists():raise SystemExit('Capture guard already consumed; do not restart')
root=pathlib.Path(tempfile.mkdtemp(prefix='rustdom-optimization-capture-'))
pointer.write_text(str(root)+'\n',encoding='utf-8')
shutil.copyfile(__file__,root/'execute.py')
shutil.copyfile('/tmp/rustdom-optimization-method-67qtetar/inputs.json',root/'inputs.json')
shutil.copyfile(repo/'.cache/optimization-method-publication.json',root/'publication.json')
shutil.copyfile(repo/'.cache/optimization-method-publication-verification.json',root/'publication-verification.json')
argv=[sys.executable,'-B',str(repo/'reports/benchmarks/native-class-ownership/optimization-log/run.py'),'--capture',str(root/'inputs.json'),str(root/'capture'),str(root/'publication.json')]
record={'argv':argv,'root':str(root),'wrapperPid':os.getpid(),'terminal':False,'startedAtUnix':time.time()}
def save():(root/'driver-process.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
save();print(json.dumps(record),flush=True)
with (root/'driver.stdout.log').open('wb') as stdout,(root/'driver.stderr.log').open('wb') as stderr:
    child=subprocess.Popen(argv,cwd=repo,stdout=stdout,stderr=stderr)
    record['driverPid']=child.pid;save();print('driverPid='+str(child.pid),flush=True)
    exit_code=child.wait()
record.update(terminal=True,exitCode=exit_code,finishedAtUnix=time.time());save()
print(json.dumps(record),flush=True)
raise SystemExit(exit_code)
