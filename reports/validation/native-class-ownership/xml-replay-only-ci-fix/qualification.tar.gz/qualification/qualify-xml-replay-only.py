"""Windows launcher for real XML CLI contracts after the original seeded study ends."""
import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import tempfile
import time

repository = pathlib.Path(__file__).resolve().parent.parent
linux_repository = '/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom'
tools = pathlib.Path('C:/Users/guido/ghq/projects/rustdom/.tools')
linux_tools = '/mnt/c/Users/guido/ghq/projects/rustdom/.tools'
guard = ['wsl', '--exec', 'python3', linux_repository + '/.cache/archive-seeded-pre-gc-study.py', '--check-ready']
subprocess.run(guard, check=True)
marker = repository / '.cache/xml-replay-only-qualification-root.txt'
with marker.open('x', encoding='utf-8') as output:
    root = pathlib.Path(tempfile.mkdtemp(prefix='xml-replay-only-qualification-', dir=repository / '.cache'))
    output.write(str(root) + '\n')
(root / 'base-commit.txt').write_text(subprocess.check_output(
    ['git', 'rev-parse', 'HEAD'], cwd=repository, text=True), encoding='utf-8')

paths = ['.github/workflows/xml-controller.yml',
         'reports/benchmarks/native-class-ownership/xml-history.cjs',
         'reports/benchmarks/native-class-ownership/xml-history.spec.cjs',
         'reports/benchmarks/native-class-ownership/constants/xml-history.json']
sources = {}
for relative in paths:
    raw = (repository / relative).read_bytes()
    target = root / 'sources' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    sources[relative] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
(root / 'sources.json').write_text(json.dumps(sources, indent=2) + '\n', encoding='utf-8')
shutil.copyfile(__file__, root / pathlib.Path(__file__).name)
environment = dict(os.environ)
for name in ['NODE_OPTIONS', 'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS']:
    environment.pop(name, None)
rust_bin = linux_tools + '/rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin'
linux_path = subprocess.check_output(['wsl', '--exec', 'printenv', 'PATH'], text=True).strip()
linux_prefix = ['wsl', '--exec', 'env', '-u', 'NODE_OPTIONS', '-u', 'RUSTFLAGS', '-u', 'CARGO_ENCODED_RUSTFLAGS',
                'PATH=' + rust_bin + ':' + linux_path,
                'RUSTUP_HOME=' + linux_tools + '/rustup', 'CARGO_HOME=' + linux_tools + '/cargo']
compiler = subprocess.check_output(['wsl', '--exec', rust_bin + '/rustc', '-Vv'], text=True).strip()
settings = json.loads((repository / paths[-1]).read_bytes())
assert compiler == settings['rustc'], 'Install/use the declared Rust toolchain before qualifying the supported CLI profile'
(root / 'runtime-policy.json').write_text(json.dumps({'compiler': compiler,
    'clearedVariables': ['NODE_OPTIONS', 'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS'],
    'linuxOverrides': linux_prefix[3:]}, indent=2) + '\n', encoding='utf-8')

executables = [
    ('linux-node-22', linux_prefix + [linux_tools + '/node-22/bin/node'], 'v22.12.0'),
    ('linux-node-24', linux_prefix + [linux_tools + '/node/bin/node'], 'v24.14.1'),
    ('windows-node-22', [str(tools / 'node-win/node-v22.12.0-win-x64/node.exe')], 'v22.12.0'),
    ('windows-node-24', [str(tools / 'node-win/node-v24.22.1-win-x64/node.exe')], 'v24.22.1'),
]
results = []
for label, prefix, expected_version in executables:
    version = subprocess.check_output(prefix + ['--version'], text=True, env=environment).strip()
    (root / f'{label}.version.txt').write_text(version + '\n', encoding='utf-8')
    assert version == expected_version, f'{label}: expected {expected_version}, found {version}; use the declared executable before qualifying'
    test_file = linux_repository + '/reports/benchmarks/native-class-ownership/xml-history.spec.cjs' if label.startswith('linux') else str(repository / paths[2])
    command = prefix + ['--test', '--test-reporter=tap', test_file]
    record = {'command': command, 'node': version, 'cwd': str(repository), 'startedAt': time.time()}
    with (root / f'{label}.stdout.log').open('xb') as stdout, (root / f'{label}.stderr.log').open('xb') as stderr:
        child = subprocess.Popen(command, cwd=repository, env=environment, stdout=stdout, stderr=stderr)
        record['launcherPid'] = child.pid
        (root / f'{label}.process.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
        print(f'START {label} pid={child.pid}', flush=True)
        record['exitCode'] = child.wait()
    record['finishedAt'] = time.time()
    (root / f'{label}.process.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
    print(f'END {label} exit={record["exitCode"]}', flush=True)
    assert record['exitCode'] == 0, f'Preserve {label} logs and fix the failing contract before retrying'
    lines = (root / f'{label}.stdout.log').read_text(encoding='utf-8').splitlines()
    skipped = 4 if label.startswith('windows') else 0
    for expected in ['# tests 22', '# fail 0', '# cancelled 0', f'# skipped {skipped}', f'# pass {22 - skipped}']:
        assert expected in lines, (label, expected)
    results.append({'label': label, 'node': version, 'tests': 22, 'passed': 22 - skipped, 'skipped': skipped})
for relative, metadata in sources.items():
    raw = (repository / relative).read_bytes()
    assert len(raw) == metadata['bytes'] and hashlib.sha256(raw).hexdigest() == metadata['sha256']
(root / 'receipt.json').write_text(json.dumps({'complete': True, 'results': results,
    'sourceBytesUnchanged': True, 'newMeasurementsExecuted': False,
    'windowsLimits': 'Four existing Linux/Python CI profile tests are explicitly skipped; Windows exercises source eligibility and controlled rejection by the actual CLI.'}, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'root': str(root), 'results': results, 'newMeasurementsExecuted': False}), flush=True)
