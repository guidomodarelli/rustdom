const { performance } = require('node:perf_hooks');
function sumProbe(limit) { let sum = 0; for (let index = 0; index < limit; index++) sum += index; return sum; }
const start = { hrtimeUs: Number(process.hrtime.bigint() / 1000n), performanceMs: performance.now() };
let checksum = 0;
for (let iteration = 0; iteration < 200000; iteration++) checksum += sumProbe(iteration % 16);
if (checksum !== 7000000) throw new Error('Trace qualification: checksum mismatch: ' + checksum);
global.gc();
setImmediate(() => process.stdout.write(JSON.stringify({ pid: process.pid, node: process.version, v8: process.versions.v8, start, end: { hrtimeUs: Number(process.hrtime.bigint() / 1000n), performanceMs: performance.now() }, checksum })));
