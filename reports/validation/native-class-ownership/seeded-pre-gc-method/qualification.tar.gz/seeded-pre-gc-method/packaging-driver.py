import hashlib, io, json, pathlib, shutil, tarfile, zipfile

repo = pathlib.Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom')
root = pathlib.Path((repo / '.cache/seeded-pre-gc-method-root.txt').read_text().strip())
qualification = json.loads((root / 'qualification.json').read_bytes())
assert qualification['complete'] and all(record['exitCode'] == 0 for record in qualification['commands'])
source = json.loads((root / 'source-manifest.json').read_bytes())
assert len(source['files']) == 409
for entry in source['files']:
    for base in [repo, root / 'harness']:
        assert hashlib.sha256((base / entry['path']).read_bytes()).hexdigest() == entry['sha256']
preparation = repo / 'reports/validation/native-class-ownership/hosted-build-ci/39720077911'
identity = json.loads((preparation / 'receipt.json').read_bytes())
original_zip = preparation / 'artifact-12400802735.zip'
assert hashlib.sha256(original_zip.read_bytes()).hexdigest() == identity['artifactSha256']
with zipfile.ZipFile(original_zip) as stream:
    archived_tar = stream.read('ownership-build.tar.gz')
assert hashlib.sha256(archived_tar).hexdigest() == identity['tarSha256']
with tarfile.open(fileobj=io.BytesIO(archived_tar)) as stream:
    index_member = next(member for member in stream if member.isfile() and member.name.endswith('/index.json') and member.name.count('/') == 1)
    archived_index = stream.extractfile(index_member).read()
actual_preparation = pathlib.Path('/tmp/rustdom-ownership-results-m7jq3638/independent-order/prepared/ownership-build')
assert archived_index == (actual_preparation / 'index.json').read_bytes()
(root / 'official-preparation.json').write_text(json.dumps({
    'repositoryArtifact': original_zip.relative_to(repo).as_posix(), 'artifactSha256': identity['artifactSha256'],
    'tarSha256': identity['tarSha256'], 'indexByteIdenticalToUsedPreparation': True,
    'runId': identity['runId'], 'artifactId': identity['artifactId']}, indent=2) + '\n')
rows = []
for label in ['node-22', 'node-24']:
    assert '# pass 11' in (root / label / 'contracts.stdout.log').read_text()
    reports = [json.loads(path.read_bytes()) for prefix in ['seeded-', 'legacy-']
        for path in sorted((root / label / 'workers').glob(prefix + '*.json')) if not path.name.endswith('.process.json')]
    assert len(reports) == 7
    assert len({report['schedule']['physical'] for report in reports}) == 5
    owners = {'window': 0, 'document': 0}
    for report in reports:
        assert report['complete'] and len(report['batches']) == 8
        for batch in report['batches']:
            assert len(batch['samplesMs']) == 9 and batch['withinRealmWarmupGcOrder'] == 'before-warmup'
            assert batch['cleanupTrace'][-1]['survivors'] == {'window': 0, 'document': 0}
            assert batch['cleanupTrace'][-1]['clear']
        for kind in owners: owners[kind] += report['batches'][-1]['trackedOwners'][kind]
    assert owners == {'window': 672, 'document': 672}
    rows.append({'node': reports[0]['node'], 'tests': 11, 'positiveWorkers': 7, 'seededWorkers': 5,
        'legacyWorkers': 2, 'functionalBatches': 56, 'storedFunctionalTimings': 504,
        'observedOwnersIncludingWarmup': owners, 'realSeededWorkerPositions': [0, 15],
        'realWorkerSeedValues': [1, 16], 'schedulePositionsValidated': 16})
summary = {'complete': True, 'measurementAccepted': None, 'historicalStudyStillRejected': True,
    'harnessFiles': 409, 'harnessSha256': source['sha256'], 'results': rows,
    'productionChanged': False, 'optimizationCaptureRepeated': False, 'actualStudyExecuted': False}
(root / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
for name in ['seeded-pre-gc-design-metrics.json']:
    shutil.copyfile(repo / '.cache' / name, root / name)
shutil.copyfile(pathlib.Path(__file__), root / 'packaging-driver.py')
output = repo / 'reports/validation/native-class-ownership/seeded-pre-gc-method'
output.mkdir(parents=True, exist_ok=False)
for name in ['summary.json', 'qualification.json', 'source-manifest.json', 'official-preparation.json', 'seeded-pre-gc-design-metrics.json']:
    shutil.copyfile(root / name, output / name)
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
files = {path.relative_to(root).as_posix(): {'bytes': path.stat().st_size, 'sha256': digest(path)}
    for path in sorted(root.rglob('*')) if path.is_file()}
(output / 'raw-files.json').write_text(json.dumps(files, indent=2) + '\n')
archive = output / 'qualification.tar.gz'
with tarfile.open(archive, 'w:gz') as stream: stream.add(root, arcname='seeded-pre-gc-method')
actual = {}
with tarfile.open(archive) as stream:
    for member in stream:
        if member.isfile(): actual[member.name.removeprefix('seeded-pre-gc-method/')] = {
            'bytes': member.size, 'sha256': hashlib.sha256(stream.extractfile(member).read()).hexdigest()}
assert actual == files
receipt = {'archiveSha256': digest(archive), 'archiveBytes': archive.stat().st_size,
    'rawFiles': len(files), 'archiveReadbackMatched': True, 'measurementAccepted': None,
    'harnessFiles': 409, 'harnessSha256': source['sha256'], 'testsPerNode': 11}
(output / 'archive.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt), flush=True)
