import hashlib, json, pathlib, shutil, subprocess, sys, tarfile, tempfile

repo = pathlib.Path(__file__).resolve().parent.parent
output = repo / 'reports/validation/native-class-ownership/seeded-pre-gc-method'
root_text = (repo / '.cache/seeded-pre-gc-method-root.txt').read_text().strip()
# This finalizer runs on Windows; the qualification root lives on the local WSL filesystem.
root_windows = subprocess.check_output(['wsl', '-e', 'wslpath', '-w', root_text], text=True).strip()
root = pathlib.Path(root_windows)
names = ['authenticate-seeded-pre-gc.py', 'run-seeded-pre-gc-study.py']
hashes = {}
for name in names:
    shutil.copyfile(repo / '.cache' / name, root / name)
    hashes[name] = hashlib.sha256((root / name).read_bytes()).hexdigest()
shutil.copyfile(pathlib.Path(__file__), root / 'finalize-launchers.py')
fixture = pathlib.Path(tempfile.mkdtemp(prefix='rustdom-seeded-marker-test-'))
try:
    cache = fixture / '.cache'; cache.mkdir()
    marker = cache / 'seeded-pre-gc-study.started.json'
    evidence = b'{"existingEvidence":"must remain untouched"}\n'
    marker.write_bytes(evidence)
    command = [sys.executable, str(repo / '.cache/run-seeded-pre-gc-study.py'), str(fixture)]
    child = subprocess.run(command, capture_output=True)
    assert child.returncode == 1 and b'already has a marker' in child.stderr
    assert marker.read_bytes() == evidence
    assert list(cache.iterdir()) == [marker]
    (root / 'launcher-guard.stdout.log').write_bytes(child.stdout)
    (root / 'launcher-guard.stderr.log').write_bytes(child.stderr)
    (root / 'launcher-guard.json').write_text(json.dumps({'command': command, 'exitCode': 1,
        'existingMarkerUnchanged': True, 'noNewFiles': True, 'noMeasurementLaunched': True}, indent=2) + '\n', encoding='utf-8', newline='\n')
finally:
    target = fixture.resolve()
    assert target.parent == pathlib.Path(tempfile.gettempdir()).resolve()
    assert target.name.startswith('rustdom-seeded-marker-test-')
    shutil.rmtree(target)
(root / 'launchers.json').write_text(json.dumps(hashes, indent=2) + '\n', encoding='utf-8', newline='\n')
# Repack on Linux to preserve the original raw bytes and avoid platform path conventions in tar members.
program = '''import hashlib,json,pathlib,tarfile
root=pathlib.Path(ROOT);out=pathlib.Path(OUTPUT)
digest=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
files={path.relative_to(root).as_posix():{'bytes':path.stat().st_size,'sha256':digest(path)} for path in sorted(root.rglob('*')) if path.is_file()}
(out/'raw-files.json').write_text(json.dumps(files,indent=2)+'\\n')
archive=out/'qualification.tar.gz'
with tarfile.open(archive,'w:gz') as stream:stream.add(root,arcname='seeded-pre-gc-method')
actual={}
with tarfile.open(archive) as stream:
 for member in stream:
  if member.isfile():actual[member.name.removeprefix('seeded-pre-gc-method/')]={'bytes':member.size,'sha256':hashlib.sha256(stream.extractfile(member).read()).hexdigest()}
assert actual==files
receipt=json.loads((out/'archive.json').read_bytes());receipt.update({'archiveSha256':digest(archive),'archiveBytes':archive.stat().st_size,'rawFiles':len(files),'launchersIncluded':True,'launchersSha256':json.loads((root/'launchers.json').read_bytes()),'duplicateStartGuardPassed':True})
(out/'archive.json').write_text(json.dumps(receipt,indent=2)+'\\n')
print(json.dumps(receipt))'''
output_linux = subprocess.check_output(['wsl', '-e', 'wslpath', '-a', str(output)], text=True).strip()
program = program.replace('ROOT', repr(root_text)).replace('OUTPUT', repr(output_linux))
result = subprocess.run(['wsl', '-e', 'python3', '-'], input=program.encode(), capture_output=True)
if result.returncode:
    sys.stderr.buffer.write(result.stderr); raise SystemExit(result.returncode)
sys.stdout.buffer.write(result.stdout)
