import hashlib, json, os, pathlib, shutil, subprocess, tempfile, time

repo = pathlib.Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom')
root = pathlib.Path(tempfile.mkdtemp(prefix='rustdom-seeded-pre-gc-method-'))
(repo / '.cache/seeded-pre-gc-method-root.txt').write_text(str(root) + '\n')
harness = json.loads((repo / '.cache/seeded-pre-gc-harness.json').read_bytes())
for entry in harness['files']:
    raw = (repo / entry['path']).read_bytes()
    assert len(raw) == entry['bytes'] and hashlib.sha256(raw).hexdigest() == entry['sha256']
    target = root / 'harness' / entry['path']
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
(root / 'source-manifest.json').write_text(json.dumps(harness, indent=2) + '\n')
shutil.copyfile(pathlib.Path(__file__), root / 'qualification-driver.py')
nodes = {'node-22': '/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node-22/bin/node',
         'node-24': '/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node/bin/node'}
environment = dict(os.environ); environment.pop('NODE_OPTIONS', None)
environment.update({
    'RUSTDOM_HOSTED_BUILD_ARCHIVE': '/tmp/rustdom-ownership-results-m7jq3638/independent-order/prepared/ownership-build',
    'RUSTDOM_PRIOR_PRE_GC_ARCHIVE': '/tmp/rustdom-pre-gc-warmup-study-x5ykpauj',
})
receipt = {'complete': False, 'measurementAccepted': None, 'root': str(root), 'commands': [], 'startedAt': time.time()}
save = lambda: (root / 'qualification.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(f'ROOT {root}', flush=True); save()
for label, node in nodes.items():
    directory = root / label; directory.mkdir()
    (directory / 'workers').mkdir()
    commands = [('version', ['--version']), ('v8-options', ['--v8-options']),
        ('contracts', ['--test', '--test-reporter=tap', 'reports/benchmarks/native-class-ownership/seeded-pre-gc.spec.cjs'])]
    for name, arguments in commands:
        local = dict(environment)
        local['RUSTDOM_SEEDED_PRE_GC_TEST_OUTPUT'] = str(directory / 'workers')
        record = {'command': [node, *arguments], 'cwd': str(root / 'harness'), 'startedAt': time.time(),
            'environment': {key: value for key, value in local.items() if key.startswith('RUSTDOM_')},
            'stdout': f'{label}/{name}.stdout.log', 'stderr': f'{label}/{name}.stderr.log'}
        receipt['commands'].append(record); save()
        with (root / record['stdout']).open('xb') as stdout, (root / record['stderr']).open('xb') as stderr:
            child = subprocess.Popen(record['command'], cwd=root / 'harness', env=local, stdout=stdout, stderr=stderr)
            record['pid'] = child.pid; save(); print(f'START {label}/{name} pid={child.pid}', flush=True)
            record['exitCode'] = child.wait(); record['finishedAt'] = time.time(); save()
        print(f'END {label}/{name} exit={record["exitCode"]}', flush=True)
        if record['exitCode'] != 0:
            raise SystemExit(record['exitCode'])
for entry in harness['files']:
    for base in [repo, root / 'harness']:
        assert hashlib.sha256((base / entry['path']).read_bytes()).hexdigest() == entry['sha256'], entry['path']
receipt['complete'] = True; receipt['finishedAt'] = time.time(); save()
print('COMPLETE: seeded method qualified in both Nodes; no performance acceptance run', flush=True)
