"""Preserve and classify real DOMStringMap source correspondence, without loading a runtime."""
from pathlib import Path
import collections, gzip, hashlib, io, json, tarfile
root=Path.cwd()
base=Path(r'\\wsl.localhost\Ubuntu-22.04\home\guido\rustdom-validation\background-affinity-preparation-qh_03rjv\ownership-build')
evidence=root/'reports/validation/inventory-dom-string-map-audit';evidence.mkdir(parents=True,exist_ok=False)
inventory=root/'reports/progress/inventory'
reference=json.loads((inventory/'reference.json').read_bytes());units=json.loads((inventory/'implementation-units.json').read_bytes());surface=json.loads((inventory/'surface.json').read_bytes());audits=json.loads((inventory/'audits.json').read_bytes())
index_bytes=(base/'index.json').read_bytes();index=json.loads(index_bytes)
sha=lambda data:hashlib.sha256(data).hexdigest()
assert sha(index_bytes)=='cb30a9c13d612a14700f76a36f246ceb85cb0281aad3696f8f2e86a460307874'
raw={'official-index.json':index_bytes,'producer.py':Path(__file__).read_bytes()}
local_names=['src/dom/string-map.cjs','src/dom/string_map.rs','src/dom/string_map_binding.rs','src/dom/tree.rs','src/dom/native-tree.cjs','src/xml/input.rs','src/xml/mod.rs','scripts/build.mjs']
mapped=[]
for name in local_names:
 data=(root/name).read_bytes();official=(base/'sources'/name).read_bytes();assert data==official and sha(data)==index['files']['sources/'+name],name
 raw['local/'+name]=data;mapped.append({'path':name,'sha256':sha(data),'bytes':len(data),'officialSourceIdentical':True})
reference_names=['lib/jsdom/living/nodes/DOMStringMap-impl.js','lib/jsdom/living/generated/DOMStringMap.js','lib/jsdom/living/helpers/validate-names.js','lib/jsdom/living/attributes.js','lib/jsdom/living/nodes/HTMLOrSVGElement-impl.js']
for name in reference_names:
 data=(root/'node_modules/jsdom'/name).read_bytes();entry=next(entry for entry in reference['files'] if entry['path']==name);assert sha(data)==entry['sha256'],name;raw['reference/'+name]=data
built_names=['dist/string-map.cjs','dist/vendor-jsdom/lib/jsdom/living/nodes/DOMStringMap-impl.js','dist/vendor-jsdom/lib/jsdom/living/generated/DOMStringMap.js','dist/vendor-jsdom/lib/jsdom/living/attributes.js','dist/native-build.json']
for name in built_names:
 data=(base/'packages/B'/name).read_bytes();entry=next(entry for entry in index['distributions']['B']['files'] if entry['path']==name);assert sha(data)==entry['sha256'] and len(data)==entry['bytes'],name;raw['built/'+name]=data
history=['reports/validation/dom-string-map.md','reports/validation/dom-string-map/integration.log','reports/validation/dom-string-map/native-contracts.log','reports/validation/dom-string-map/rust-focused.log','reports/memory/2026-09-14T23-23-01.485Z-dom-string-map.json','reports/memory/2026-09-14T23-24-26.000Z-dom-string-map-valgrind.log','reports/benchmarks/2026-09-14T23-32-24.660Z-linux-x64.md']
for name in ['tests/dom-string-map.spec.cjs','tests/dom-string-map-native.spec.cjs','tests/helpers/dataset-memory.cjs']+history:raw['history/'+name]=(root/name).read_bytes()
module='module:lib/jsdom/living/nodes/DOMStringMap-impl.js';selected=[entry for entry in units if entry['moduleId']==module];assert len(selected)==10
native_lines={10,11,14,15,23,35};hybrid_lines={46,57,60}
proposal={'status':'proposal-only','ledgerModified':False,'runtimeExecuted':False,'testsExecuted':False,'performanceMeasured':False,'newRustImplementation':False,'referenceVersion':reference['package']['version'],'referenceSourceHash':reference['package']['sourceHash'],'moduleProposals':[{'id':module,'status':'hybrid'},{'id':'module:lib/jsdom/living/generated/DOMStringMap.js','status':'pending'}],'unitProposals':[],'apiProposals':[{'id':'api:Window.DOMStringMap','status':'pending','pending':['El constructor público, branding y Proxy continúan en WebIDL generado JavaScript.']}],'deferred':[{'id':'api:Window.DOMStringMap.prototype.@@toStringTag','reason':'Descriptor de infraestructura del binding; no exige reimplementar V8 y no se clasifica como algoritmo DOM nuevo.'}],'consumersOutsideProposal':['api:Window.HTMLElement.prototype.dataset','api:Window.SVGElement.prototype.dataset'],'surfaceGaps':['El catálogo no representa cada operación dinámica del Proxy como API separada; no se cierra alcance ni se inventan IDs.'],'sourceCorrespondence':mapped,'builtFilesVerified':built_names,'existingTests':['tests/dom-string-map.spec.cjs','tests/dom-string-map-native.spec.cjs','tests/helpers/dataset-memory.cjs'],'runtimeValidationRequired':['Ejecutar comportamiento público y nativo en Node22.12.0 y24.14.1 después del estudio original.','Verificar catálogo/ledger y ownership de mapas retenidos/liberados antes de incorporar estas filas.'],'performanceLimits':['Los antecedentes históricos reportan regresiones en escritura y borrado; no se aceptan ni reinterpretan como mejoras por esta auditoría.']}
for entry in selected:
 if entry['line']==19:proposal['deferred'].append({'id':entry['id'],'reason':'Constructor interno de infraestructura: ownership del owner visible a V8 y factories requieren auditoría conjunta con sus consumidores.'});continue
 status='rust-complete' if entry['line'] in native_lines else 'hybrid';assert entry['line'] in native_lines|hybrid_lines
 pending=[] if status=='rust-complete' else ['Validación y nombres tienen ruta Rust; efectos reales de atributos y/o selección y composición de excepciones permanecen en JavaScript.']
 native_symbols=['property_name'] if entry['line'] in {10,11} else ['attribute_name'] if entry['line'] in {14,15} else ['TreeStore::dataset_names'] if entry['line']==23 else ['TreeStore::dataset_value'] if entry['line']==35 else ['name_plan','attribute_name']
 proposal['unitProposals'].append({'id':entry['id'],'name':entry['name'],'kind':entry['kind'],'status':status,'nativeSymbols':native_symbols,'pending':pending,'bindings':['Transporte UTF16, Vec/Option y acceso al handle canónico; no completa el Proxy público.'] if status=='rust-complete' else [],'scope':'Solo el cuerpo de referencia; las anclas callback no son algoritmos normativos adicionales.'})
rows=proposal['moduleProposals']+proposal['unitProposals']+proposal['apiProposals'];assert len(rows)==12 and not set(audits)&{entry['id'] for entry in rows}
proposal_path=inventory/'dom-string-map-audit-proposal.json';proposal_path.write_text(json.dumps(proposal,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
raw['proposal.json']=proposal_path.read_bytes();raw_manifest={name:{'bytes':len(data),'sha256':sha(data)} for name,data in sorted(raw.items())}
with (evidence/'sources.tar.gz').open('wb') as stream:
 with gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,filename='') as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as archive:
   for name,data in sorted(raw.items()):
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;archive.addfile(info,io.BytesIO(data))
with tarfile.open(evidence/'sources.tar.gz','r:gz') as archive:
 assert len(archive.getmembers())==len(raw_manifest)
 for member in archive:
  data=archive.extractfile(member).read();assert len(data)==raw_manifest[member.name]['bytes'] and sha(data)==raw_manifest[member.name]['sha256']
receipt={'complete':True,'kind':'static-source-correspondence-only','sourceMembers':len(raw),'archiveSha256':sha((evidence/'sources.tar.gz').read_bytes()),'archiveBytes':(evidence/'sources.tar.gz').stat().st_size,'allMembersReadbackVerified':True,'officialPreparationId':index['preparationId'],'officialIndexSha256':sha(index_bytes),'artifactId':12400802735,'mappedLocalSources':mapped,'builtFilesVerified':built_names,'runtimeExecuted':False,'testsExecuted':False,'benchmarkExecuted':False,'ledgerModified':False,'proposalRows':len(rows),'bodyStates':dict(collections.Counter(entry['status'] for entry in proposal['unitProposals'])),'deferredRows':len(proposal['deferred'])}
for name,data in [('receipt.json',receipt),('raw-files.json',raw_manifest)]: (evidence/name).write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(receipt))