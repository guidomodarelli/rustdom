"""Preserve a static DOMTokenList correspondence proposal without loading packages, running tests or timing workloads."""
import hashlib
import io
import json
import pathlib
import tarfile

repository = pathlib.Path('/mnt/c/Users/guido/.codex/worktrees/migration-inventory/rustdom')
ownership = pathlib.Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom')
prepared = pathlib.Path('/home/guido/rustdom-validation/background-affinity-preparation-qh_03rjv/ownership-build')
inventory = repository / 'reports/progress/inventory'
output = repository / 'reports/validation/inventory-dom-token-list-audit'
reference = json.loads((inventory / 'reference.json').read_bytes())
units = json.loads((inventory / 'implementation-units.json').read_bytes())
surface = json.loads((inventory / 'surface.json').read_bytes())
reference_files = {entry['path']: entry for entry in reference['files']}
index = json.loads((prepared / 'index.json').read_bytes())
distribution = {entry['path']: entry for entry in index['distributions']['B']['files']}
official = json.loads((ownership / 'reports/validation/native-class-ownership/hosted-build-ci/39720077911/receipt.json').read_bytes())
if index['preparationId'] != official['identity']['preparationId']:
    raise ValueError('Physical preparation differs from the published identity')
payloads = {}
local_sources = ['src/dom/token-list.cjs', 'src/dom/token_list.rs', 'src/dom/token_list_binding.rs',
                 'src/dom/tree.rs', 'src/dom/native-tree.cjs', 'scripts/build.mjs']
source_correspondence = []
for name in local_sources:
    raw = (repository / name).read_bytes()
    compiled_source = (prepared / 'sources' / name).read_bytes()
    if raw != compiled_source:
        raise ValueError('Local mapped source differs from official archived source: ' + name)
    payloads['local/' + name] = raw
    payloads['official-source/' + name] = compiled_source
    source_correspondence.append({'path': name, 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw),
                                  'officialSourceIdentical': True})
reference_names = ['lib/jsdom/living/nodes/DOMTokenList-impl.js', 'lib/jsdom/living/generated/DOMTokenList.js',
                   'lib/jsdom/living/helpers/ordered-set.js', 'lib/jsdom/living/attributes.js']
for name in reference_names:
    raw = (repository / 'node_modules/jsdom' / name).read_bytes()
    entry = reference_files[name]
    if hashlib.sha256(raw).hexdigest() != entry['sha256'] or len(raw) != entry['bytes']:
        raise ValueError('Installed reference differs from the fixed catalog: ' + name)
    payloads['reference/' + name] = raw
for name in ['dist/token-list.cjs', 'dist/vendor-jsdom/lib/jsdom/living/nodes/DOMTokenList-impl.js',
             'dist/vendor-jsdom/lib/jsdom/living/generated/DOMTokenList.js', 'dist/vendor-jsdom/lib/jsdom/living/helpers/ordered-set.js']:
    raw = (prepared / 'packages/B' / name).read_bytes()
    entry = distribution[name]
    if hashlib.sha256(raw).hexdigest() != entry['sha256'] or len(raw) != entry['bytes']:
        raise ValueError('Selected physical distribution file differs from its authenticated manifest: ' + name)
    payloads['official-package/' + name] = raw
for name in ['tests/dom-token-list.spec.cjs', 'tests/dom-token-list-native.spec.cjs', 'tests/helpers/token-list-memory.cjs',
             'reports/validation/dom-token-list.md', 'reports/validation/dom-token-list/native-contracts.log',
             'reports/validation/dom-token-list/integration.log', 'reports/validation/dom-token-list/rust-focused.log',
             'reports/memory/2026-09-14T22-23-50.839Z-dom-token-list.json',
             'reports/memory/2026-09-14T22-26-49.253Z-dom-token-list.json',
             'reports/memory/2026-09-14T22-41-47.486Z-dom-token-list.json']:
    payloads['existing-evidence/' + name] = (repository / name).read_bytes()
payloads['tools/audit-dom-token-list.py'] = pathlib.Path(__file__).read_bytes()
payloads['official-receipt.json'] = (ownership / 'reports/validation/native-class-ownership/hosted-build-ci/39720077911/receipt.json').read_bytes()

module_id = 'module:lib/jsdom/living/nodes/DOMTokenList-impl.js'
decisions = {
    ('validateTokens', 'FunctionDeclaration'): ('hybrid', 'La validación y precedencia están en Rust; selección/composición de DOMException por status conservada en el host.'),
    ('attrModified', 'MethodDeclaration'): ('hybrid', 'La señal dirty es nativa; el host invalida la vista cacheada. Resolver la frontera de ese binding antes de acreditar el cuerpo completo.'),
    ('_syncWithElement', 'MethodDeclaration'): ('rust-complete', ''),
    ('_validationSteps', 'MethodDeclaration'): ('hybrid', 'Lowercase y membresía son nativos; ausencia de tokens soportados, mensaje y TypeError se resuelven en JavaScript.'),
    ('_updateSteps', 'MethodDeclaration'): ('hybrid', 'Rust planifica presencia y serialización; el host decide invocar el hook y conserva el driver real de atributos.'),
    ('_serializeSteps', 'MethodDeclaration'): ('rust-complete', ''),
    ('tokenSet', 'GetAccessor'): ('hybrid', 'Rust sincroniza y comparte el conjunto; el host conserva elección y cache de TokenSetView y sus consumidores JavaScript.'),
    ('length', 'GetAccessor'): ('rust-complete', ''),
    ('[idlUtils.supportedPropertyIndices]', 'GetAccessor'): ('hybrid', 'Sincronización nativa consumida mediante el generador keys de TokenSetView en JavaScript.'),
    ('item', 'MethodDeclaration'): ('rust-complete', ''),
    ('contains', 'MethodDeclaration'): ('rust-complete', ''),
    ('add', 'MethodDeclaration'): ('hybrid', 'Rust valida y muta el conjunto; el host conserva error, escritura y efectos mediante _mutate y setAttributeValue.'),
    ('remove', 'MethodDeclaration'): ('hybrid', 'Rust valida y muta el conjunto; el host conserva error, escritura y efectos mediante _mutate y setAttributeValue.'),
    ('toggle', 'MethodDeclaration'): ('hybrid', 'Rust decide force, pertenencia y plan; el host conserva error, escritura y efectos.'),
    ('replace', 'MethodDeclaration'): ('hybrid', 'Rust decide validación, orden y resultado; el host conserva error, escritura y efectos.'),
    ('supports', 'MethodDeclaration'): ('hybrid', 'Consume el algoritmo de soporte nativo y la selección de TypeError todavía JavaScript.'),
    ('value', 'GetAccessor'): ('rust-complete', ''),
    ('value', 'SetAccessor'): ('pending', 'El cuerpo delega al driver setAttributeValue de JavaScript, no a una orquestación nativa de atributos y efectos.'),
}
selected_units = [entry for entry in units if entry['moduleId'] == module_id and entry['kind'] != 'Constructor']
if len(selected_units) != len(decisions):
    raise ValueError('Reference body scope differs from the reviewed proposal')
proposals = []
for entry in selected_units:
    status, reason = decisions[(entry['name'], entry['kind'])]
    proposals.append({'id': entry['id'], 'name': entry['name'], 'kind': entry['kind'], 'status': status,
                      'pending': [reason] if reason else [],
                      'bindings': ['Transporte N-API de valor UTF16, Option, cantidad o booleano; no acredita el consumidor WebIDL.'] if not reason else [],
                      'scope': 'Solo el cuerpo de referencia identificado; sin completar módulos, APIs ni sus dependencias.'})
excluded_names = ['.@@iterator', '.@@toStringTag', '.entries', '.forEach', '.keys', '.values']
apis = [entry for entry in surface['apis'] if entry['id'].startswith('api:Window.DOMTokenList') and
        not any(entry['id'].endswith(name) for name in excluded_names)]
if len(apis) != 11:
    raise ValueError('Observed direct DOMTokenList API scope differs from the reviewed proposal')
proposal = {'status': 'proposal-only', 'ledgerModified': False, 'referenceVersion': '27.4.0',
            'referenceSourceHash': '6195104b9e153430a280485e51cbbbd738c73b9b1c7bc422a5df3d13a591fc5f',
            'moduleProposals': [{'id': module_id, 'status': 'hybrid'},
                                {'id': 'module:lib/jsdom/living/generated/DOMTokenList.js', 'status': 'pending'}],
            'unitProposals': proposals,
            'apiProposals': [{'id': entry['id'], 'status': 'pending' if entry['id'] == 'api:Window.DOMTokenList' else 'hybrid'} for entry in apis],
            'deferred': [{'id': entry['id'], 'reason': 'Constructor interno: aristas y factories requieren decisión explícita de frontera de bindings.'}
                         for entry in units if entry['moduleId'] == module_id and entry['kind'] == 'Constructor'] +
                        [{'id': entry['id'], 'reason': 'Alias de intrínseco Array o metadata de binding: auditar frontera/proxy sin imponer reimplementación de V8.'}
                         for entry in surface['apis'] if entry['id'].startswith('api:Window.DOMTokenList') and entry not in apis],
            'runtimeExecuted': False, 'testsExecuted': False, 'performanceMeasured': False,
            'independentReviewComplete': False, 'newRustImplementation': False,
            'legacyEvidenceLimits': ['El histórico público contiene175casos y el nativo5; el archivo nativo actual contiene un sexto caso posterior.',
                                     'No son ejecuciones de esta auditoría ni certificación completa de estándares.',
                                     'Ninguna fila modifica los recuentos vigentes ni concede porcentaje de migración.']}
output.mkdir(parents=True, exist_ok=False)
raw_manifest = {name: {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()} for name, raw in payloads.items()}
archive_path = output / 'sources.tar.gz'
with tarfile.open(archive_path, 'w:gz') as archive:
    for name, raw in payloads.items():
        member = tarfile.TarInfo(name)
        member.size = len(raw)
        member.mode = 0o644
        archive.addfile(member, io.BytesIO(raw))
with tarfile.open(archive_path, 'r:gz') as archive:
    if archive.getnames() != list(payloads):
        raise ValueError('Static source archive member coverage differs')
    for member in archive:
        if hashlib.sha256(archive.extractfile(member).read()).hexdigest() != raw_manifest[member.name]['sha256']:
            raise ValueError('Static source archive readback differs: ' + member.name)


def save(filename, value):
    filename.write_bytes((json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode())


save(inventory / 'dom-token-list-audit-proposal.json', proposal)
save(output / 'raw-files.json', raw_manifest)
save(output / 'receipt.json', {'complete': True, 'kind': 'static-source-correspondence-only',
     'sourceMembers': len(payloads), 'archiveSha256': hashlib.sha256(archive_path.read_bytes()).hexdigest(),
     'archiveBytes': archive_path.stat().st_size, 'allMembersReadbackVerified': True,
     'officialPreparationId': index['preparationId'], 'artifactId': official['artifactId'],
     'mappedLocalSources': source_correspondence, 'runtimeExecuted': False, 'testsExecuted': False,
     'benchmarkExecuted': False, 'ledgerModified': False})
print(json.dumps({'members': len(payloads), 'archiveBytes': archive_path.stat().st_size,
                  'archiveSha256': hashlib.sha256(archive_path.read_bytes()).hexdigest(),
                  'units': len(proposals), 'apis': len(apis), 'ledgerModified': False}))
