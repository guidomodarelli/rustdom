"""Exercise the actual offline data reader on the saved cohort, fresh output, preserved output and corrupted byte transport; no DOM or measurement."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

if sys.flags.optimize:
    raise RuntimeError('Data reader qualification requires non-optimized Python')
if sys.platform == 'win32':
    repository = Path.cwd(); base = repository / '.cache/ordinary-ci-reader-windows-safe-inputs'; label = 'windows'
else:
    repository = Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom')
    base = Path('/home/guido/rustdom-validation/ordinary-ci-reader-linux-safe-inputs'); label = 'linux'
assert not base.exists(); base.mkdir()
dataset = repository / 'reports/benchmarks/ci-validation/40191262985'
reader = dataset / 'analyze-current-ci-data.py'; transport = dataset / 'transport'
commands = []

def run(name, arguments, expected):
    argv = [sys.executable, '-B', str(reader), *map(str, arguments)]
    with (base / (name + '.stdout.log')).open('xb') as stdout, (base / (name + '.stderr.log')).open('xb') as stderr:
        result = subprocess.run(argv, cwd=repository, stdout=stdout, stderr=stderr, timeout=30)
    commands.append({'name': name, 'argv': argv, 'exitCode': result.returncode, 'expectedSuccess': expected})
    (base / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    assert (result.returncode == 0) == expected, name
    return result

before = {filename.relative_to(transport).as_posix(): hashlib.sha256(filename.read_bytes()).hexdigest()
    for filename in transport.rglob('*') if filename.is_file()}
run('verify-real-cohort', ['--verify', transport], True)
run('export-real-cohort', [transport, base / 'export'], True)
for name in ['comparisons.csv', 'timing-spans.csv', 'memory-endpoints.jsonl', 'analysis.json']:
    assert (base / 'export' / name).read_bytes() == (dataset / name).read_bytes(), name
existing = base / 'existing'; existing.mkdir(); (existing / 'sentinel').write_bytes(b'preserve-owned-output')
run('reject-existing-output', [transport, existing], False)
assert list(existing.iterdir()) == [existing / 'sentinel'] and (existing / 'sentinel').read_bytes() == b'preserve-owned-output'
alias = base / 'input-alias'; alias_available = True
try:
    alias.symlink_to(transport, target_is_directory=True)
except OSError:
    alias_available = False
if alias_available:
    run('reject-input-alias-output', [transport, alias], False)
corrupted = base / 'corrupted'; shutil.copytree(transport, corrupted)
archive = corrupted / 'artifact-12598434028/artifact.zip'
with archive.open('r+b') as stream:
    stream.seek(-1, 2); value = stream.read(1); stream.seek(-1, 2); stream.write(bytes([value[0] ^ 1]))
corrupt_sha = hashlib.sha256(archive.read_bytes()).hexdigest()
run('reject-corrupt-transport', ['--verify', corrupted], False)
assert 'Ordinary CI data: pinned input bytes differ: artifact-12598434028/artifact.zip' in (base / 'reject-corrupt-transport.stderr.log').read_text()
assert hashlib.sha256(archive.read_bytes()).hexdigest() == corrupt_sha
run('reject-corrupt-before-export', [corrupted, base / 'corrupt-export'], False)
assert not (base / 'corrupt-export').exists()
extra_input = base / 'extra-input'; shutil.copytree(transport, extra_input)
(extra_input / 'unlisted-secret.txt').write_bytes(b'owned-test-data-must-not-be-copied')
run('reject-unlisted-before-export', [extra_input, base / 'extra-export'], False)
assert not (base / 'extra-export').exists()
foreign = base / 'foreign-parent'; foreign.mkdir(); (foreign / 'sentinel').write_bytes(b'preserve-owned-foreign-data')
linked_input = base / 'linked-input'; shutil.copytree(transport, linked_input)
link = linked_input / 'loop-to-output-parent'
if sys.platform == 'win32':
    created = subprocess.run(['cmd', '/d', '/c', 'mklink', '/J', str(link), str(foreign)], capture_output=True)
    (base / 'junction-create.stdout.log').write_bytes(created.stdout)
    (base / 'junction-create.stderr.log').write_bytes(created.stderr)
    assert created.returncode == 0 and link.is_junction()
    input_link_kind = 'Windows junction'
else:
    link.symlink_to(foreign, target_is_directory=True); input_link_kind = 'POSIX symlink'
run('reject-linked-input-before-export', [linked_input, foreign / 'output'], False)
assert 'input tree contains a link or junction' in (base / 'reject-linked-input-before-export.stderr.log').read_text()
assert list(foreign.iterdir()) == [foreign / 'sentinel'] and (foreign / 'sentinel').read_bytes() == b'preserve-owned-foreign-data'

after = {filename.relative_to(transport).as_posix(): hashlib.sha256(filename.read_bytes()).hexdigest()
    for filename in transport.rglob('*') if filename.is_file()}
assert before == after
receipt = {'platform': label, 'python': sys.version, 'commands': commands, 'sourceInputPreserved': True,
    'readerSha256': hashlib.sha256(reader.read_bytes()).hexdigest(), 'configSha256': hashlib.sha256((dataset / 'constants/ci-validation.json').read_bytes()).hexdigest(),
    'exportsByteIdentical': True, 'symlinkContractExecuted': alias_available, 'inputLinkKind': input_link_kind, 'reviewP2InputTraversalFixed': True, 'analyzerExecutedDOM': False,
    'newMeasurementProcesses': 0, 'performanceAccepted': None, 'gateReevaluated': False}
(base / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({key: value for key, value in receipt.items() if key != 'commands'}))
