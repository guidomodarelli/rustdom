"""Exercise the actual offline data reader on the saved cohort, fresh output, preserved output and corrupted byte transport; no DOM or measurement."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

if sys.flags.optimize:
    raise RuntimeError('Data reader qualification requires non-optimized Python')
if sys.platform == 'win32':
    repository = Path.cwd(); base = repository / '.cache/ordinary-ci-reader-windows'; label = 'windows'
else:
    repository = Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom')
    base = Path('/home/guido/rustdom-validation/ordinary-ci-reader-linux'); label = 'linux'
assert not base.exists(); base.mkdir()
dataset = repository / 'reports/benchmarks/ci-validation/40191262985'
reader = dataset / 'analyze-current-ci-data.py'; transport = dataset / 'transport'
commands = []

def run(name, arguments, expected):
    argv = [sys.executable, '-B', str(reader), *map(str, arguments)]
    with (base / (name + '.stdout.log')).open('xb') as stdout, (base / (name + '.stderr.log')).open('xb') as stderr:
        result = subprocess.run(argv, cwd=repository, stdout=stdout, stderr=stderr)
    commands.append({'name': name, 'argv': argv, 'exitCode': result.returncode, 'expectedSuccess': expected})
    (base / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    assert (result.returncode == 0) == expected, name
    return result

before = {filename.relative_to(transport).as_posix(): hashlib.sha256(filename.read_bytes()).hexdigest()
    for filename in transport.rglob('*') if filename.is_file()}
run('verify-real-cohort', ['--verify', transport], True)
run('export-real-cohort', [transport, base / 'export'], True)
for name in ['comparisons.csv', 'timing-spans.csv', 'memory-endpoints.jsonl', 'analysis.json']:
    assert (base / 'export' / name).read_bytes() == (dataset / name).read_bytes(), name
existing = base / 'existing'; existing.mkdir(); (existing / 'sentinel').write_bytes(b'preserve-owned-output')
run('reject-existing-output', [transport, existing], False)
assert list(existing.iterdir()) == [existing / 'sentinel'] and (existing / 'sentinel').read_bytes() == b'preserve-owned-output'
alias = base / 'input-alias'; alias_available = True
try:
    alias.symlink_to(transport, target_is_directory=True)
except OSError:
    alias_available = False
if alias_available:
    run('reject-input-alias-output', [transport, alias], False)
corrupted = base / 'corrupted'; shutil.copytree(transport, corrupted)
archive = corrupted / 'artifact-12598434028/artifact.zip'
with archive.open('r+b') as stream:
    stream.seek(-1, 2); value = stream.read(1); stream.seek(-1, 2); stream.write(bytes([value[0] ^ 1]))
corrupt_sha = hashlib.sha256(archive.read_bytes()).hexdigest()
run('reject-corrupt-transport', ['--verify', corrupted], False)
assert 'Ordinary CI data: artifact 12598434028 bytes or SHA256 differ from pinned transport' in (base / 'reject-corrupt-transport.stderr.log').read_text()
assert hashlib.sha256(archive.read_bytes()).hexdigest() == corrupt_sha
after = {filename.relative_to(transport).as_posix(): hashlib.sha256(filename.read_bytes()).hexdigest()
    for filename in transport.rglob('*') if filename.is_file()}
assert before == after
receipt = {'platform': label, 'python': sys.version, 'commands': commands, 'sourceInputPreserved': True,
    'readerSha256': hashlib.sha256(reader.read_bytes()).hexdigest(), 'configSha256': hashlib.sha256((dataset / 'constants/ci-validation.json').read_bytes()).hexdigest(),
    'exportsByteIdentical': True, 'symlinkContractExecuted': alias_available, 'analyzerExecutedDOM': False,
    'newMeasurementProcesses': 0, 'performanceAccepted': None, 'gateReevaluated': False}
(base / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({key: value for key, value in receipt.items() if key != 'commands'}))
