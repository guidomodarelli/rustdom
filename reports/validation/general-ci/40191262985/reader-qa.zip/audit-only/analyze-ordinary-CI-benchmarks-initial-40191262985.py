"""Preserve all ordinary CI data and reproduce reported medians without executing archives or accepting ownership performance."""
import csv
import hashlib
import json
import math
from pathlib import Path
import re
import shutil
import statistics
import sys
import zipfile

if sys.flags.optimize:
    raise RuntimeError('Benchmark data analysis requires non-optimized Python')
repository = Path.cwd(); collection = repository / '.cache/general-CI-40191262985'
receipt = json.loads((collection / 'collection.json').read_bytes())
assert receipt['runId'] == 40191262985 and receipt['head'] == 'd265390ec77390fc055178f0c29093329debf860' and receipt['attempt'] == 1
assert next(job for job in receipt['jobs'] if job['name'] == 'benchmarks')['conclusion'] == 'success'
merge = json.loads((collection / 'measured-merge-commit.json').read_bytes())
head = json.loads((collection / 'PR-head-commit.json').read_bytes())
assert head['sha'] == receipt['head'] and head['sha'] in [parent['sha'] for parent in merge['parents']]
assert merge['tree']['sha'] == head['tree']['sha']
destination = repository / 'reports/benchmarks/ci-validation/40191262985'; assert not destination.exists()
destination.mkdir(parents=True); (destination / '.gitattributes').write_bytes(b'* -text\n')
shutil.copytree(collection, destination / 'transport')
shutil.copyfile(Path(__file__), destination / 'analyze-current-ci-data.py')
shutil.copyfile(repository / '.cache/collect-general-CI-40191262985.py', destination / 'collect-current-ci.py')
rows = []; auxiliaries = []; profiles = []; seen = set(); spans = []; resources = []
for artifact in receipt['artifacts']:
    if not artifact['name'].startswith('benchmark-linux-'):
        continue
    shard = int(artifact['name'].removeprefix('benchmark-linux-'))
    directory = collection / ('artifact-' + str(artifact['id'])); archive_file = directory / 'artifact.zip'
    assert archive_file.stat().st_size == artifact['bytes'] and hashlib.sha256(archive_file.read_bytes()).hexdigest() == artifact['sha256']
    with zipfile.ZipFile(archive_file) as archive:
        reports = [(name, json.loads(archive.read(name))) for name in archive.namelist()
            if name.endswith('.json') and name != 'artifact-manifest.json']
        full = [(name, report) for name, report in reports if report.get('shard') == {'index': shard, 'count': 4} and report.get('requestedWorkloads') == []]
        assert len(full) == 1, 'Do not select among multiple full benchmark captures'
        name, report = full[0]
        assert report['complete'] is True and report['sourceCommit'] == merge['sha']
        assert len(report['runs']) == 4 and [run['engine'] for run in report['runs']] == ['jsdom', 'rustdom', 'rustdom', 'jsdom']
        manifest = json.loads(archive.read('artifact-manifest.json'))
        assert manifest['sourceCommit'] == report['sourceCommit'] and manifest['githubRunId'] == str(receipt['runId'])
        assert manifest['githubRunAttempt'] == '1' and manifest['complete'] is True
        identity = {key: report[key] for key in ['sourceCommit', 'sourceChanges', 'sourceGitErrors', 'node', 'jsdom', 'rustc', 'cargo',
            'nativeBinarySha256', 'runtimeSource', 'machine', 'methodology']}
        profiles.append({'artifactId': artifact['id'], 'shard': shard, 'report': name, **identity})
        by_case = {}
        for run_index, run in enumerate(report['runs']):
            assert run['warmupSamples'] == 3 and run['measuredSamples'] == 9
            for workload in run['workloads']:
                key = (workload['name'], workload['rows'])
                assert len(workload['samplesMs']) == 9 and len(workload['memoryAfterCleanup']) == 9
                assert re.fullmatch('[a-f0-9]{64}', workload['outputHash'])
                by_case.setdefault(key, {}).setdefault(run['engine'], []).append(workload)
                resources.append({'artifactId': artifact['id'], 'shard': shard, 'reportRunIndex': run_index,
                    'engine': run['engine'], 'node': report['node'], 'sourceCommit': report['sourceCommit'], 'workloadReport': workload})
                for sample_index, duration in enumerate(workload['samplesMs']):
                    assert isinstance(duration, (int, float)) and math.isfinite(duration) and duration > 0
                    spans.append({'shard': shard, 'reportRunIndex': run_index, 'engine': run['engine'], 'workload': key[0],
                        'rows': key[1], 'sampleIndex': sample_index, 'durationMs': duration, 'outputHash': workload['outputHash']})
        assert len(by_case) == len(report['comparisons'])
        for comparison in report['comparisons']:
            key = (comparison['workload'], comparison['rows']); assert key not in seen; seen.add(key)
            group = by_case[key]
            assert set(group) == {'jsdom', 'rustdom'} and all(len(workloads) == 2 for workloads in group.values())
            assert len({entry['outputHash'] for workloads in group.values() for entry in workloads}) == 1
            for engine in ['jsdom', 'rustdom']:
                samples = [sample for entry in group[engine] for sample in entry['samplesMs']]
                assert len(samples) == comparison[engine]['samples'] == 18
                assert statistics.median(samples) == comparison[engine]['medianMs']
                assert min(samples) == comparison[engine]['minMs'] and max(samples) == comparison[engine]['maxMs']
            assert comparison['speedup'] == comparison['jsdom']['medianMs'] / comparison['rustdom']['medianMs']
            rows.append({'artifactId': artifact['id'], 'shard': shard, 'workload': key[0], 'rows': key[1],
                'jsdomSamples': 18, 'rustdomSamples': 18, 'jsdomMedianMs': comparison['jsdom']['medianMs'],
                'rustdomMedianMs': comparison['rustdom']['medianMs'], 'speedupJsdomOverRustdom': comparison['speedup'],
                'rustdomSlowerMedian': comparison['speedup'] < 1, 'reportedComparison': comparison})
        for auxiliary_name, auxiliary in reports:
            if auxiliary_name == name:
                continue
            auxiliaries.append({'artifactId': artifact['id'], 'file': auxiliary_name, 'complete': auxiliary.get('complete'),
                'shard': auxiliary.get('shard'), 'requestedWorkloads': auxiliary.get('requestedWorkloads'),
                'failure': auxiliary.get('failure'), 'purpose': 'Runner-contract output, kept distinct from the declared four-shard cohort'})
assert sorted(profile['shard'] for profile in profiles) == [0, 1, 2, 3]
assert len(rows) == 332 and len(spans) == 11952 and len(resources) == 1328
assert sum(len(entry['workloadReport']['memoryAfterCleanup']) for entry in resources) == 11952
assert len(auxiliaries) == 20 and sum(auxiliary['complete'] is False for auxiliary in auxiliaries) == 8
assert len({profile['nativeBinarySha256'] for profile in profiles}) == 1 and len({profile['node'] for profile in profiles}) == 1
rows.sort(key=lambda row: (row['workload'], row['rows']))
fields = ['artifactId', 'shard', 'workload', 'rows', 'jsdomSamples', 'rustdomSamples', 'jsdomMedianMs', 'rustdomMedianMs',
    'speedupJsdomOverRustdom', 'rustdomSlowerMedian']
with (destination / 'comparisons.csv').open('x', encoding='utf-8', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=fields, extrasaction='ignore'); writer.writeheader(); writer.writerows(rows)
with (destination / 'timing-spans.csv').open('x', encoding='utf-8', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=list(spans[0])); writer.writeheader(); writer.writerows(spans)
with (destination / 'memory-endpoints.jsonl').open('x', encoding='utf-8', newline='\n') as stream:
    for entry in resources:
        stream.write(json.dumps(entry, separators=(',', ':')) + '\n')
summary = {'runId': receipt['runId'], 'PRHead': head['sha'], 'observedSourceCommit': merge['sha'], 'identicalGitTree': head['tree']['sha'],
    'benchmarkCohortComplete': True, 'overallCIStatusAtCollection': receipt['status'], 'cases': len(rows), 'durations': len(spans),
    'memorySnapshots': 11952, 'rustdomSlowerMedianCases': sum(row['rustdomSlowerMedian'] for row in rows),
    'rustdomFasterMedianCases': sum(row['speedupJsdomOverRustdom'] > 1 for row in rows), 'profiles': profiles,
    'comparisons': rows, 'auxiliaryReports': auxiliaries, 'pooledMediansReproducedExactly': True,
    'outputHashesMatch': True, 'warmupDurationsRecorded': False, 'declaredWarmupsPerCaseAndProcess': 3,
    'rawSourcesRewritten': False, 'analyzerExecutedDOM': False, 'newMeasurementProcesses': 0,
    'scientificStudyReplaced': False, 'performanceAccepted': None, 'gateReevaluated': False,
    'limits': ['Ordinary CI public-operation probes on the hybrid runtime; not the frozen ownership candidate or Node22/24 study',
        'Each of four worker processes in a shard runs many workloads; pooled medians have no new confidence or causal claim',
        'Process endpoints after one event-loop turn and GC are not peak memory or proof that Window/Document were collected',
        'Warmup counts are declared; raw warmup durations were not retained by this ordinary benchmark harness']}
(destination / 'analysis.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8', newline='\n')
lines = ['# Comparaciones ordinarias del CI', '', 'Todas las filas se conservan. Un cociente menor que 1 indica mayor mediana de rustdom en esta corrida; no significa una regresión causal ni una decisión estadística de aceptación.', '',
    '| Workload | rows | jsdom mediana ms | rustdom mediana ms | jsdom/rustdom |', '| --- | ---: | ---: | ---: | ---: |']
for row in rows:
    lines.append(f"| {row['workload']} | {row['rows']} | {row['jsdomMedianMs']:.6g} | {row['rustdomMedianMs']:.6g} | {row['speedupJsdomOverRustdom']:.6g} |")
(destination / 'comparisons.md').write_text('\n'.join(lines) + '\n', encoding='utf-8', newline='\n')
manifest = {filename.relative_to(destination).as_posix(): {'bytes': filename.stat().st_size, 'sha256': hashlib.sha256(filename.read_bytes()).hexdigest()}
    for filename in sorted(destination.rglob('*')) if filename.is_file()}
(destination / 'manifest.json').write_text(json.dumps({'files': manifest, 'performanceAccepted': None, 'gateReevaluated': False}, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({key: summary[key] for key in ['cases', 'durations', 'memorySnapshots', 'rustdomSlowerMedianCases', 'rustdomFasterMedianCases',
    'observedSourceCommit', 'benchmarkCohortComplete', 'overallCIStatusAtCollection', 'performanceAccepted']}))
