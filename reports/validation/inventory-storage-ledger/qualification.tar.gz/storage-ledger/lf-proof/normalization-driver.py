"""Prove that publishing LF JSON leaves actual inventory CLI output unchanged."""
import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import tempfile
import time

repository = pathlib.Path('/mnt/c/Users/guido/.codex/worktrees/migration-inventory/rustdom')
qualified = pathlib.Path('/tmp/rustdom-storage-ledger-q3bsyskx')
relative = 'reports/progress/inventory/audits.json'
raw = (repository / relative).read_bytes()
sources = json.loads((qualified / 'sources.json').read_text())
assert hashlib.sha256(raw).hexdigest() == sources[relative]['sha256']
assert json.loads((qualified / 'receipt.json').read_text())['linuxCommandsPassed'] is True
normalized = raw.replace(b'\r\n', b'\n')
assert raw != normalized and json.loads(raw) == json.loads(normalized)
marker = repository / '.cache/storage-ledger-lf-proof-root.txt'
with marker.open('x') as output:
    root = pathlib.Path(tempfile.mkdtemp(prefix='rustdom-storage-ledger-lf-proof-'))
    output.write(str(root) + '\n')
shutil.copytree(qualified / 'repository', root / 'repository', symlinks=True)
(repository / relative).write_bytes(normalized)
(root / 'repository' / relative).write_bytes(normalized)
shutil.copyfile(__file__, root / 'normalization-driver.py')
receipt = {'complete': False, 'originalQualifiedSha256': hashlib.sha256(raw).hexdigest(),
           'publishedLfSha256': hashlib.sha256(normalized).hexdigest(), 'jsonValuesIdentical': True,
           'originalQualificationPreserved': True, 'commands': [], 'newMeasurementsExecuted': False}
environment = dict(os.environ)
environment.pop('NODE_OPTIONS', None)
for label in ['node-22', 'node-24']:
    original = json.loads((qualified / (label + '-generator.process.json')).read_text())
    command = [*original['command'][:-1], str(root / (label + '-catalog'))]
    record = {'command': command, 'cwd': str(root / 'repository'), 'startedAt': time.time()}
    with (root / (label + '.stdout.log')).open('xb') as stdout, (root / (label + '.stderr.log')).open('xb') as stderr:
        child = subprocess.Popen(command, cwd=root / 'repository', env=environment, stdout=stdout, stderr=stderr)
        record['pid'] = child.pid
        record['exitCode'] = child.wait()
        record['finishedAt'] = time.time()
    receipt['commands'].append(record)
    (root / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    assert record['exitCode'] == 0
    record['identicalOutputs'] = {}
    for filename in ['classification.json', 'summary.json', 'reference.json', 'implementation-units.json', 'surface.json']:
        before = (qualified / (label + '-catalog') / filename).read_bytes()
        after = (root / (label + '-catalog') / filename).read_bytes()
        assert before == after, (label, filename)
        record['identicalOutputs'][filename] = hashlib.sha256(after).hexdigest()
for relative_source, expected in sources.items():
    assert hashlib.sha256((qualified / 'repository' / relative_source).read_bytes()).hexdigest() == expected['sha256']
    actual = (root / 'repository' / relative_source).read_bytes()
    assert actual == (normalized if relative_source == relative else (qualified / 'repository' / relative_source).read_bytes())
assert (repository / relative).read_bytes() == normalized
receipt['complete'] = True
(root / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'root': str(root), **receipt}), flush=True)
