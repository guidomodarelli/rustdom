"""Qualify the Storage ledger only after the existing seeded study is terminal."""
import hashlib
import json
import pathlib
import subprocess
import sys
import tempfile
import time

REPOSITORY = pathlib.Path('/mnt/c/Users/guido/.codex/worktrees/migration-inventory/rustdom')
STUDY = pathlib.Path('/tmp/rustdom-seeded-pre-gc-study-4zryergi')
DEPENDENCIES = pathlib.Path('/tmp/rustdom-runner-suites-ytu9q4xb/static-prepared/packages/B/node_modules')
NODES = {
    'node-22': '/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node-22/bin/node',
    'node-24': '/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node/bin/node',
}
CATALOG_FILES = ['reference.json', 'surface.json', 'implementation-units.json', 'classification.json', 'summary.json']


def require_terminal_study():
    """Inspect real process state before permitting any qualification or output creation."""
    marker = json.loads((STUDY / 'publication.json').read_bytes())
    assert marker['head'] == '737a2ba1c2cf5994561c3b739232f5e3cb6fb257'
    for label in NODES:
        filename = STUDY / f'{label}.process.json'
        assert filename.is_file(), f'Original study has not started {label}; do not compete with it'
        record = json.loads(filename.read_bytes())
        process = pathlib.Path(f'/proc/{record["pid"]}')
        if process.exists():
            status = (process / 'stat').read_text().split(') ', 1)[1].split()[0]
            command = (process / 'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace')
            assert status == 'Z' or 'seeded-pre-gc-experiment.cjs' not in command, (
                f'Original study is live: {label} pid={record["pid"]}; do not run qualification')
        assert record.get('exitCode') in [0, 1], f'Original study is not terminal with preserved evidence: {label}'
    assert (STUDY / 'verification.exit-code').read_text().strip() == '0'
    verification = json.loads((STUDY / 'verification.json').read_bytes())
    assert verification['verified'] is True and len(verification['results']) == 2


def run_command(root, snapshot, name, arguments):
    """Preserve complete output and the child identity, then require successful termination."""
    record = {'command': arguments, 'cwd': str(snapshot), 'startedAt': time.time()}
    with (root / f'{name}.stdout.log').open('xb') as stdout, (root / f'{name}.stderr.log').open('xb') as stderr:
        child = subprocess.Popen(arguments, cwd=snapshot, stdout=stdout, stderr=stderr)
        record['pid'] = child.pid
        (root / f'{name}.process.json').write_text(json.dumps(record, indent=2) + '\n')
        print(f'START {name} pid={child.pid}', flush=True)
        record['exitCode'] = child.wait()
    record['finishedAt'] = time.time()
    (root / f'{name}.process.json').write_text(json.dumps(record, indent=2) + '\n')
    print(f'END {name} exit={record["exitCode"]}', flush=True)
    assert record['exitCode'] == 0, f'Inspect original {name} logs; no retry performed'


def qualify():
    """Freeze inputs on Linux, run both real Node versions and compare all generated records."""
    require_terminal_study()
    marker = REPOSITORY / '.cache/storage-local-root.txt'
    assert not marker.exists(), 'Inspect the previous qualification; preserve its root instead of overwriting it'
    with marker.open('x', encoding='utf-8') as output:
        root = pathlib.Path(tempfile.mkdtemp(prefix='rustdom-storage-ledger-'))
        output.write(str(root) + '\n')
    snapshot = root / 'repository'
    snapshot.mkdir()
    audits = json.loads((REPOSITORY / 'reports/progress/inventory/audits.json').read_bytes())
    assert len(audits) == 105
    paths = {'package.json', 'package-lock.json', 'scripts/migration-inventory.cjs',
             'scripts/constants/migration-inventory.cjs', 'scripts/memory-endpoint.cjs',
             'tests/validation/migration-inventory.spec.mjs', 'tests/helpers/inventory-memory.cjs',
             'reports/progress/inventory/audits.json'}
    paths.update(path.relative_to(REPOSITORY).as_posix()
                 for path in (REPOSITORY / 'scripts/migration-inventory').rglob('*.cjs'))
    for audit in audits.values():
        for field in ['rustSources', 'javascriptSources', 'tests', 'evidence']:
            paths.update(audit[field])
    sources = {}
    for relative in sorted(paths):
        raw = (REPOSITORY / relative).read_bytes()
        target = snapshot / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
        sources[relative] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    for name in ['jsdom', 'typescript']:
        assert (DEPENDENCIES / name / 'package.json').read_bytes() == (REPOSITORY / 'node_modules' / name / 'package.json').read_bytes()
    (snapshot / 'node_modules').symlink_to(DEPENDENCIES, target_is_directory=True)
    (root / 'sources.json').write_text(json.dumps(sources, indent=2) + '\n')
    (root / 'dependency-location.json').write_text(json.dumps({
        'nodeModules': str(DEPENDENCIES), 'reusedReadOnly': True}, indent=2) + '\n')
    print(f'ROOT {root}', flush=True)
    for label, node in NODES.items():
        for operation, arguments in [
            ('generator', ['scripts/migration-inventory.cjs', '--output', str(root / f'{label}-catalog')]),
            ('contracts', ['--test', '--test-reporter=tap', 'tests/validation/migration-inventory.spec.mjs']),
            ('memory', ['--expose-gc', 'tests/helpers/inventory-memory.cjs']),
        ]:
            run_command(root, snapshot, f'{label}-{operation}', [node, *arguments])
    generated = {label: {name: json.loads((root / f'{label}-catalog' / name).read_bytes())
                         for name in CATALOG_FILES} for label in NODES}
    published = REPOSITORY / 'reports/progress/inventory'
    for label, catalog in generated.items():
        for name in ['reference.json', 'implementation-units.json']:
            assert (root / f'{label}-catalog' / name).read_bytes() == (published / name).read_bytes()
        assert catalog['surface.json']['apis'] == json.loads((published / 'surface.json').read_bytes())['apis']
        summary = catalog['summary.json']
        assert [summary['counts'][kind]['total'] for kind in ['files', 'apis', 'callableUnits']] == [531, 4374, 7246]
        assert [summary['counts'][kind]['audited'] for kind in ['files', 'apis', 'callableUnits']] == [18, 32, 55]
        assert summary['scopeClosed'] is False and summary['migrationPercent'] is None
        log = (root / f'{label}-contracts.stdout.log').read_text()
        for expected in ['# tests 13', '# pass 13', '# fail 0', '# cancelled 0', '# skipped 0']:
            assert expected in log.splitlines(), (label, expected)
        memory = json.loads((root / f'{label}-memory.stdout.log').read_bytes())
        assert memory['released'] and memory['cycles'] == memory['reportsRetained'] == 3
        assert memory['survivors'] == {'windows': 0, 'documents': 0}
    for name in CATALOG_FILES:
        if name != 'surface.json':
            assert (root / 'node-22-catalog' / name).read_bytes() == (root / 'node-24-catalog' / name).read_bytes()
    first, second = [generated[label]['surface.json'] for label in NODES]
    for key in first.keys() - {'profile', 'exclusions'}:
        assert first[key] == second[key], key
    assert {key: value for key, value in first['profile'].items() if key != 'node'} == {
        key: value for key, value in second['profile'].items() if key != 'node'}
    assert [first['profile']['node'], second['profile']['node']] == ['v22.12.0', 'v24.14.1']
    globals_ = json.loads((DEPENDENCIES / 'jsdom/lib/jsdom/browser/js-globals.json').read_bytes())
    exclusions = [{json.dumps(entry, sort_keys=True) for entry in surface['exclusions']} for surface in [first, second]]
    differences = [json.loads(entry) for entry in sorted(exclusions[0] ^ exclusions[1])]
    assert all(entry['reason'] == 'ecmascript-host-global' and entry['name'] in globals_ for entry in differences)
    common = exclusions[0] & exclusions[1]
    assert [entry for entry in first['exclusions'] if json.dumps(entry, sort_keys=True) in common] == [
        entry for entry in second['exclusions'] if json.dumps(entry, sort_keys=True) in common]
    for relative, metadata in sources.items():
        for base in [REPOSITORY, snapshot]:
            raw = (base / relative).read_bytes()
            assert len(raw) == metadata['bytes'] and hashlib.sha256(raw).hexdigest() == metadata['sha256'], relative
    receipt = {'linuxCommandsPassed': True, 'testsPerNode': 13, 'sources': len(sources),
               'surfaceApiRecordsIdentical': True, 'hostExclusionDifferencesPreserved': differences,
               'productionChanged': False, 'nativeAddonExecuted': False,
               'summary': generated['node-22']['summary.json']}
    (root / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print('COMPLETE: preserve Linux results; Windows validation and publication are still separate', flush=True)


if __name__ == '__main__':
    if sys.argv[1:] == ['--check-ready']:
        require_terminal_study()
        print('Existing study terminal and verified; qualification may start')
    else:
        assert not sys.argv[1:], 'Supported invocation: no arguments or --check-ready'
        qualify()
