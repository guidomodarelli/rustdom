"""Preserve already completed Storage qualification; no tests or measurements."""
import hashlib
import json
import pathlib
import shutil
import subprocess
import tarfile
import tempfile

repository = pathlib.Path('/mnt/c/Users/guido/.codex/worktrees/migration-inventory/rustdom')
qualified = pathlib.Path('/tmp/rustdom-storage-ledger-q3bsyskx')
normalized = pathlib.Path('/tmp/rustdom-storage-ledger-lf-proof-kxrb43o1')
windows = repository / '.cache/storage-windows-qualification'
output = repository / 'reports/validation/inventory-storage-ledger'
memory = repository / 'reports/memory/inventory-storage-ledger'
assert not output.exists() and not memory.exists()
linux_receipt = json.loads((qualified / 'receipt.json').read_text())
windows_receipt = json.loads((windows / 'receipt.json').read_text())
lf_receipt = json.loads((normalized / 'receipt.json').read_text())
assert linux_receipt['linuxCommandsPassed'] and windows_receipt['complete'] and lf_receipt['complete']
assert linux_receipt['testsPerNode'] == windows_receipt['testsPerNode'] == 13
assert windows_receipt['sourceBytesUnchanged']
audits = json.loads((repository / 'reports/progress/inventory/audits.json').read_bytes())
old = json.loads(subprocess.check_output(['git.exe', '-C', 'C:/Users/guido/.codex/worktrees/migration-inventory/rustdom',
                                        'show', 'HEAD:reports/progress/inventory/audits.json']))
assert len(old) == 84 and len(audits) == 105
assert all(audits[key] == value for key, value in old.items())
for label in ['node-22', 'node-24']:
    for operation in ['generator', 'contracts', 'memory']:
        assert json.loads((qualified / (label + '-' + operation + '.process.json')).read_text())['exitCode'] == 0
    memory_record = json.loads((qualified / (label + '-memory.stdout.log')).read_text())
    assert memory_record['cycles'] == memory_record['reportsRetained'] == 3 and memory_record['released']
    assert memory_record['survivors'] == {'windows': 0, 'documents': 0}
    for root, name in [(qualified, label + '-contracts.stdout.log'), (windows, label + '.stdout.log')]:
        lines = (root / name).read_text().splitlines()
        for expected in ['# tests 13', '# pass 13', '# fail 0', '# cancelled 0', '# skipped 0']:
            assert expected in lines, (root, expected)
for relative, expected in json.loads((qualified / 'sources.json').read_text()).items():
    raw = (repository / relative).read_bytes()
    digest = lf_receipt['publishedLfSha256'] if relative.endswith('/audits.json') else expected['sha256']
    assert hashlib.sha256(raw).hexdigest() == digest, relative

bundle = pathlib.Path(tempfile.mkdtemp(prefix='rustdom-storage-ledger-evidence-'))
for source, name in [(qualified, 'linux'), (normalized, 'lf-proof'), (windows, 'windows')]:
    shutil.copytree(source, bundle / name, ignore=shutil.ignore_patterns('node_modules'))
tools = bundle / 'tools'
tools.mkdir()
for name in ['qualify-storage-ledger.py', 'normalize-storage-ledger.py', 'package-storage-ledger.py']:
    shutil.copyfile(repository / '.cache' / name, tools / name)
dependencies = pathlib.Path('/tmp/rustdom-runner-suites-ytu9q4xb/static-prepared/packages/B/node_modules')
dependency_manifest = pathlib.Path('/tmp/rustdom-pre-gc-method-exroua90/test-dependency-inventory.json')
expected_dependencies = json.loads(dependency_manifest.read_text())
for entry in expected_dependencies['files']:
    raw = (dependencies.parent / entry['path']).read_bytes()
    assert len(raw) == entry['bytes'] and hashlib.sha256(raw).hexdigest() == entry['sha256'], entry['path']
shutil.copyfile(dependency_manifest, bundle / 'dependencies.json')
entries = {path.relative_to(bundle).as_posix(): {'bytes': path.stat().st_size,
           'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
           for path in sorted(bundle.rglob('*')) if path.is_file()}
output.mkdir()
(output / 'raw-files.json').write_text(json.dumps(entries, indent=2) + '\n')
archive = output / 'qualification.tar.gz'
with tarfile.open(archive, 'w:gz') as stream:
    stream.add(bundle, arcname='storage-ledger')
actual = {}
with tarfile.open(archive) as stream:
    for member in stream:
        if member.isfile():
            actual[member.name.removeprefix('storage-ledger/')] = {'bytes': member.size,
                    'sha256': hashlib.sha256(stream.extractfile(member).read()).hexdigest()}
assert actual == entries
memory.mkdir()
for label in ['node-22', 'node-24']:
    shutil.copyfile(qualified / (label + '-memory.stdout.log'), memory / (label + '.json'))
for name in ['classification.json', 'summary.json']:
    raw = (normalized / 'node-22-catalog' / name).read_bytes()
    assert raw == (qualified / 'node-22-catalog' / name).read_bytes()
    (repository / 'reports/progress/inventory' / name).write_bytes(raw)
receipt = {'linux': linux_receipt, 'windows': windows_receipt, 'lfProof': lf_receipt,
           'previousAuditRecords': 84, 'newAuditRecords': 21, 'totalAuditRecords': 105,
           'archiveBytes': archive.stat().st_size, 'archiveSha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
           'rawFiles': len(entries), 'archiveReadbackMatched': True,
           'dependencyFilesMatchedHistoricalFrozenTree': len(expected_dependencies['files']),
           'nativeAddonExecuted': False, 'productionChanged': False, 'newPerformanceMeasurementsExecuted': False}
(output / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({key: value for key, value in receipt.items() if key not in ['linux', 'windows', 'lfProof']}), flush=True)
