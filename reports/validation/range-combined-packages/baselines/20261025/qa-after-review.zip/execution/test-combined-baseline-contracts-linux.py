import os,subprocess,sys
from pathlib import Path
env=dict(os.environ,RUSTDOM_COMBINED_BASELINE_SOURCE="/home/guido/rustdom-validation/range-collapse-packages-20261024/prepared")
result=subprocess.run([sys.argv[1],"--test","--test-concurrency=1","/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom/reports/benchmarks/native-class-ownership/range-combined-packages/baselines.spec.cjs"],env=env)
raise SystemExit(result.returncode)
