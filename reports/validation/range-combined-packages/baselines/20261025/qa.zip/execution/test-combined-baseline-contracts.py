import json,subprocess
from pathlib import Path
repo=Path.cwd();out=repo/'.cache/combined-baseline-contracts';out.mkdir()
script='''import os,subprocess,sys
from pathlib import Path
env=dict(os.environ,RUSTDOM_COMBINED_BASELINE_SOURCE="/home/guido/rustdom-validation/range-collapse-packages-20261024/prepared")
result=subprocess.run([sys.argv[1],"--test","--test-concurrency=1","/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom/reports/benchmarks/native-class-ownership/range-combined-packages/baselines.spec.cjs"],env=env)
raise SystemExit(result.returncode)
'''
runner=repo/'.cache/test-combined-baseline-contracts-linux.py';runner.write_text(script,encoding='utf-8',newline='\n')
records=[]
for label,node in [('node22','/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node-22/bin/node'),('node24','/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node/bin/node')]:
 argv=['wsl','-d','Ubuntu-22.04','--cd','/','--','python3','-B','/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom/.cache/test-combined-baseline-contracts-linux.py',node]
 with (out/(label+'.stdout.log')).open('xb') as stdout,(out/(label+'.stderr.log')).open('xb') as stderr:result=subprocess.run(argv,stdout=stdout,stderr=stderr)
 records.append({'node':label,'argv':argv,'exitCode':result.returncode});(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(records[-1]),flush=True);assert result.returncode==0,label
