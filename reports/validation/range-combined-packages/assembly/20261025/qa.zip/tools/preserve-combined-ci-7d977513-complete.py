"""Preserve the complete selected six-job functional matrix and original transport; never executes archived helpers."""
import hashlib,json,shutil,subprocess,zipfile
from pathlib import Path
repo=Path.cwd();collection=repo/'.cache/combined-ci-collection-40168321423';run=json.loads((collection/'run.json').read_bytes());assert run['id']==40168321423 and run['run_attempt']==1 and run['status']=='completed' and run['conclusion']=='success' and run['head_sha']=='7d97751344d02100bbfc38a03a074ec0965cc752'
def sha(raw):return hashlib.sha256(raw).hexdigest()
logs=collection/'run-logs.zip';assert not logs.exists();logs.write_bytes(subprocess.check_output(['gh','api','repos/guidomodarelli/rustdom/actions/runs/40168321423/attempts/1/logs']))
with zipfile.ZipFile(logs) as archive:
 assert archive.testzip() is None
 logmeta={'run':40168321423,'attempt':1,'bytes':logs.stat().st_size,'sha256':sha(logs.read_bytes()),'members':[{'name':member.filename,'bytes':member.file_size,'sha256':sha(archive.read(member))} for member in archive.infolist()]}
(collection/'run-logs.json').write_text(json.dumps(logmeta,indent=2)+'\n',encoding='utf-8',newline='\n')
receipt=json.loads((collection/'collection.json').read_bytes());assert len(receipt['artifacts'])==6
manifest=json.loads((repo/'reports/implementation/range-combined-candidate/source.json').read_bytes());results=[]
for metadata in receipt['artifacts']:
 path=collection/('artifact-'+str(metadata['artifact']))/'artifact.zip';assert sha(path.read_bytes())==metadata['sha256']
 with zipfile.ZipFile(path) as archive:
  qualification=json.loads(archive.read(next(name for name in archive.namelist() if name.endswith('/combined-range-proof/qualification.json'))))
  assert qualification['qualified'] and len(qualification['commands'])==22 and all(command['exitCode']==0 and not command['timedOut'] for command in qualification['commands'])
  assert qualification['sourceCommit']==manifest['baseCommit'] and not qualification['sourceGitErrors']
  assert qualification['preparedSource']['sourceFiles']==manifest['sources'] and qualification['preparedSource']['patchSha256']==manifest['patchSha256']
  assert qualification['performanceAccepted'] is None and qualification['gateReevaluated'] is False
  native_name=next(name for name in archive.namelist() if name.endswith('/combined-range-source/dist/native-build.json'));native=json.loads(archive.read(native_name));assert sha(archive.read(native_name.replace('native-build.json','rustdom.node')))==native['binarySha256']
  assert native==qualification['nativeBuild']
  results.append({'artifact':metadata['artifact'],'name':metadata['name'],'platform':qualification['platform'],'node':qualification['node'],'qualified':True,'commands':22,'binarySha256':native['binarySha256'],'performanceAccepted':None,'gateReevaluated':False})
assert {(value['platform'],value['node']) for value in results}=={(platform,node) for platform in ['linux','darwin','win32'] for node in ['v22.12.0','v24.14.1']}
out=repo/'reports/validation/range-combined-ci/40168321423';assert not out.exists();out.mkdir()
for file in sorted(collection.rglob('*')):
 if file.is_file():
  target=out/'transport'/file.relative_to(collection);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(file,target)
(out/'summary.json').write_text(json.dumps({'run':40168321423,'attempt':1,'head':run['head_sha'],'conclusion':'success','results':results,'qualifiedJobs':6,'failedJobs':0,'authenticatedArtifacts':6,'completeFunctionalEvidence':True,'runtimeIntegrated':False,'benchmarkExecuted':False,'performanceAccepted':None,'gateReevaluated':False,'methodPinsPreserved':599,'foreignEntriesPreserved':48},indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'.gitattributes').write_text('*.json -text\n*.zip -text\ntransport/collection.json whitespace=cr-at-eol\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# Matriz funcional7d977513: seis jobs aprobados

Run40168321423,intento1,fuente7d977513 terminó success6/6. Linux,macOS yWindows
calificaron el candidato combinado con22comandos aprobados por job en ambos
Node22.12.0/24.14.1. La corrección de ruta permite descubrir y ejecutar Jest
Windows; la evidencia anterior fallida permanece separada e intacta.

Los seis artifacts completos se autentican por ID/run/commit/intento/nombre/
tamaño/digest. Se conservan ZIPs,metadata API,manifiestos por miembro,snapshots
de observación,run/jobs y logs completos. Se contrastan las fuentes/patch/base
del candidato y el hash de cada binario. No se normalizan sourceCommit,
sourceChangesRaw o sourceGitErrors ni se ejecutan scripts archivados al leer.

Cada job preserva suites públicas,WPT/fallos compartidos/exclusiones y probes
finitos de Window/Document separados. No es una captura científica ni aceptación
de rendimiento,memoria pico o garantía universal de ausencia de fugas. El perfil
Linuxx64/Node24 fue seleccionado antes de medir; su binding y paquete se preparan
por separado. Runtime híbrido,no integrado;rechazos históricos vigentes.
Conservados599pins/48entradas ajenas,sin tag o merge de ownership.
''',encoding='utf-8',newline='\n')
files={file.relative_to(out).as_posix():{'bytes':file.stat().st_size,'sha256':sha(file.read_bytes())} for file in out.rglob('*') if file.is_file()};(out/'files.json').write_text(json.dumps({'files':files,'excludedSelfReference':'files.json'},indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'files':len(files),'artifacts':6,'qualifiedJobs':6,'logsMembers':len(logmeta['members']),'selected':[value for value in results if value['platform']=='linux' and value['node']=='v24.14.1']}))
