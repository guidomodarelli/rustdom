"""Prepare a real immutable compiler-source checkout, without installing, building or loading runtime packages."""
import hashlib,json,subprocess
from pathlib import Path
repository=Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom')
objects=Path('/mnt/c/Users/guido/ghq/projects/rustdom/.git/objects');assert objects.is_dir()
destination=Path('/home/guido/rustdom-validation/combined-range-package-source-20261025-f781');assert not destination.exists()
proof=Path('/home/guido/rustdom-validation/combined-range-package-source-proof-20261025');assert not proof.exists()
subprocess.run(['git','init','-q',str(destination)],check=True)
(destination/'.git/objects/info/alternates').write_text(str(objects)+'\n',encoding='utf-8')
subprocess.run(['git','-C',str(destination),'config','core.autocrlf','false'],check=True)
subprocess.run(['git','-C',str(destination),'checkout','--detach','f781c3b7549a86b6aa8b5a34d2bbb32038c315b7'],check=True)
subprocess.run(['python3','-B',str(repository/'reports/implementation/range-combined-candidate/tools/prepare.py'),str(repository),str(destination),str(proof)],check=True)
node=Path('/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node-22/bin/node')
script=repository/'.cache/capture-combined-package-source.cjs'
result=subprocess.run([str(node),str(script),str(destination)],check=True,capture_output=True)
(proof/'source-identity.json').write_bytes(result.stdout)
identity=json.loads(result.stdout);assert identity['sourceCommit']=='f781c3b7549a86b6aa8b5a34d2bbb32038c315b7' and not identity['sourceGitErrors']
files={name:hashlib.sha256((destination/name).read_bytes()).hexdigest() for name in identity['measuredSources']}
(proof/'source-files.json').write_text(json.dumps(files,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'sourceHash':identity['sourceHash'],'sourceFiles':len(files),'sourceCommit':identity['sourceCommit'],'sourceChanges':identity['sourceChanges'],'runtimeExecuted':False,'installExecuted':False,'rustRebuilt':False,'benchmarkExecuted':False}))
