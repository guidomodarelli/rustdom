import json,subprocess,sys,unittest
from pathlib import Path
repo=Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom');packet=repo/'reports/benchmarks/native-class-ownership/range-combined-packages';sys.path.insert(0,str(packet));import extract
output=repo/'.cache/combined-package-roundtrip';output.mkdir()
tests=unittest.TextTestRunner(verbosity=2).run(unittest.TestLoader().discover(str(packet),pattern='test_extract.py'));assert tests.wasSuccessful()
extracted=extract.extract(repo,Path('/home/guido/rustdom-validation/combined-range-package-roundtrip-20261025'))
(output/'extraction.json').write_text(json.dumps(extracted,indent=2)+'\n',encoding='utf-8',newline='\n')
records=[]
for label,node in [('node22','/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node-22/bin/node'),('node24','/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node/bin/node')]:
 for operation,arguments in [('verify',['python3','-B',str(packet/'assemble.py'),'--verify',extracted['root'],str(repo/'reports/validation/range-combined-ci/40168321423/transport'),node]),('probe',[node,'--expose-gc',str(packet/'probe.cjs'),extracted['root']])]:
  with (output/(label+'-'+operation+'.stdout.log')).open('xb') as stdout,(output/(label+'-'+operation+'.stderr.log')).open('xb') as stderr:result=subprocess.run(arguments,stdout=stdout,stderr=stderr)
  records.append({'node':label,'operation':operation,'argv':arguments,'exitCode':result.returncode});(output/'commands.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(records[-1]),flush=True);assert result.returncode==0
