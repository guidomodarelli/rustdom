"""Bind the predeclared successful functional matrix before package materialization or performance measurement."""
import importlib.util,json,hashlib
from pathlib import Path
repo=Path.cwd();packet=repo/'reports/benchmarks/native-class-ownership/range-combined-packages';collection=repo/'reports/validation/range-combined-ci/40168321423/transport'
selection=json.loads((packet/'constants/selection.json').read_bytes());assert selection['artifactId'] is None and not selection['packagePrepared'] and selection['run']==40168321423
summary=json.loads((collection.parent/'summary.json').read_bytes());assert summary['completeFunctionalEvidence'] and summary['qualifiedJobs']==6
metadata=next(value for value in json.loads((collection/'artifacts.json').read_bytes())['artifacts'] if value['name']==selection['profile']['artifactName'])
spec=importlib.util.spec_from_file_location('combined_artifact',packet/'artifact.py');reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(reader)
selected=reader.inspect_artifact(repo,collection/('artifact-'+str(metadata['id']))/'artifact.zip',metadata)
files={file.relative_to(collection).as_posix():hashlib.sha256(file.read_bytes()).hexdigest() for file in collection.rglob('*') if file.is_file() and 'history' not in file.relative_to(collection).parts}
binding={'complete':True,'artifactId':metadata['id'],'digest':metadata['digest'],'bytes':metadata['size_in_bytes'],'binarySha256':selected['binarySha256'],'collectionDirectory':collection.relative_to(repo).as_posix(),'collectionFiles':files,'qualifiedJobs':6,'selectionBeforeMeasurements':True,'runtimeExecuted':False,'benchmarkExecuted':False,'performanceAccepted':None,'gateReevaluated':False}
(packet/'constants/artifact-binding.json').write_text(json.dumps(binding,indent=2)+'\n',encoding='utf-8',newline='\n')
selection['artifactId']=metadata['id'];(packet/'constants/selection.json').write_text(json.dumps(selection,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'artifactId':metadata['id'],'bytes':metadata['size_in_bytes'],'digest':metadata['digest'],'binarySha256':selected['binarySha256'],'boundFiles':len(files),'qualifiedJobs':6}))
