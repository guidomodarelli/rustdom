import json,subprocess
from pathlib import Path
repo=Path.cwd();out=repo/'.cache/combined-package-materialization';out.mkdir()
base='/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom/'
argv=['wsl','-d','Ubuntu-22.04','--cd','/','--','python3','-B',base+'reports/benchmarks/native-class-ownership/range-combined-packages/assemble.py','--prepare','/home/guido/rustdom-validation/range-combined-baselines-20261025',base+'reports/validation/range-combined-ci/40168321423/transport','/home/guido/rustdom-validation/combined-range-package-source-20261025-f781','/home/guido/rustdom-validation/combined-range-packages-20261025','/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node-22/bin/node']
with (out/'stdout.log').open('xb') as stdout,(out/'stderr.log').open('xb') as stderr:result=subprocess.run(argv,stdout=stdout,stderr=stderr)
(out/'command.json').write_text(json.dumps({'argv':argv,'exitCode':result.returncode},indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps({'exitCode':result.returncode}));raise SystemExit(result.returncode)
