import json,subprocess,sys,time
from pathlib import Path
repo=Path.cwd();out=repo/'.cache/combined-package-contracts';out.mkdir()
base='/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom/'
wsl=['wsl','-d','Ubuntu-22.04','--cd','/','--']
commands=[('reader-windows',[sys.executable,'-B','-m','unittest','discover','-s','reports/benchmarks/native-class-ownership/range-combined-packages','-p','test_artifact.py','-v']),('reader-linux',wsl+['python3','-B',base+'.cache/test-combined-artifact-linux.py'])]
for label,node in [('node22','/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node-22/bin/node'),('node24','/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node/bin/node')]:
 commands.append((label,wsl+['python3','-B',base+'.cache/test-combined-assembly-linux.py',node]))
records=[]
for label,argv in commands:
 started=time.perf_counter()
 with (out/(label+'.stdout.log')).open('xb') as stdout,(out/(label+'.stderr.log')).open('xb') as stderr:result=subprocess.run(argv,stdout=stdout,stderr=stderr)
 records.append({'label':label,'argv':argv,'exitCode':result.returncode,'seconds':time.perf_counter()-started});(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(records[-1]),flush=True);assert result.returncode==0,label
