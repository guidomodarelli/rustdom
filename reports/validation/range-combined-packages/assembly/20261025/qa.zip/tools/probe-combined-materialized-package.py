import json,subprocess,time
from pathlib import Path
repo=Path.cwd();out=repo/'.cache/combined-materialized-probes';out.mkdir()
base='/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom/'
records=[]
for label,node in [('node22','/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node-22/bin/node'),('node24','/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node/bin/node')]:
 argv=['wsl','-d','Ubuntu-22.04','--cd','/','--',node,'--expose-gc',base+'reports/benchmarks/native-class-ownership/range-combined-packages/probe.cjs','/home/guido/rustdom-validation/combined-range-packages-20261025']
 started=time.perf_counter()
 with (out/(label+'.stdout.log')).open('xb') as stdout,(out/(label+'.stderr.log')).open('xb') as stderr:result=subprocess.run(argv,stdout=stdout,stderr=stderr)
 records.append({'node':label,'argv':argv,'exitCode':result.returncode,'seconds':time.perf_counter()-started});(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(records[-1]),flush=True);assert result.returncode==0,label
