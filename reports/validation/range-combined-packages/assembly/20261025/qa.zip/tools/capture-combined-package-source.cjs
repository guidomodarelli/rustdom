'use strict';
const { captureSourceIdentity } = require('../benchmarks/sources.cjs');
console.log(JSON.stringify(captureSourceIdentity(process.argv[2])));
