"""Preserve the complete verified assembly as data before freezing its future measurement method."""
import hashlib,json,sys,tarfile
from pathlib import Path
repo=Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom');packet=repo/'reports/benchmarks/native-class-ownership/range-combined-packages';sys.path.insert(0,str(packet));import assemble
root=Path('/home/guido/rustdom-validation/combined-range-packages-20261025');collection=repo/'reports/validation/range-combined-ci/40168321423/transport';node=Path('/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node-22/bin/node')
verified=assemble.verify(root,collection,node)
out=repo/'reports/validation/range-combined-packages/assembly/20261025';out.mkdir(parents=True)
archive_path=out/'packages.tar.xz';assert not archive_path.exists()
archive_root='combined-range-packages'
with tarfile.open(archive_path,'x:xz',preset=6) as archive:
 for file in [root,*sorted(root.rglob('*'))]:
  relative=archive_root if file==root else archive_root+'/'+file.relative_to(root).as_posix()
  info=archive.gettarinfo(str(file),arcname=relative);info.uid=info.gid=info.mtime=0;info.uname=info.gname=''
  if info.isfile():
   with file.open('rb') as stream:archive.addfile(info,stream)
  else:archive.addfile(info)
members=[]
with tarfile.open(archive_path) as archive:
 for member in archive:
  record={'path':member.name}
  if member.isfile():record.update(kind='file',bytes=member.size,sha256=hashlib.sha256(archive.extractfile(member).read()).hexdigest())
  elif member.isdir():record['kind']='directory'
  else:
   assert member.issym(),'Do not replace independent runtime files with hardlinks';record.update(kind='symlink',target=member.linkname)
  members.append(record)
assert sum(member['kind']=='symlink' for member in members)==6
assert assemble.verify(root,collection,node)==verified
manifest=out/'archive-members.json';manifest.write_text(json.dumps({'members':members},indent=2)+'\n',encoding='utf-8',newline='\n')
policy={'archive':{'path':archive_path.relative_to(repo).as_posix(),'root':archive_root,'bytes':archive_path.stat().st_size,'sha256':hashlib.sha256(archive_path.read_bytes()).hexdigest()},'members':{'path':manifest.relative_to(repo).as_posix(),'sha256':hashlib.sha256(manifest.read_bytes()).hexdigest()},'extractor':{'path':'reports/benchmarks/native-class-ownership/jsdom-telemetry-results/39959175058/tools/extract-current-ownership-result.py','sha256':'ae23a0e0b371c357d28a7979b01b3ac38af584a5696abad99ecd8c3657762c01'},'runtimeExecuted':False,'benchmarkExecuted':False,'performanceAccepted':None,'gateReevaluated':False}
(packet/'constants/archive.json').write_text(json.dumps(policy,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'prepared-verification.json').write_text(json.dumps(verified,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'archive':policy['archive'],'members':len(members),'links':6,'candidateFiles':verified['candidateFiles']}))
