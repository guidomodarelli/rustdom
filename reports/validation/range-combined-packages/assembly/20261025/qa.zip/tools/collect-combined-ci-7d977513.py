"""Read only the published functional CI run; preserve API and authenticate its artifacts without executing them."""
import datetime,hashlib,json,subprocess,sys,zipfile
from pathlib import Path
RUN=40168321423
HEAD='7d97751344d02100bbfc38a03a074ec0965cc752'
REPOSITORY='guidomodarelli/rustdom'
root=Path.cwd();out=root/'.cache/combined-ci-collection-40168321423';out.mkdir(exist_ok=True)
def api(path):return subprocess.check_output(['gh','api','repos/'+REPOSITORY+'/'+path])
def save_snapshot(label,raw):
 path=out/(label+'.json')
 if path.exists():
  old=path.read_bytes()
  if old!=raw:
   history=out/'history';history.mkdir(exist_ok=True)
   prior=history/(label+'-'+hashlib.sha256(old).hexdigest()+'.json')
   if not prior.exists():prior.write_bytes(old)
 path.write_bytes(raw)
run_raw=api('actions/runs/'+str(RUN));run=json.loads(run_raw)
assert run['id']==RUN and run['head_sha']==HEAD and run['run_attempt']==1
assert run['path']=='.github/workflows/combined-range-candidate.yml'
jobs_raw=api('actions/runs/'+str(RUN)+'/jobs?per_page=100');jobs=json.loads(jobs_raw)
assert jobs['total_count']==6 and len(jobs['jobs'])==6
save_snapshot('run',run_raw);save_snapshot('jobs',jobs_raw)
if '--collect' in sys.argv:
 assert run['status']=='completed','Preserve active CI; do not download incomplete artifacts'
 raw=api('actions/runs/'+str(RUN)+'/artifacts?per_page=100');save_snapshot('artifacts',raw)
 artifacts=json.loads(raw);assert len(artifacts['artifacts'])==artifacts['total_count']
 receipt=[]
 for meta in artifacts['artifacts']:
  assert meta['workflow_run']['id']==RUN and meta['workflow_run']['head_sha']==HEAD and not meta['expired']
  assert meta['name'].startswith('combined-range-') and meta['name'].endswith('-'+HEAD)
  directory=out/('artifact-'+str(meta['id']));directory.mkdir(exist_ok=True)
  metadata=json.dumps(meta,indent=2).encode()+b'\n';metadata_path=directory/'metadata.json'
  if metadata_path.exists():assert metadata_path.read_bytes()==metadata
  else:metadata_path.write_bytes(metadata)
  archive=directory/'artifact.zip'
  if not archive.exists():
   raw=api('actions/artifacts/'+str(meta['id'])+'/zip')
   assert len(raw)==meta['size_in_bytes'] and 'sha256:'+hashlib.sha256(raw).hexdigest()==meta['digest']
   archive.write_bytes(raw)
  raw=archive.read_bytes();assert len(raw)==meta['size_in_bytes'] and 'sha256:'+hashlib.sha256(raw).hexdigest()==meta['digest']
  with zipfile.ZipFile(archive) as z:
   assert z.testzip() is None
   members=[{'name':i.filename,'bytes':i.file_size,'sha256':hashlib.sha256(z.read(i)).hexdigest()} for i in z.infolist()]
  manifest=directory/'members.json';manifest_raw=json.dumps(members,indent=2).encode()+b'\n'
  if manifest.exists():assert manifest.read_bytes()==manifest_raw
  else:manifest.write_bytes(manifest_raw)
  receipt.append({'artifact':meta['id'],'name':meta['name'],'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'members':len(members)})
 (out/'collection.json').write_text(json.dumps({'run':RUN,'head':HEAD,'attempt':1,'status':run['status'],'conclusion':run['conclusion'],'artifacts':receipt,'archivedCodeExecuted':False,'benchmarkExecuted':False},indent=2)+'\n',encoding='utf-8')
print(json.dumps({'run':RUN,'status':run['status'],'conclusion':run['conclusion'],'jobs':[{'id':job['id'],'name':job['name'],'status':job['status'],'conclusion':job['conclusion'],'step':next((step['name'] for step in job['steps'] if step['status']=='in_progress'),None)} for job in jobs['jobs']]}))
