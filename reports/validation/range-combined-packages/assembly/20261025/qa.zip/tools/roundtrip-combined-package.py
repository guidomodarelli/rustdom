import json,subprocess,sys
from pathlib import Path
out=Path('.cache/combined-package-roundtrip-execution');out.mkdir()
commands=[('extract-windows',[sys.executable,'-B','-m','unittest','discover','-s','reports/benchmarks/native-class-ownership/range-combined-packages','-p','test_extract.py','-v']),('roundtrip-linux',['wsl','-d','Ubuntu-22.04','--cd','/','--','python3','-B','/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom/.cache/roundtrip-combined-package-linux.py'])]
records=[]
for label,argv in commands:
 with (out/(label+'.stdout.log')).open('xb') as stdout,(out/(label+'.stderr.log')).open('xb') as stderr:result=subprocess.run(argv,stdout=stdout,stderr=stderr)
 records.append({'label':label,'argv':argv,'exitCode':result.returncode});(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(records[-1]),flush=True);assert result.returncode==0,label
