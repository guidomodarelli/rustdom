import json,subprocess
from pathlib import Path
out=Path('.cache/combined-package-source-preparation');out.mkdir()
argv=['wsl','-d','Ubuntu-22.04','--cd','/','--','python3','-B','/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom/.cache/prepare-combined-package-source-linux.py']
with (out/'stdout.log').open('xb') as stdout,(out/'stderr.log').open('xb') as stderr:result=subprocess.run(argv,stdout=stdout,stderr=stderr)
(out/'command.json').write_text(json.dumps({'argv':argv,'exitCode':result.returncode},indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'exitCode':result.returncode}));raise SystemExit(result.returncode)
