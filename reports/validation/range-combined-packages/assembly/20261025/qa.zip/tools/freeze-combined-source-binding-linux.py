"""Pin actual compiler checkout bytes and Git provenance after a reviewed patch, without building a package."""
import importlib.util,json,sys
from pathlib import Path
repo=Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom');packet=repo/'reports/benchmarks/native-class-ownership/range-combined-packages';sys.path.insert(0,str(packet))
spec=importlib.util.spec_from_file_location('combined_assembly',packet/'assemble.py');assembly=importlib.util.module_from_spec(spec);spec.loader.exec_module(assembly)
source=Path('/home/guido/rustdom-validation/combined-range-package-source-20261025-f781');proof=Path('/home/guido/rustdom-validation/combined-range-package-source-proof-20261025')
identity=json.loads((proof/'source-identity.json').read_bytes());preparation=json.loads((proof/'preparation.json').read_bytes())
assert preparation['prepared'] and preparation['sourceCommit']==identity['sourceCommit']=='f781c3b7549a86b6aa8b5a34d2bbb32038c315b7' and not identity['sourceGitErrors']
files=assembly.source_files(source)
assert assembly.run_node(Path('/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node-22/bin/node'),'source-identity.cjs',source)==identity
binding={'complete':True,'identity':identity,'files':files,'compilerPreparation':preparation,'runtimeExecuted':False,'rustRebuilt':False,'benchmarkExecuted':False,'performanceAccepted':None,'gateReevaluated':False}
(packet/'constants/source-binding.json').write_text(json.dumps(binding,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'sourceFiles':len(files),'measuredSourceFiles':len(identity['measuredSources']),'sourceHash':identity['sourceHash'],'sourceCommit':identity['sourceCommit'],'sourceGitErrors':identity['sourceGitErrors']}))
