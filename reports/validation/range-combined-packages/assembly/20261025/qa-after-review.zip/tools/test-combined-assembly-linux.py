import os,sys,unittest
root='/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom/reports/benchmarks/native-class-ownership/range-combined-packages'
os.environ['RUSTDOM_COMBINED_PACKAGE_ROOT']='/home/guido/rustdom-validation/combined-range-packages-20261025'
os.environ['RUSTDOM_COMBINED_NODE']=sys.argv[1]
result=unittest.TextTestRunner(verbosity=2).run(unittest.TestLoader().discover(root,pattern='test_assemble.py'))
raise SystemExit(not result.wasSuccessful())
