import json,subprocess
from pathlib import Path
out=Path('.cache/combined-package-roundtrip-after-review');out.mkdir();records=[]
for label,node in [('node22','/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node-22/bin/node'),('node24','/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node/bin/node')]:
 argv=['wsl','-d','Ubuntu-22.04','--cd','/','--','python3','-B','/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom/reports/benchmarks/native-class-ownership/range-combined-packages/assemble.py','--verify','/home/guido/rustdom-validation/combined-range-package-roundtrip-20261025/combined-range-packages','/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom/reports/validation/range-combined-ci/40168321423/transport',node]
 with (out/(label+'.stdout.log')).open('xb') as stdout,(out/(label+'.stderr.log')).open('xb') as stderr:result=subprocess.run(argv,stdout=stdout,stderr=stderr)
 records.append({'node':label,'argv':argv,'exitCode':result.returncode});(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(records[-1]),flush=True);assert result.returncode==0,label
