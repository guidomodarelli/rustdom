import subprocess,sys
from pathlib import Path
root=Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom')
environment=root/'.cache/hooks-validation-linux-env'
if not environment.exists():subprocess.run([sys.executable,'-m','venv',str(environment)],check=True)
python=environment/'bin/python'
subprocess.run([str(python),'-m','pip','install','--disable-pip-version-check','-r',str(root/'.codex/hooks/requirements.txt')],check=True)
subprocess.run([str(python),'-B',str(root/'.cache/test-authorization-hooks-linux.py')],check=True)
