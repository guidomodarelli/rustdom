import unittest
root='/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom/reports/benchmarks/native-class-ownership/range-combined-packages'
result=unittest.TextTestRunner(verbosity=2).run(unittest.TestLoader().discover(root,pattern='test_artifact.py'))
raise SystemExit(not result.wasSuccessful())
