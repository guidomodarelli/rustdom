import unittest
root='/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom/.codex/hooks'
suite=unittest.TestLoader().discover(root,pattern='test_*.py')
result=unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(not result.wasSuccessful())
