import hashlib, json, pathlib

repo = pathlib.Path('/mnt/c/Users/guido/.codex/worktrees/migration-inventory/rustdom')
root = pathlib.Path((repo / '.cache/geometry-local-root.txt').read_text().strip())
snapshot = root / 'repository'
sources = json.loads((root / 'sources.json').read_bytes())
for relative, metadata in sources.items():
    for base in [repo, snapshot]:
        raw = (base / relative).read_bytes()
        assert len(raw) == metadata['bytes'] and hashlib.sha256(raw).hexdigest() == metadata['sha256'], relative
nodes = {'node-22': 'v22.12.0', 'node-24': 'v24.14.1'}
for label, version in nodes.items():
    for operation in ['generator', 'contracts', 'memory']:
        record = json.loads((root / f'{label}-{operation}.process.json').read_bytes())
        assert record['exitCode'] == 0
    contracts = (root / f'{label}-contracts.stdout.log').read_text()
    prefix = '# ' if label == 'node-22' else 'ℹ '
    for field in ['tests 12', 'pass 12', 'fail 0', 'cancelled 0', 'skipped 0']:
        assert prefix + field in contracts.splitlines(), (label, field)
    memory = json.loads((root / f'{label}-memory.stdout.log').read_bytes())
    assert memory['released'] and memory['cycles'] == memory['reportsRetained'] == 3
    assert memory['survivors'] == {'windows': 0, 'documents': 0}
    for name in ['reference.json', 'implementation-units.json', 'classification.json', 'summary.json']:
        assert (root / f'{label}-catalog' / name).read_bytes() == (repo / 'reports/progress/inventory' / name).read_bytes()
surfaces = [json.loads((root / f'{label}-catalog/surface.json').read_bytes()) for label in nodes]
assert (root / 'node-22-catalog/surface.json').read_bytes() == (repo / 'reports/progress/inventory/surface.json').read_bytes()
for surface, version in zip(surfaces, nodes.values()):
    assert surface['profile']['node'] == version
for key in surfaces[0].keys() - {'profile', 'exclusions'}:
    assert surfaces[0][key] == surfaces[1][key], key
assert {key: value for key, value in surfaces[0]['profile'].items() if key != 'node'} == {
    key: value for key, value in surfaces[1]['profile'].items() if key != 'node'}
host_globals = json.loads((snapshot / 'node_modules/jsdom/lib/jsdom/browser/js-globals.json').read_bytes())
excluded = [{json.dumps(entry, sort_keys=True) for entry in surface['exclusions']} for surface in surfaces]
differences = [json.loads(entry) for entry in sorted(excluded[0] ^ excluded[1])]
assert len(differences) == 4
assert all(entry['reason'] == 'ecmascript-host-global' and entry['name'] in host_globals for entry in differences)
common = excluded[0] & excluded[1]
assert [entry for entry in surfaces[0]['exclusions'] if json.dumps(entry, sort_keys=True) in common] == [
    entry for entry in surfaces[1]['exclusions'] if json.dumps(entry, sort_keys=True) in common]
summary = json.loads((root / 'node-24-catalog/summary.json').read_bytes())
assert [summary['counts'][kind]['total'] for kind in ['files', 'apis', 'callableUnits']] == [531, 4374, 7246]
assert [summary['counts'][kind]['audited'] for kind in ['files', 'apis', 'callableUnits']] == [16, 23, 45]
assert summary['scopeClosed'] is False and summary['migrationPercent'] is None
receipt = {'allProductCommandsPassed': True, 'sources': len(sources), 'productionChanged': False,
    'testsPerNode': 12, 'cliTimeoutMsUnchanged': 30000, 'surfaceApiRecordsIdentical': True,
    'surfaceOtherRecordsIdenticalExceptDeclaredHostMetadata': True,
    'completeSurfaceFilesByteIdenticalAcrossNodes': False,
    'hostDifferencesPreserved': {'nodeVersions': list(nodes.values()), 'ecmascriptExclusions': differences},
    'referenceUnitsClassificationSummaryByteIdentical': True, 'summary': summary,
    'verificationCorrection': 'Initial helper incorrectly required byte equality of Node profile and ECMAScript host exclusions; source contract records these host differences. No product or budget changed; no product commands rerun.'}
(root / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({key: value for key, value in receipt.items() if key != 'summary'}, indent=2))
