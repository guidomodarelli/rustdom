import hashlib, json, pathlib, shutil, tarfile, tempfile

repo = pathlib.Path('/mnt/c/Users/guido/.codex/worktrees/migration-inventory/rustdom')
output = repo / 'reports/validation/inventory-geometry-ledger'
root = pathlib.Path((repo / '.cache/geometry-local-root.txt').read_text().strip())
receipt = json.loads((root / 'receipt.json').read_bytes())
assert receipt['allProductCommandsPassed']
bundle = pathlib.Path(tempfile.mkdtemp(prefix='rustdom-geometry-evidence-'))
shutil.copytree(root, bundle / 'linux-local', ignore=shutil.ignore_patterns('node_modules'))
shutil.copytree(pathlib.Path('/tmp/rustdom-geometry-ledger-bjpsalr2'), bundle / 'history/missing-package-input',
    ignore=shutil.ignore_patterns('node_modules'))
windows = bundle / 'windows'; windows.mkdir()
for path in (repo / '.cache/geometry-windows-validation').glob('*.log'):
    shutil.copyfile(path, windows / path.name)
(windows / 'execution.json').write_text(json.dumps({'toolSession': 90056, 'exitCode': 0,
    'commands': [
        ['C:/Users/guido/ghq/projects/rustdom/.tools/node-win/node-v22.12.0-win-x64/node.exe', '--test', 'tests/validation/migration-inventory.spec.mjs'],
        ['C:/Users/guido/ghq/projects/rustdom/.tools/node-win/node-v24.22.1-win-x64/node.exe', '--test', 'tests/validation/migration-inventory.spec.mjs']],
    'contractsPassedPerNode': 12, 'processPidsNotRecorded': True}, indent=2) + '\n')
for label in ['node-22', 'node-24']:
    raw = (windows / f'{label}.stdout.log').read_text()
    prefix = '# ' if label == 'node-22' else 'ℹ '
    assert prefix + 'pass 12' in raw and prefix + 'fail 0' in raw
history = bundle / 'history/mounted-filesystem'; history.mkdir(parents=True)
for path in output.iterdir():
    if path.is_file(): shutil.copyfile(path, history / path.name)
tools = bundle / 'tools'; tools.mkdir()
for name in ['validate-geometry-ledger.py', 'qualify-geometry-local.py', 'finalize-geometry-local.py', 'package-geometry-ledger.py']:
    shutil.copyfile(repo / '.cache' / name, tools / name)
(bundle / 'history/verification-correction.json').write_text(json.dumps({
    'firstFrozenSnapshot': 'Missing project package.json; generator exited1 before product tests. Added package.json and lockfile to next immutable snapshot.',
    'originalFinalComparison': 'All six product commands exited0; helper incorrectly required surface.json bytes to match across different Node profiles and ECMAScript exclusions.',
    'reporterCorrection': 'Offline receipt reader first assumed TAP for both Nodes; Node24 uses the spec reporter. Reader checks the actual summary format of each pinned version.',
    'correctedScope': 'All 4374 API records and other included declarations match; reference, implementation units, classification and summary match byte-for-byte. Node profile and four predeclared excluded ECMAScript globals remain preserved.',
    'productCodeOrTimeoutChanged': False, 'productCommandsRerunForReceiptCorrection': False}, indent=2) + '\n')
deps = pathlib.Path('/tmp/rustdom-runner-suites-ytu9q4xb/static-prepared/packages/B/node_modules')
expected = json.loads(pathlib.Path('/tmp/rustdom-pre-gc-method-exroua90/test-dependency-inventory.json').read_bytes())
for entry in expected['files']:
    raw = (deps.parent / entry['path']).read_bytes()
    assert len(raw) == entry['bytes'] and hashlib.sha256(raw).hexdigest() == entry['sha256'], entry['path']
shutil.copyfile('/tmp/rustdom-pre-gc-method-exroua90/test-dependency-inventory.json', bundle / 'dependencies.json')
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
entries = {path.relative_to(bundle).as_posix(): {'bytes': path.stat().st_size, 'sha256': digest(path)}
    for path in sorted(bundle.rglob('*')) if path.is_file()}
(output / 'raw-files.json').write_text(json.dumps(entries, indent=2) + '\n')
archive = output / 'qualification.tar.gz'
with tarfile.open(archive, 'w:gz') as stream: stream.add(bundle, arcname='geometry-ledger')
actual = {}
with tarfile.open(archive) as stream:
    for member in stream:
        if member.isfile(): actual[member.name.removeprefix('geometry-ledger/')] = {
            'bytes': member.size, 'sha256': hashlib.sha256(stream.extractfile(member).read()).hexdigest()}
assert actual == entries
memory_directory = repo / 'reports/memory/inventory-geometry-ledger'
memory_directory.mkdir(parents=True, exist_ok=False)
for label in ['node-22', 'node-24']:
    shutil.copyfile(root / f'{label}-memory.stdout.log', memory_directory / f'{label}.json')
summary = {**receipt, 'windowsNodeVersions': ['v22.12.0', 'v24.22.1'], 'windowsTestsPerNode': 12,
    'previousAudits': 42, 'newAudits': 42, 'allCatalogIDsStable': 12151,
    'dependencyFilesMatchedHistoricalFrozenTree': len(expected['files']),
    'archiveSha256': digest(archive), 'archiveBytes': archive.stat().st_size,
    'rawFiles': len(entries), 'archiveReadbackMatched': True, 'nativeAddonExecutedForThisAudit': False,
    'historicalMountedFilesystemFailurePreserved': True}
(output / 'receipt.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({key: value for key, value in summary.items() if key not in ['summary', 'hostDifferencesPreserved']}, indent=2))
