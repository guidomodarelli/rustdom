import hashlib, json, pathlib, shutil, subprocess, tempfile, time

repo = pathlib.Path('/mnt/c/Users/guido/.codex/worktrees/migration-inventory/rustdom')
root = pathlib.Path(tempfile.mkdtemp(prefix='rustdom-geometry-ledger-'))
snapshot = root / 'repository'
snapshot.mkdir()
deps = pathlib.Path('/tmp/rustdom-runner-suites-ytu9q4xb/static-prepared/packages/B/node_modules')
audits = json.loads((repo / 'reports/progress/inventory/audits.json').read_bytes())
paths = {'package.json', 'package-lock.json', 'scripts/migration-inventory.cjs', 'scripts/constants/migration-inventory.cjs',
    'scripts/memory-endpoint.cjs', 'tests/validation/migration-inventory.spec.mjs',
    'tests/helpers/inventory-memory.cjs', 'reports/progress/inventory/audits.json'}
paths.update(path.relative_to(repo).as_posix() for path in (repo / 'scripts/migration-inventory').rglob('*.cjs'))
for audit in audits.values():
    for field in ['rustSources', 'javascriptSources', 'tests', 'evidence']:
        paths.update(audit[field])
sources = {}
for relative in sorted(paths):
    raw = (repo / relative).read_bytes()
    target = snapshot / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    sources[relative] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
for name in ['jsdom', 'typescript']:
    assert (deps / name / 'package.json').read_bytes() == (repo / 'node_modules' / name / 'package.json').read_bytes()
(snapshot / 'node_modules').symlink_to(deps, target_is_directory=True)
(root / 'sources.json').write_text(json.dumps(sources, indent=2) + '\n')
(root / 'dependencies.json').write_text(json.dumps({'nodeModules': str(deps),
    'reusedReadOnly': True, 'jsdomVersion': json.loads((deps / 'jsdom/package.json').read_bytes())['version'],
    'typescriptVersion': json.loads((deps / 'typescript/package.json').read_bytes())['version']}, indent=2) + '\n')
(repo / '.cache/geometry-local-root.txt').write_text(str(root) + '\n')
print(f'ROOT {root}', flush=True)
nodes = {'node-22': '/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node-22/bin/node',
         'node-24': '/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node/bin/node'}
for label, node in nodes.items():
    for operation, arguments in [
        ('generator', ['scripts/migration-inventory.cjs', '--output', str(root / f'{label}-catalog')]),
        ('contracts', ['--test', 'tests/validation/migration-inventory.spec.mjs']),
        ('memory', ['--expose-gc', 'tests/helpers/inventory-memory.cjs']),
    ]:
        name = f'{label}-{operation}'
        command = [node, *arguments]
        record = {'command': command, 'cwd': str(snapshot), 'startedAt': time.time()}
        with (root / f'{name}.stdout.log').open('xb') as stdout, (root / f'{name}.stderr.log').open('xb') as stderr:
            child = subprocess.Popen(command, cwd=snapshot, stdout=stdout, stderr=stderr)
            record['pid'] = child.pid
            (root / f'{name}.process.json').write_text(json.dumps(record, indent=2) + '\n')
            print(f'START {name} pid={child.pid}', flush=True)
            record['exitCode'] = child.wait()
        record['finishedAt'] = time.time()
        (root / f'{name}.process.json').write_text(json.dumps(record, indent=2) + '\n')
        print(f'END {name} exit={record["exitCode"]}', flush=True)
        if record['exitCode'] != 0:
            raise SystemExit(record['exitCode'])
for name in ['reference.json', 'surface.json', 'implementation-units.json', 'classification.json', 'summary.json']:
    raw = (repo / 'reports/progress/inventory' / name).read_bytes()
    for label in nodes:
        assert (root / f'{label}-catalog' / name).read_bytes() == raw, (label, name)
for relative, metadata in sources.items():
    assert hashlib.sha256((snapshot / relative).read_bytes()).hexdigest() == metadata['sha256']
summary = json.loads((root / 'node-24-catalog/summary.json').read_bytes())
assert [summary['counts'][kind]['total'] for kind in ['files', 'apis', 'callableUnits']] == [531, 4374, 7246]
assert [summary['counts'][kind]['audited'] for kind in ['files', 'apis', 'callableUnits']] == [16, 23, 45]
assert summary['scopeClosed'] is False and summary['migrationPercent'] is None
(root / 'receipt.json').write_text(json.dumps({'allPassed': True, 'sources': len(sources),
    'catalogByteIdenticalToWorktreeAndAcrossNodes': True, 'summary': summary,
    'cliTimeoutMsUnchanged': 30000, 'productionChanged': False}, indent=2) + '\n')
print('COMPLETE: Linux local filesystem, both Nodes passed; catalog byte-identical', flush=True)
