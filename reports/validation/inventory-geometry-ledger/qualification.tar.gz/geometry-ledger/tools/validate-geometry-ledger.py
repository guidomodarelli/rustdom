import hashlib, json, os, pathlib, subprocess, time

repo = pathlib.Path('/mnt/c/Users/guido/.codex/worktrees/migration-inventory/rustdom')
output = repo / 'reports/validation/inventory-geometry-ledger'
output.mkdir(parents=True, exist_ok=True)
assert not list(output.glob('*.process.json')), 'Do not overwrite a previous qualification'
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
catalog = repo / 'reports/progress/inventory'
fixed = ['reference.json', 'surface.json', 'implementation-units.json']
before = {name: digest(catalog / name) for name in fixed}
windows_repo = subprocess.check_output(['wslpath', '-w', str(repo)], text=True).strip()
audits_before = json.loads(subprocess.check_output(['git.exe', '-C', windows_repo, 'show', 'HEAD:reports/progress/inventory/audits.json']))
audits_after = json.loads((catalog / 'audits.json').read_bytes())
assert all(audits_after[key] == value for key, value in audits_before.items())
assert len(set(audits_after) - set(audits_before)) == 42
nodes = {'node-22': '/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node-22/bin/node',
         'node-24': '/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node/bin/node'}
commands = []
for label, node in nodes.items():
    arguments = ['scripts/migration-inventory.cjs']
    if label == 'node-24':
        arguments += ['--output', str(output / 'node-24-catalog')]
    commands += [(f'{label}-generator', node, arguments),
                 (f'{label}-contracts', node, ['--test', 'tests/validation/migration-inventory.spec.mjs']),
                 (f'{label}-memory', node, ['--expose-gc', 'tests/helpers/inventory-memory.cjs'])]
for label, node, arguments in commands:
    command = [node, *arguments]
    record = {'command': command, 'cwd': str(repo), 'startedAt': time.time()}
    with (output / f'{label}.stdout.log').open('xb') as stdout, (output / f'{label}.stderr.log').open('xb') as stderr:
        child = subprocess.Popen(command, cwd=repo, stdout=stdout, stderr=stderr)
        record['pid'] = child.pid
        (output / f'{label}.process.json').write_text(json.dumps(record, indent=2) + '\n')
        print(f'START {label} pid={child.pid}', flush=True)
        record['exitCode'] = child.wait()
    record['finishedAt'] = time.time()
    (output / f'{label}.process.json').write_text(json.dumps(record, indent=2) + '\n')
    print(f'END {label} exit={record["exitCode"]}', flush=True)
    if record['exitCode'] != 0:
        raise SystemExit(record['exitCode'])
assert {name: digest(catalog / name) for name in fixed} == before
generated = ['reference.json', 'surface.json', 'implementation-units.json', 'classification.json', 'summary.json']
for name in generated:
    assert (catalog / name).read_bytes() == (output / 'node-24-catalog' / name).read_bytes(), name
summary = json.loads((catalog / 'summary.json').read_bytes())
assert summary['scopeClosed'] is False and summary['migrationPercent'] is None
assert [summary['counts'][kind]['total'] for kind in ['files', 'apis', 'callableUnits']] == [531, 4374, 7246]
assert [summary['counts'][kind]['audited'] for kind in ['files', 'apis', 'callableUnits']] == [16, 23, 45]
receipt = {'allPassed': True, 'newAuthoredAudits': 42, 'previousAuditsUnchanged': True,
    'referenceDigestsUnchanged': before, 'catalogByteIdenticalAcrossNodes': True,
    'summary': summary, 'outputs': {name: digest(catalog / name) for name in generated}}
(output / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('COMPLETE: catalog stable, both Nodes passed', flush=True)
