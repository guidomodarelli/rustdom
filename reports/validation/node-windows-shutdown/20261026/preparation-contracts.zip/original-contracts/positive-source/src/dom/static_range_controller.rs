//! StaticRange construction decisions with scoped host references and numeric native ownership.
use super::{
    constants::{
        ATTRIBUTE_NODE, DOCUMENT_TYPE_NODE, STATIC_RANGE_INVALID_NODE_MESSAGE,
        STATIC_RANGE_OPERATION_FAILURE, STATIC_RANGE_OWNER_IDS_MESSAGE,
    },
    napi_error::capture_pending_error,
    range_state::RangeState,
    range_state_binding::NativeRange,
};
use napi::{
    Env, Error, JsValue, Result, Status, ValueType,
    bindgen_prelude::{Array, FnArgs, Function, JsObjectValue, Unknown},
};
use napi_derive::napi;

enum OwnerResolution {
    Individual,
    Paired,
}

fn has_kind(node: Unknown<'_>, kind: u16) -> Result<bool> {
    let value: Unknown = node.coerce_to_object()?.get_c_named_property(c"nodeType")?;
    // Strict equality does not coerce strings, objects, bigint or other host values.
    Ok(value.get_type()? == ValueType::Number
        && value.coerce_to_number()?.get_double()? == f64::from(kind))
}

fn invalid_node(node: Unknown<'_>) -> Result<bool> {
    // Match the reference's repeated property reads and short-circuit ordering.
    Ok(has_kind(node, DOCUMENT_TYPE_NODE)? || has_kind(node, ATTRIBUTE_NODE)?)
}

fn invalid_owner_ids() -> Error {
    Error::new(Status::InvalidArg, STATIC_RANGE_OWNER_IDS_MESSAGE)
}

fn construct<'env>(
    global: Unknown<'env>,
    start_node: Unknown<'env>,
    start_offset: f64,
    end_node: Unknown<'env>,
    end_offset: f64,
    helpers: Unknown<'env>,
    resolution: OwnerResolution,
) -> Result<NativeRange> {
    let host = helpers.coerce_to_object()?;
    if invalid_node(start_node)? || invalid_node(end_node)? {
        let reject: Function<FnArgs<(Unknown, String, String)>, Unknown> =
            host.get_c_named_property(c"exception")?;
        let exception = reject.apply(
            helpers,
            (
                global,
                STATIC_RANGE_INVALID_NODE_MESSAGE.to_owned(),
                "InvalidNodeTypeError".to_owned(),
            )
                .into(),
        )?;
        return Err(Error::from_unknown_without_coercion(exception));
    }
    // No TreeStore borrow or native box exists while host callbacks or array getters run.
    let (start, end) = match resolution {
        OwnerResolution::Individual => {
            let identify: Function<Unknown, f64> = host.get_c_named_property(c"nodeId")?;
            let start = identify.apply(helpers, start_node)?;
            let end = identify.apply(helpers, end_node)?;
            (start, end)
        }
        OwnerResolution::Paired => {
            let identify: Function<FnArgs<(Unknown, Unknown)>, Array> =
                host.get_c_named_property(c"nodeIds")?;
            let owners = identify.apply(helpers, (start_node, end_node).into())?;
            if owners.len() != 2 {
                return Err(invalid_owner_ids());
            }
            let start = owners.get::<f64>(0)?.ok_or_else(invalid_owner_ids)?;
            let end = owners.get::<f64>(1)?.ok_or_else(invalid_owner_ids)?;
            (start, end)
        }
    };
    let state = RangeState::from_endpoints(start, start_offset, end, end_offset)
        .map_err(super::napi_error::to_napi_error)?;
    Ok(NativeRange::with_state(state))
}

fn finish(env: &Env, result: Result<NativeRange>) -> Result<NativeRange> {
    match result {
        Ok(state) => Ok(state),
        Err(error) => {
            // Preserve the original thrown value, including errors from a reentrant host.
            env.throw(capture_pending_error(env, error))?;
            Err(Error::new(
                Status::PendingException,
                STATIC_RANGE_OPERATION_FAILURE,
            ))
        }
    }
}

/// Preserve the original native constructor contract with individual owner callbacks.
#[napi]
pub fn initialize_static_range<'env>(
    env: &'env Env,
    global: Unknown<'env>,
    start_node: Unknown<'env>,
    start_offset: f64,
    end_node: Unknown<'env>,
    end_offset: f64,
    helpers: Unknown<'env>,
) -> Result<NativeRange> {
    finish(
        env,
        construct(
            global,
            start_node,
            start_offset,
            end_node,
            end_offset,
            helpers,
            OwnerResolution::Individual,
        ),
    )
}

/// Resolve both numeric owners in one host callback after all DOM node validation.
#[napi]
pub fn initialize_static_range_with_owners<'env>(
    env: &'env Env,
    global: Unknown<'env>,
    start_node: Unknown<'env>,
    start_offset: f64,
    end_node: Unknown<'env>,
    end_offset: f64,
    helpers: Unknown<'env>,
) -> Result<NativeRange> {
    finish(
        env,
        construct(
            global,
            start_node,
            start_offset,
            end_node,
            end_offset,
            helpers,
            OwnerResolution::Paired,
        ),
    )
}
