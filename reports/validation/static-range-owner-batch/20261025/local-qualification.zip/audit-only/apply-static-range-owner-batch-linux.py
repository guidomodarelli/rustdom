import json
from pathlib import Path
current=Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom');source=Path('/home/guido/rustdom-validation/static-range-owner-batch-work/source')
assert (source/'.git').is_dir()
controller=(current/'.cache/static-range-owner-batch-controller.rs').read_text(encoding='utf-8-sig');(source/'src/dom/static_range_controller.rs').write_text(controller,encoding='utf-8')
filename=source/'src/dom/constants.rs';content=filename.read_text();marker='pub const STATIC_RANGE_OPERATION_FAILURE: &str = "StaticRange native construction failed";';assert marker in content;content=content.replace(marker,marker+'\n/// Invalid private owner-pair adapter result.\npub const STATIC_RANGE_OWNER_IDS_MESSAGE: &str = "StaticRange owner resolver must return exactly two numeric node IDs";');filename.write_text(content)
filename=source/'src/dom/static-range.cjs';content=filename.read_text();content=content.replace('initializeStaticRange','initializeStaticRangeWithOwners').replace('nodeId(node) { return tree._ensure(node); }','nodeIds(startNode, endNode) { return [tree._ensure(startNode), tree._ensure(endNode)]; }');filename.write_text(content)
filename=source/'src/native.mjs';content=filename.read_text();assert content.count('initializeStaticRange,')==1;filename.write_text(content.replace('initializeStaticRange,','initializeStaticRange, initializeStaticRangeWithOwners,'))
filename=source/'types/native.d.ts';content=filename.read_text();marker='export function initializeStaticRange(globalObject: object, startNode: object, startOffset: number,';assert marker in content
start=content.index(marker);end=content.index(';',start)+1;declaration=content[start:end].replace('initializeStaticRange(', 'initializeStaticRangeWithOwners(')
content=content[:end]+'\n/** Construct native StaticRange after validating nodes and resolving both owners in one callback. */\n'+declaration+content[end:];filename.write_text(content)
print(json.dumps({'source':str(source),'changed':'candidate-only','newEntryPoint':'initializeStaticRangeWithOwners','measurementsExecuted':False}))
