import hashlib,json,os,subprocess,types
from pathlib import Path
current=Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom');source=Path('/dev/shm/rustdom-static-range-owner-batch/source');root=source.parent;packet=current/'reports/implementation/static-range-owner-batch-candidate'
(source/'tests/consumers/owner-batch.mts').write_bytes((packet/'consumer.mts').read_bytes())
module=types.ModuleType('owner_pair_extra_commands');filename=current/'reports/implementation/range-combined-candidate/tools/command.py';module.__file__=str(filename);exec(compile(filename.read_bytes(),str(filename),'exec'),module.__dict__)
proof=root/'extra-consumers';assert not proof.exists();proof.mkdir();receipt={'commands':[],'benchmarkExecuted':False,'performanceAccepted':None}
for major,directory in [('24','node'),('22','node-22')]:
 node=Path('/mnt/c/Users/guido/ghq/projects/rustdom/.tools')/directory/'bin/node';logs=proof/('node'+major);logs.mkdir();environment=dict(os.environ,PATH=str(node.parent)+os.pathsep+os.environ['PATH'],TMPDIR=str(root/'tmp'),RUSTDOM_STATIC_RANGE_SOURCE=str(source));output=source/'.cache'/('owner-pair-extra-consumers-'+major)
 commands=[('compile',[node,source/'node_modules/typescript/bin/tsc','--strict','--module','NodeNext','--target','ES2022','--esModuleInterop','--skipLibCheck','false','--types','node','--rootDir',source,'--outDir',output,source/'tests/consumers/owner-batch.cts',source/'tests/consumers/owner-batch.mts'])]
 commands.extend((extension,[node,output/'tests/consumers'/('owner-batch.'+extension)]) for extension in ['cjs','mjs'])
 for label,argv in commands:
  result=module.run_command(label,argv,source,environment,logs,120,30);receipt['commands'].append({'node':major,**result});(proof/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8');assert result['exitCode']==0 and not result['timedOut'],label
print(json.dumps({'SDKs':2,'typedRealConsumers':4,'commandsPassed':len(receipt['commands']),'benchmarkExecuted':False}),flush=True)
