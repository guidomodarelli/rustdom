"""Prepare a new real Git source in project-scoped RAM; never modify prior source checkouts or archived packages."""
import hashlib,json,subprocess
from pathlib import Path
current=Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom');root=Path('/home/guido/rustdom-validation/static-range-owner-batch-work');source=root/'source';baseline=Path('/home/guido/rustdom-validation/combined-process-source-95e64bd2')
assert not source.exists() and root.is_dir()
subprocess.run(['git','clone','--shared','--no-checkout',str(baseline),str(source)],check=True)
subprocess.run(['git','sparse-checkout','init','--no-cone'],cwd=source,check=True)
patterns=['/*','!/*/','/src/','/scripts/','/benchmarks/','/tests/','/types/','/third-party/','/reports/validation/native-class-ownership/ci-macos-timeout/fixture.json.gz','/reports/validation/native-class-ownership/ci-macos-timeout/39686199408/fixture.json.gz','/reports/validation/native-class-ownership/ci-windows-timeout/39894045206/comparison.json.gz']
subprocess.run(['git','sparse-checkout','set','--no-cone','--stdin'],input='\n'.join(patterns)+'\n',text=True,cwd=source,check=True)
subprocess.run(['git','checkout','--detach','f781c3b7549a86b6aa8b5a34d2bbb32038c315b7'],cwd=source,check=True)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source)
prepare=current/'reports/implementation/range-combined-candidate/tools/prepare.py'
subprocess.run(['python3','-B',str(prepare),str(current),str(source),str(root/'combined-source-proof')],check=True,stdout=(root/'prepare.stdout.log').open('xb'),stderr=(root/'prepare.stderr.log').open('xb'))
print(json.dumps({'source':str(source),'realGit':(source/'.git').is_dir(),'baseCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),'preparedOriginalCandidate':True,'performanceAccepted':None,'measurementExecuted':False}),flush=True)
