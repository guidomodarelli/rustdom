"""Qualify the isolated owner-pair candidate with real addons, independent jsdom, consumers and resource probes; never accepts performance."""
import hashlib,json,os,subprocess,types
from pathlib import Path
current=Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom');source=Path('/dev/shm/rustdom-static-range-owner-batch/source');root=source.parent;packet=current/'reports/implementation/static-range-owner-batch-candidate'
assert (root/'build-final.exit-code').read_text().strip()=='0'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()=='f781c3b7549a86b6aa8b5a34d2bbb32038c315b7'
command_file=current/'reports/implementation/range-combined-candidate/tools/command.py';module=types.ModuleType('current_functional_command');module.__file__=str(command_file);exec(compile(command_file.read_bytes(),str(command_file),'exec'),module.__dict__)
proof=root/'qualification';assert not proof.exists();proof.mkdir()
(source/'tests/consumers/owner-batch.cts').write_bytes((packet/'consumer.cts').read_bytes())
policy=json.loads((current/'reports/implementation/range-combined-candidate/tools/constants/qualification.json').read_bytes())
receipt={'revision':'static-range-owner-batch-functional-v1','sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),'sourceChangesRaw':subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=source,text=True),'executionSource':str(source),'commandReaderSha256':hashlib.sha256(command_file.read_bytes()).hexdigest(),'qualified':False,'runtimeIntegrated':False,'benchmarkExecuted':False,'performanceAccepted':None,'gateReevaluated':False,'SDKs':[]}
for major,node_name,version,checksum in [('24','node','v24.14.1','bf9112eb83a827dc9f9c8d19bb7bddcbf00f7b2fedae18fdcaee05406981f20a'),('22','node-22','v22.12.0','177208bfc4a9403121a40c72d038c670f4fd937fa16ca7df0a720e90be0fe2d9')]:
 node=Path('/mnt/c/Users/guido/ghq/projects/rustdom/.tools')/node_name/'bin/node';assert hashlib.sha256(node.read_bytes()).hexdigest()==checksum
 assert subprocess.check_output([str(node),'--version'],text=True).strip()==version
 logs=proof/('node'+major);logs.mkdir();environment=dict(os.environ,PATH=str(node.parent)+os.pathsep+os.environ['PATH'],TMPDIR=str(root/'tmp'),npm_config_cache=str(root/'npm-cache'),RUSTDOM_STATIC_RANGE_SOURCE=str(source),RUSTDOM_COMBINED_SOURCE=str(source),RUSTDOM_RANGE_PREPARATION_SOURCE=str(source))
 sdk={'node':version,'executableSha256':checksum,'commands':[]};receipt['SDKs'].append(sdk)
 def run(label,argv):
  result=module.run_command(label,argv,source,environment,logs,policy['commandTimeoutSeconds'],policy['cleanupTimeoutSeconds']);sdk['commands'].append(result)
  (proof/'qualification.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
  print(json.dumps({'node':version,'label':label,'exitCode':result['exitCode'],'seconds':result['seconds']}),flush=True)
  assert result['exitCode']==0 and not result['timedOut'],label
 run('owner-pair-contracts',[node,'--expose-gc','--test','--test-concurrency=1',packet/'contract.spec.cjs'])
 run('directed',[node,*policy['nodeArguments'],*sorted((source/'tests').glob('range-*.spec.cjs')),source/'tests/combined-range-candidate.spec.cjs',current/policy['publicTests']])
 consumers=source/'.cache'/('owner-batch-consumers-node'+major)
 run('compile-consumers',[node,source/'node_modules/typescript/bin/tsc','--strict','--module','NodeNext','--target','ES2022','--esModuleInterop','--skipLibCheck','false','--types','node','--rootDir',source,'--outDir',consumers,*[source/name for name in policy['consumerInputs']],source/'tests/consumers/owner-batch.cts'])
 for name in ['consumer.cjs','consumer.mjs','owner-batch.cjs']:run('consumer-'+name,[node,consumers/'tests/consumers'/name])
 for suite in policy['suites']:run(suite.replace(':','-'),[node,node.parent/'../lib/node_modules/npm/bin/npm-cli.js','run',suite])
 run('static-memory',[node,'--expose-gc',current/policy['staticMemory']])
 run('collapse-memory',[node,'--expose-gc',source/policy['collapseMemory']])
receipt['qualified']=True;receipt['nativeBuild']=json.loads((source/'dist/native-build.json').read_bytes());receipt['sourceAfterChangesRaw']=subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=source,text=True)
(proof/'qualification.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'qualified':True,'SDKs':len(receipt['SDKs']),'performanceAccepted':None,'gateReevaluated':False}),flush=True)
