from pathlib import Path
filename=Path('/dev/shm/rustdom-static-range-owner-batch/source/src/dom/static_range_controller.rs')
source=filename.read_text();start=source.index("fn initialize<'env>(");end=source.index('/// Preserve the original',start)
source=source[:start]+'''fn finish(env: &Env, result: Result<NativeRange>) -> Result<NativeRange> {
    match result {
        Ok(state) => Ok(state),
        Err(error) => {
            // Preserve the original thrown value, including errors from a reentrant host.
            env.throw(capture_pending_error(env, error))?;
            Err(Error::new(
                Status::PendingException,
                STATIC_RANGE_OPERATION_FAILURE,
            ))
        }
    }
}

'''+source[end:]
for variant in ['Individual','Paired']:
 before='''    initialize(
        env,
        global,
        start_node,
        start_offset,
        end_node,
        end_offset,
        helpers,
        OwnerResolution::'''+variant+''',
    )'''
 after='''    finish(env, construct(
        global,
        start_node,
        start_offset,
        end_node,
        end_offset,
        helpers,
        OwnerResolution::'''+variant+''',
    ))'''
 assert before in source;source=source.replace(before,after)
filename.write_text(source)
