from pathlib import Path
source=Path('/home/guido/rustdom-validation/static-range-owner-batch-work/source')
filename=source/'types/native.d.cts';content=filename.read_text();marker='  }): NativeRange;\nexport class NativeRange {';assert marker in content
addition='''  }): NativeRange;
/** Construct native StaticRange after Rust validates nodes and resolves both owners in one callback. */
export function initializeStaticRangeWithOwners(globalObject: object, startNode: object, startOffset: number,
  endNode: object, endOffset: number, helpers: {
    nodeIds(startNode: object, endNode: object): [number, number];
    exception(globalObject: object, message: string, name: string): unknown;
  }): NativeRange;
export class NativeRange {'''
filename.write_text(content.replace(marker,addition))
