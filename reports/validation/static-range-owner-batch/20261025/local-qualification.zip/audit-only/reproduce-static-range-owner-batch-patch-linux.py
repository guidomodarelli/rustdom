import hashlib,json,subprocess
from pathlib import Path
current=Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom');packet=current/'reports/implementation/static-range-owner-batch-candidate';root=Path('/dev/shm/rustdom-static-range-owner-batch');source=root/'patch-reproduction';assert not source.exists()
manifest=json.loads((packet/'source.json').read_bytes());subprocess.run(['git','clone','--shared','--no-checkout','/home/guido/rustdom-validation/combined-process-source-95e64bd2',str(source)],check=True,capture_output=True)
subprocess.run(['git','sparse-checkout','init','--no-cone'],cwd=source,check=True,capture_output=True)
patterns=['/*','!/*/']+['/'+name for name in manifest['sources']]
subprocess.run(['git','sparse-checkout','set','--no-cone','--stdin'],input='\n'.join(patterns)+'\n',text=True,cwd=source,check=True,capture_output=True)
subprocess.run(['git','checkout','--detach',manifest['baseCommit']],cwd=source,check=True,capture_output=True)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source)
for name,expected in manifest['sourceBefore'].items():
 path=source/name
 if expected is None:assert not path.exists()
 else:assert hashlib.sha256(path.read_bytes()).hexdigest()==expected,name
for arguments in [['apply','--check',str(packet/'range-combined.patch')],['apply',str(packet/'range-combined.patch')]]:subprocess.run(['git',*arguments],cwd=source,check=True,capture_output=True)
for name,expected in manifest['sources'].items():assert hashlib.sha256((source/name).read_bytes()).hexdigest()==expected,name
record={'baseCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),'sourceChangesRaw':subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=source,text=True),'sourceGitErrors':[],'sourceFiles':manifest['sources'],'patchSha256':hashlib.sha256((packet/'range-combined.patch').read_bytes()).hexdigest(),'sourcesReproducedExactly':True,'compiledBinaryClaimedIdentical':False,'measurementExecuted':False}
(root/'patch-reproduction.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'realGit':True,'sourceFilesReproducedExactly':len(manifest['sources']),'measurementExecuted':False}))
