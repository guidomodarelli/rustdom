import json,shutil,subprocess
from pathlib import Path
original=Path('/home/guido/rustdom-validation/static-range-owner-batch-work');root=Path('/dev/shm/rustdom-static-range-owner-batch');assert not root.exists();root.mkdir()
assert root.stat().st_dev==Path('/dev/shm').stat().st_dev and root.stat().st_dev!=original.stat().st_dev
shutil.copytree(original/'source',root/'source',copy_function=shutil.copy2)
shutil.copytree(original/'target',root/'target',copy_function=shutil.copy2)
(root/'initial-build-location.json').write_text(json.dumps({'initialRoot':str(original),'initialBuildExitCode':143,'reason':'Custom mount was not persistent between WSL invocations; source and target copied to the existing shared tmpfs before continuing','measurementExecuted':False},indent=2)+'\n')
print(json.dumps({'ramRoot':str(root),'filesystem':subprocess.check_output(['findmnt','-no','FSTYPE','-T',str(root)],text=True).strip(),'realGit':(root/'source/.git').is_dir()}))
