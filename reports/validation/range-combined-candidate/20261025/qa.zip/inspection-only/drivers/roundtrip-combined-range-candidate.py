import gzip,hashlib,json,subprocess
from pathlib import Path
repository=Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom')
root=Path('/home/guido/rustdom-validation/range-combined-candidate-20261025-f781')
packet=repository/'reports/implementation/range-combined-candidate'
policy=json.loads((packet/'source.json').read_bytes())
roundtrip=root/'roundtrip'
assert not roundtrip.exists()
subprocess.run(['git','clone','--shared','--no-checkout',str(root/'source'),str(roundtrip)],check=True)
subprocess.run(['git','config','core.autocrlf','false'],cwd=roundtrip,check=True)
subprocess.run(['git','sparse-checkout','set','--no-cone','/*','!/*/','/src/','/scripts/','/types/'],cwd=roundtrip,check=True)
subprocess.run(['git','checkout','--detach',policy['baseCommit']],cwd=roundtrip,check=True)
assert (roundtrip/'.git').is_dir() and not subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=roundtrip)
for name,expected in policy['sourceBefore'].items():
    observed=hashlib.sha256((roundtrip/name).read_bytes()).hexdigest() if (roundtrip/name).exists() else None
    assert observed==expected,name
patch=packet/'range-combined.patch';assert hashlib.sha256(patch.read_bytes()).hexdigest()==policy['patchSha256']
for argv in [['git','apply','--check',str(patch)],['git','apply',str(patch)]]:
    subprocess.run(argv,cwd=roundtrip,check=True,capture_output=True)
for name,expected in policy['sources'].items():assert hashlib.sha256((roundtrip/name).read_bytes()).hexdigest()==expected,name
proof={'baseCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=roundtrip,text=True).strip(),'sourceChangesRaw':subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=roundtrip,text=True),'filesIdenticalToCompiledCandidate':len(policy['sources']),'patchSha256':policy['patchSha256'],'DOMExecuted':False,'benchmarkExecuted':False,'performanceAccepted':None}
(root/'roundtrip.json').write_text(json.dumps(proof,indent=2)+'\n')
evidence=repository/'reports/validation/range-combined-candidate/20261025';evidence.mkdir(parents=True)
binary=(root/'source/dist/rustdom.node').read_bytes();assert hashlib.sha256(binary).hexdigest()==policy['nativeBinarySha256']
(evidence/'native-linux-x64.node.gz').write_bytes(gzip.compress(binary,compresslevel=9,mtime=0))
for name,source in [('native-build.json',root/'source/dist/native-build.json'),('build.json',root/'build.json'),('preparation.json',root/'preparation.json'),('roundtrip.json',root/'roundtrip.json')]:
    if source.exists():(evidence/name).write_bytes(source.read_bytes())
print(json.dumps({'patchRoundtripFiles':len(policy['sources']),'nativeBinarySha256':policy['nativeBinarySha256'],'nativeCompressedBytes':(evidence/'native-linux-x64.node.gz').stat().st_size,'DOMExecuted':False,'benchmarkExecuted':False}))
