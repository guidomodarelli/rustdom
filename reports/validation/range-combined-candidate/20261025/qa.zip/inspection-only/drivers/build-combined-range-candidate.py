"""Build and qualify a distinct combined Rust candidate; never replace historical prepared packages."""
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
if sys.flags.optimize:raise RuntimeError('Combined candidate qualification requires non-optimized Python')
root=Path('/home/guido/rustdom-validation/range-combined-candidate-20261025-f781')
source=root/'source';logs=root/'logs-build';logs.mkdir()
tools=Path('/mnt/c/Users/guido/ghq/projects/rustdom/.tools')
toolchain=Path('/home/guido/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin')
node=tools/'node/bin/node';npm=tools/'node/lib/node_modules/npm/bin/npm-cli.js'
assert (source/'.git').is_dir()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()=='f781c3b7549a86b6aa8b5a34d2bbb32038c315b7'
assert hashlib.sha256(node.read_bytes()).hexdigest()=='bf9112eb83a827dc9f9c8d19bb7bddcbf00f7b2fedae18fdcaee05406981f20a'
environment=dict(os.environ,PATH=str(node.parent)+os.pathsep+str(toolchain)+os.pathsep+os.environ.get('PATH',''),CARGO_HOME=str(tools/'cargo'),CARGO_TARGET_DIR=str(root/'target'),CARGO_INCREMENTAL='0',RUSTC=str(toolchain/'rustc'),RUSTDOC=str(toolchain/'rustdoc'),RUSTUP_TOOLCHAIN='1.99.1',CARGO_BUILD_JOBS='2')
record={'baseCommit':'f781c3b7549a86b6aa8b5a34d2bbb32038c315b7','runtimeIntegrated':False,'newCombinedCandidate':True,'performanceAccepted':None,'gateReevaluated':False,'benchmarkExecuted':False,'historicalPackagesModified':False,'commands':[]}
def run(label,argv,timeout=600):
    before=time.monotonic()
    with (logs/(label+'.stdout.log')).open('xb') as stdout,(logs/(label+'.stderr.log')).open('xb') as stderr:
        try:
            result=subprocess.run(list(map(str,argv)),cwd=source,env=environment,stdout=stdout,stderr=stderr,timeout=timeout)
            observed={'name':label,'argv':list(map(str,argv)),'exitCode':result.returncode,'timedOut':False,'seconds':time.monotonic()-before}
        except subprocess.TimeoutExpired:
            observed={'name':label,'argv':list(map(str,argv)),'exitCode':None,'timedOut':True,'seconds':time.monotonic()-before}
    record['commands'].append(observed)
    (root/'build.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(observed),flush=True)
    assert observed['exitCode']==0,label
run('node-version',[node,'--version'])
run('rustc-version',[toolchain/'rustc','-Vv'])
run('cargo-version',[toolchain/'cargo','--version'])
run('format-check',[toolchain/'cargo','fmt','--check'])
run('npm-ci',[node,npm,'ci','--no-audit','--no-fund'])
run('rust-tests',[toolchain/'cargo','test','--release','--locked','--offline','--lib'])
run('native-build',[node,'scripts/build-native.mjs'])
run('clippy',[toolchain/'cargo','clippy','--all-targets','--release','--locked','--offline','--','-D','warnings'])
run('js-build',[node,'scripts/build.mjs'])
record['nativeBinarySha256']=hashlib.sha256((source/'dist/rustdom.node').read_bytes()).hexdigest()
record['sourceChangesRaw']=subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=source,text=True)
record['nodeSha256']=hashlib.sha256(node.read_bytes()).hexdigest()
record['buildComplete']=True
(root/'build.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'buildComplete':True,'nativeBinarySha256':record['nativeBinarySha256'],'benchmarkExecuted':False}),flush=True)
