from pathlib import Path
import json,shutil,subprocess
file=Path('.cache/prepare-combined-range-candidate.py')
shutil.copyfile(file,'.cache/prepare-combined-range-candidate-first-preflight.py')
text=file.read_text(encoding='utf-8-sig')
old="subprocess.check_output(['git','rev-parse','HEAD'],cwd=repository,text=True).strip()==head"
new="subprocess.check_output(['git','--git-dir',str(common),'rev-parse','refs/heads/feature/native-class-ownership'],text=True).strip()==head"
assert text.count(old)==1
file.write_text(text.replace(old,new),encoding='utf-8',newline='\n')
Path('.cache/combined-range-candidate-first-preflight.json').write_text(json.dumps({'exitCode':1,'operation':'WSL Git preflight in Windows gitfile worktree','failure':'fatal: not a git repository; Windows gitfile path cannot be consumed by Git WSL','sourceCheckoutCreated':False,'sourceChangesNormalized':False,'fix':'Read exact branch from the actual common Git directory, then use Git only inside the new genuine Linux checkout.'},indent=2)+'\n',encoding='utf-8')
command=['wsl','-d','Ubuntu-22.04','--','python3','-B','/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom/.cache/prepare-combined-range-candidate.py']
result=subprocess.run(command,capture_output=True)
Path('.cache/combined-range-candidate-prepare.stdout.log').write_bytes(result.stdout)
Path('.cache/combined-range-candidate-prepare.stderr.log').write_bytes(result.stderr)
print(result.stdout.decode(errors='replace'));print(result.stderr.decode(errors='replace'))
assert result.returncode==0
