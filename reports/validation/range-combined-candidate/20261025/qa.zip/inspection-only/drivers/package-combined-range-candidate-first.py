import gzip,hashlib,json,re,shutil,zipfile
from pathlib import Path
root=Path.cwd()
linux=Path('//wsl.localhost/Ubuntu-22.04/home/guido/rustdom-validation/range-combined-candidate-20261025-f781')
implementation=root/'reports/implementation/range-combined-candidate'
validation=root/'reports/validation/range-combined-candidate/20261025'
memory=root/'reports/memory/range-combined-candidate/20261025';memory.mkdir(parents=True)
policy=json.loads((implementation/'source.json').read_bytes())
summary={'baseCommit':policy['baseCommit'],'nativeBinarySha256':policy['nativeBinarySha256'],'runtimeIntegrated':False,'benchmarkExecuted':False,'performanceAccepted':None,'gateReevaluated':False,'rustTests':315,'formatPassed':True,'clippyPassed':True,'nodes':{},'primaryRuntimeChanged':False,'historicalPackagesModified':False,'methodFilesPreserved':599,'foreignEntriesPreserved':48,'candidateFunctionalCIPending':True,'sourceChangesNotNormalized':True}
for profile in ['node22','node24']:
    qa=linux/'qa'
    for mode in ['directed','types','memory','suites']:
        receipt=json.loads((qa/(profile+'-'+mode)/'receipt.json').read_bytes())
        assert all(command['exitCode']==0 and not command['timedOut'] for command in receipt['commands'])
        assert receipt['nativeBinarySha256']==policy['nativeBinarySha256']
    folder=qa/(profile+'-suites')
    wpt=json.loads(next((folder/'test-wpt-reports').rglob('*wpt.json')).read_bytes())
    assert wpt['pass'] is True and wpt['complete'] is False and len(wpt['results'])==240
    assert all(row['pass'] for row in wpt['results'])
    assertions=sum(len(row['actual']['tests']) for row in wpt['results'])
    failures=sum(test['status']!=0 for row in wpt['results'] for test in row['actual']['tests'])
    assert failures==sum(test['status']!=0 for row in wpt['results'] for test in row['expected']['tests'])
    corpus=json.loads((folder/'test-corpus-reports/validation/html5lib.json').read_bytes())
    counts={}
    for name in ['test-vitest','test-vm']:
        text='\n'.join((folder/(name+'.'+stream+'.log')).read_text(encoding='utf-8') for stream in ['stdout','stderr'])
        plain=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',text)
        match=re.search(r'Tests\s+(\d+) passed',plain)
        assert match,name
        counts[name]=int(match.group(1))
    probes={}
    for name in ['static-memory','collapse-memory']:
        source=qa/(profile+'-memory')/(name+'.stdout.log')
        value=json.loads(source.read_bytes());assert value['pass'] is True
        (memory/(profile+'-'+name+'.json')).write_bytes(source.read_bytes())
        final=value['cycles'][-1]['released']['state']
        probes[name]={'cycles':len(value['cycles']),'allReleasedReached':all(cycle['released']['reached'] for cycle in value['cycles']),'finalSurvivors':final['survivors'],'finalNativeRanges':final['nativeTree']['rangeStates'],'baselineConstructors':value['baseline']['napiClasses'],'finalConstructors':final['nativeTree']['napiClasses'],'scope':value.get('scope')}
    node_record=json.loads((qa/(profile+'-suites')/'receipt.json').read_bytes())
    summary['nodes'][profile]={'node':node_record['node'],'nodeSha256':node_record['nodeSha256'],'directed':84,'compatibilityCore':3784,'fixtureProcessContracts':9,'jest':22,'vitest':counts['test-vitest'],'vm':counts['test-vm'],'html':{key:corpus[key] for key in ['total','passed','excludedScriptOn','mismatches']},'wpt':{'fixtures':len(wpt['results']),'assertions':assertions,'sharedFailedAssertions':failures,'complete':wpt['complete'],'pass':wpt['pass'],'excludedFixtures':wpt['excludedFixtures'],'blockedSuites':wpt['blockedSuites'],'wptRevision':wpt['wptRevision'],'jsdom':wpt['jsdom'],'diagnosticNormalization':wpt['diagnosticNormalization']},'consumers':{'compilations':1,'actualCjsEsmExecutions':2},'resourceProbes':probes}
policy['testsPending']=False
policy['functionalValidationPassed']=True
policy['functionalCIPending']=True
policy['buildInputs']={name:hashlib.sha256((linux/'source'/name).read_bytes()).hexdigest() for name in ['Cargo.lock','Cargo.toml','package-lock.json','package.json','rust-toolchain.toml']}
(implementation/'source.json').write_text(json.dumps(policy,indent=2)+'\n',encoding='utf-8',newline='\n')
(validation/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
(validation/'.gitattributes').write_text('*.gz -text -whitespace\n*.zip -text -whitespace\n',encoding='utf-8',newline='\n')
# Preserve complete logs, generated reports, original compiled sources and read-only CI artifacts.
files={}
for directory in ['logs','logs-build','qa']:
    for file in sorted((linux/directory).rglob('*')):
        if file.is_file():files['candidate/'+file.relative_to(linux).as_posix()]=file
for name in ['preparation.json','prepare-commands.json','build.json','roundtrip.json','node24-preparation.json']:
    files['candidate/'+name]=linux/name
for name in policy['sources']:
    files['inspection-only/compiled-source/'+name]=linux/'source'/name
for name in ['Cargo.lock','Cargo.toml','package-lock.json','package.json','rust-toolchain.toml']:
    files['inspection-only/build-inputs/'+name]=linux/'source'/name
for name in ['prepare-combined-range-candidate.py','prepare-combined-range-candidate-first-preflight.py','run-combined-range-preparation.py','combined-range-candidate-first-preflight.json','combined-range-candidate-prepare.stdout.log','combined-range-candidate-prepare.stderr.log','build-combined-range-candidate.py','test-combined-range-candidate.py','test-combined-range-node24-suites.py','prepare-combined-range-node24.py','roundtrip-combined-range-candidate.py']:
    files['inspection-only/drivers/'+name]=root/'.cache'/name
for name in ['range-aa-result-ci-40160504234','range-aa-exploration-ci-40161044874']:
    folder=root/'.cache'/name
    for file in folder.rglob('*'):
        if file.is_file():files['read-only-ci/'+name+'/'+file.relative_to(folder).as_posix()]=file
manifest={name:{'bytes':file.stat().st_size,'sha256':hashlib.sha256(file.read_bytes()).hexdigest()} for name,file in files.items()}
archive=validation/'qa.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as output:
    for name,file in files.items():output.write(file,name)
    output.writestr('members.json',json.dumps(manifest,indent=2)+'\n')
    output.writestr('README.txt','Evidencia completa del candidato combinado. Los scripts archivados son solo inspeccion. Reproducir desde el Git base y el patch actual verificado, nunca ejecutar codigo archivado. No hay captura de rendimiento nueva.\n')
with zipfile.ZipFile(archive) as checked:
    assert checked.testzip() is None
    for name,expected in manifest.items():
        content=checked.read(name)
        assert len(content)==expected['bytes'] and hashlib.sha256(content).hexdigest()==expected['sha256']
(validation/'qa.json').write_text(json.dumps({'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(manifest)+2,'files':manifest,'benchmarkExecuted':False,'performanceAccepted':None,'gateReevaluated':False},indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'qaBytes':archive.stat().st_size,'members':len(manifest)+2,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'counts':{key:{'wpt':value['wpt']['assertions'],'sharedFailed':value['wpt']['sharedFailedAssertions'],'vitest':value['vitest'],'vm':value['vm']} for key,value in summary['nodes'].items()}}))
