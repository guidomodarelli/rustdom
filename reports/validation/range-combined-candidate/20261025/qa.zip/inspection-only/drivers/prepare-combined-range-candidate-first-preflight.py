"""Prepare a new combined Rust candidate from current reviewed patches; no timing capture or historical package writes."""
import hashlib,json,subprocess,sys
from pathlib import Path
if sys.flags.optimize:raise RuntimeError('Candidate preparation requires non-optimized Python')
repository=Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom')
common=Path('/mnt/c/Users/guido/ghq/projects/rustdom/.git')
root=Path('/home/guido/rustdom-validation/range-combined-candidate-20261025-f781')
source=root/'source'
head='f781c3b7549a86b6aa8b5a34d2bbb32038c315b7'
assert common.is_dir() and not common.is_symlink()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repository,text=True).strip()==head
assert not root.exists()
root.mkdir();(root/'logs').mkdir()
subprocess.run(['git','clone','--shared','--no-checkout',str(common),str(source)],check=True)
subprocess.run(['git','config','core.autocrlf','false'],cwd=source,check=True)
fixtures=['reports/validation/native-class-ownership/ci-macos-timeout/fixture.json.gz','reports/validation/native-class-ownership/ci-macos-timeout/39686199408/fixture.json.gz','reports/validation/native-class-ownership/ci-windows-timeout/39894045206/comparison.json.gz']
subprocess.run(['git','sparse-checkout','set','--no-cone','/*','!/*/','/src/','/scripts/','/benchmarks/','/tests/','/third-party/','/types/',*['/'+name for name in fixtures]],cwd=source,check=True)
subprocess.run(['git','checkout','--detach',head],cwd=source,check=True)
assert (source/'.git').is_dir() and not subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=source)
static=repository/'reports/implementation/static-range-candidate'
collapse=repository/'reports/benchmarks/native-class-ownership/range-collapse-candidate'
static_policy=json.loads((static/'source.json').read_bytes())
collapse_policy=json.loads((collapse/'constants/candidate.json').read_bytes())
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
assert digest(static/'static-range.patch')==static_policy['patchSha256']
assert digest(collapse/'range-collapse.patch')==collapse_policy['patchSha256']
paths=sorted(set(static_policy['sourceBefore'])|set(collapse_policy['files']))
before={name:digest(source/name) if (source/name).exists() else None for name in paths}
for name,expected in static_policy['sourceBefore'].items():assert before[name]==expected,name
for name,values in collapse_policy['files'].items():assert before[name]==values['before'],name
commands=[]
def apply(label,path,extra):
    for check in [True,False]:
        command=['git','apply',*extra,*(['--check'] if check else []),str(path)]
        observed=subprocess.run(command,cwd=source,capture_output=True)
        name=label+('-check' if check else '-apply')
        (root/'logs'/(name+'.stdout.log')).write_bytes(observed.stdout)
        (root/'logs'/(name+'.stderr.log')).write_bytes(observed.stderr)
        commands.append({'argv':command,'exitCode':observed.returncode})
        (root/'prepare-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
        assert observed.returncode==0,name
apply('static-range',static/'static-range.patch',['--unidiff-zero'])
for name,expected in static_policy['sources'].items():assert digest(source/name)==expected,name
apply('atomic-collapse',collapse/'range-collapse.patch',[])
for entry,values in collapse_policy['functional'].items():
    assert digest(collapse/entry)==values['sha256']
    destination=source/values['target']
    assert not destination.exists(),str(destination)
    destination.parent.mkdir(parents=True,exist_ok=True)
    destination.write_bytes((collapse/entry).read_bytes())
actual={name:digest(source/name) for name in paths}
receipt={'baseCommit':head,'runtimeIntegrated':False,'newCandidate':True,'benchmarkExecuted':False,'performanceAccepted':None,'gateReevaluated':False,'historicalPackagesModified':False,'sourceBefore':before,'sourceAfter':actual,'staticRangePatchSha256':static_policy['patchSha256'],'collapsePatchSha256':collapse_policy['patchSha256'],'sourceChangesRaw':subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=source,text=True),'fixturesFromBaseCommit':{name:digest(source/name) for name in fixtures}}
(root/'preparation.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'prepared':True,'root':str(root),'baseCommit':head,'candidateSourceFiles':len(actual),'benchmarkExecuted':False,'sourceChanges':receipt['sourceChangesRaw']}))
