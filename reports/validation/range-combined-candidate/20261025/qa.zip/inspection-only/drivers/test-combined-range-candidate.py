"""Run real combined-candidate behavior, package consumers, runners and resource probes on both pinned Nodes."""
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
if sys.flags.optimize:raise RuntimeError('Combined candidate tests require non-optimized Python')
root=Path('/home/guido/rustdom-validation/range-combined-candidate-20261025-f781')
source=root/'source';repository=Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom')
profile=sys.argv[1];mode=sys.argv[2]
assert profile in ['node22','node24'] and mode in ['directed','suites','types','memory']
proof=root/'qa'/(profile+'-'+mode);proof.mkdir(parents=True)
build=json.loads((root/'build.json').read_bytes());assert build.get('buildComplete')
binary=hashlib.sha256((source/'dist/rustdom.node').read_bytes()).hexdigest();assert binary==build['nativeBinarySha256']
tools=Path('/mnt/c/Users/guido/ghq/projects/rustdom/.tools')
node_root=tools/('node-22' if profile=='node22' else 'node');node=node_root/'bin/node'
expected={'node22':('v22.12.0','177208bfc4a9403121a40c72d038c670f4fd937fa16ca7df0a720e90be0fe2d9'),'node24':('v24.14.1','bf9112eb83a827dc9f9c8d19bb7bddcbf00f7b2fedae18fdcaee05406981f20a')}
version=subprocess.check_output([node,'--version'],text=True).strip();node_hash=hashlib.sha256(node.read_bytes()).hexdigest()
assert (version,node_hash)==expected[profile]
environment=dict(os.environ,PATH=str(node.parent)+os.pathsep+os.environ.get('PATH',''),RUSTDOM_STATIC_RANGE_SOURCE=str(source),RUSTDOM_COMBINED_SOURCE=str(source),RUSTDOM_RANGE_PREPARATION_SOURCE=str(source))
record={'baseCommit':build['baseCommit'],'profile':profile,'mode':mode,'node':version,'nodeSha256':node_hash,'nativeBinarySha256':binary,'runtimeIntegrated':False,'performanceAccepted':None,'benchmarkExecuted':False,'gateReevaluated':False,'commands':[]}
if mode=='directed':
    commands=[('directed',[node,'--expose-gc','--test','--test-concurrency=1',*sorted((source/'tests').glob('range-*.spec.cjs')),source/'tests/combined-range-candidate.spec.cjs',repository/'reports/implementation/static-range-candidate/public.spec.cjs'])]
elif mode=='suites':
    commands=[(name,[node,node_root/'lib/node_modules/npm/bin/npm-cli.js','run',name]) for name in ['test:compat','test:jest','test:vitest','test:vm','test:corpus','test:wpt']]
elif mode=='memory':
    commands=[('static-memory',[node,'--expose-gc',repository/'reports/implementation/static-range-candidate/memory.cjs']),('collapse-memory',[node,'--expose-gc',source/'tests/helpers/range-collapse-memory.cjs'])]
else:
    output=source/'.cache'/('combined-consumers-'+profile)
    commands=[('compile-consumers',[node,source/'node_modules/typescript/bin/tsc','--strict','--module','NodeNext','--target','ES2022','--esModuleInterop','--skipLibCheck','false','--types','node','--rootDir',source,'--outDir',output,source/'tests/consumers/consumer.cts',source/'tests/consumers/consumer.mts'])]
    commands.extend(('consumer-'+extension,[node,output/'tests/consumers'/('consumer.'+extension)]) for extension in ['cjs','mjs'])
for name,argv in commands:
    label=name.replace(':','-');before=time.monotonic()
    before_reports={file.relative_to(source/'reports').as_posix():hashlib.sha256(file.read_bytes()).hexdigest() for file in (source/'reports').rglob('*') if file.is_file()} if (source/'reports').exists() else {}
    with (proof/(label+'.stdout.log')).open('xb') as stdout,(proof/(label+'.stderr.log')).open('xb') as stderr:
        try:
            observed=subprocess.run(list(map(str,argv)),cwd=source,env=environment,stdout=stdout,stderr=stderr,timeout=1200)
            result={'name':name,'argv':list(map(str,argv)),'exitCode':observed.returncode,'timedOut':False,'seconds':time.monotonic()-before}
        except subprocess.TimeoutExpired:
            result={'name':name,'argv':list(map(str,argv)),'exitCode':None,'timedOut':True,'seconds':time.monotonic()-before}
    record['commands'].append(result)
    record['sourceChangesRaw']=subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=source,text=True)
    (proof/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
    for file in (source/'reports').rglob('*'):
        if file.is_file():
            relative=file.relative_to(source/'reports').as_posix()
            if hashlib.sha256(file.read_bytes()).hexdigest()!=before_reports.get(relative):
                destination=proof/(label+'-reports')/relative;destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(file.read_bytes())
    assert hashlib.sha256((source/'dist/rustdom.node').read_bytes()).hexdigest()==binary
    print(json.dumps({'profile':profile,**result}),flush=True)
    assert result['exitCode']==0,label
