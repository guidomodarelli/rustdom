import hashlib,json,subprocess
from pathlib import Path
root=Path('/home/guido/rustdom-validation/range-combined-candidate-20261025-f781')
source=root/'source';target=root/'roundtrip'
assert (target/'.git').is_dir()
policy=json.loads((root/'preparation.json').read_bytes())
fixtures=list(policy['fixturesFromBaseCommit'])
subprocess.run(['git','sparse-checkout','add','--no-cone','/tests/','/benchmarks/','/third-party/',*['/'+name for name in fixtures]],cwd=target,check=True)
for name in ['node_modules','dist']:
    assert not (target/name).exists()
    subprocess.run(['cp','-a','--reflink=auto',str(source/name),str(target/name)],check=True)
additional=['tests/combined-range-candidate.spec.cjs','tests/range-collapse-candidate.spec.cjs','tests/consumers/consumer.cts','tests/consumers/consumer.mts','tests/helpers/constants/range-collapse.cjs','tests/helpers/range-collapse-memory.cjs']
for name in additional:
    assert not (target/name).exists(),name
    (target/name).parent.mkdir(parents=True,exist_ok=True)
    (target/name).write_bytes((source/name).read_bytes())
for name,expected in policy['sourceAfter'].items():assert hashlib.sha256((target/name).read_bytes()).hexdigest()==expected,name
build=json.loads((root/'build.json').read_bytes())
assert hashlib.sha256((target/'dist/rustdom.node').read_bytes()).hexdigest()==build['nativeBinarySha256']
receipt={'baseCommit':policy['baseCommit'],'runtimeSourceFilesIdentical':len(policy['sourceAfter']),'nativeBinaryCopiedFromCompiledCandidate':True,'nativeBinarySha256':build['nativeBinarySha256'],'additionalTests':{name:hashlib.sha256((target/name).read_bytes()).hexdigest() for name in additional},'dependenciesLockSha256':hashlib.sha256((target/'package-lock.json').read_bytes()).hexdigest(),'sourceChangesRaw':subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=target,text=True),'benchmarkExecuted':False,'performanceAccepted':None}
(root/'node24-preparation.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'node24Source':str(target),'nativeBinarySha256':build['nativeBinarySha256'],'runtimeSourceFilesIdentical':len(policy['sourceAfter'])}))
