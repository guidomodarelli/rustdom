"""Exercise read-only exports of the original 64 workers in a separate real Git checkout; never change the live study or invoke a DOM worker."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

original = Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom')
outer = Path('/home/guido/rustdom-validation/combined-resource-export-qualification-20261025-ci-alias'); outer.mkdir()
source = outer / 'source'; proof = outer / 'proof'; proof.mkdir()
method = 'reports/benchmarks/native-class-ownership/combined-process-study'
reader = 'reports/benchmarks/native-class-ownership/combined-process-exports'
subprocess.run(['git', 'init', '-q', str(source)], check=True)
(source / '.git/objects/info/alternates').write_text('/mnt/c/Users/guido/ghq/projects/rustdom/.git/objects\n')
for key, value in [('core.autocrlf', 'false'), ('core.sparseCheckout', 'true'), ('core.sparseCheckoutCone', 'false')]:
    subprocess.run(['git', '-C', str(source), 'config', key, value], check=True)
(source / '.git/info/sparse-checkout').write_text('/' + method + '/\n')
subprocess.run(['git', '-C', str(source), 'checkout', '--detach', '74ec308b405c79f0568f3ba03d3a5699c39c0f9b'], check=True)

workflow='.github/workflows/combined-resource-exports.yml'
(source / workflow).parent.mkdir(parents=True, exist_ok=True)
shutil.copyfile(original / workflow, source / workflow)
config = json.loads((original / reader / 'constants/exports.json').read_bytes())
subprocess.run(['git', '-C', str(source), 'sparse-checkout', 'add', '--no-cone', *['/' + value['path'] for value in config['helpers'].values()]], check=True)
for descriptor in config['helpers'].values():
    assert hashlib.sha256((source / descriptor['path']).read_bytes()).hexdigest() == descriptor['sha256']
shutil.copytree(original / reader, source / reader)
subprocess.run(['python3', '-B', str(source / reader / 'tools/configure-checkout.py'), str(source)], check=True)
subprocess.run(['python3', '-B', str(source / method / 'materialize-functional.py'), str(outer / 'data')], check=True)
commands = []
for label, node, version in [('node22', '/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node-22/bin/node', '22.12.0'),
                             ('node24', '/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node/bin/node', '24.14.1')]:
    for operation, arguments in [('runtime', [source / method / 'tools/runtime.cjs', version]),
                                 ('tests', ['--test', source / reader / 'resources.spec.cjs']),
                                 ('export', [source / reader / 'resources.cjs', '--functional', outer / 'data', outer / (label + '-export')])]:
        name = label + '-' + operation
        with (proof / (name + '.stdout.log')).open('xb') as stdout, (proof / (name + '.stderr.log')).open('xb') as stderr:
            result = subprocess.run([node, *map(str, arguments)], cwd=source, stdout=stdout, stderr=stderr)
        commands.append({'label': name, 'argv': [node, *map(str, arguments)], 'exitCode': result.returncode})
        (proof / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
        print(json.dumps(commands[-1]), flush=True)
        assert result.returncode == 0, name
subprocess.run(['/mnt/c/Users/guido/ghq/projects/rustdom/.tools/actionlint/actionlint','-ignore','SC.*', str(source/workflow)],check=True)
for name in [config['files']['spans'], config['files']['resources']]:
    assert (outer / 'node22-export' / name).read_bytes() == (outer / 'node24-export' / name).read_bytes()
results = [json.loads((outer / (label + '-export') / config['files']['summary']).read_bytes()) for label in ['node22', 'node24']]
for field in ['totals', 'groups', 'byRow', 'parentSnapshots', 'sourceCommit', 'purpose', 'verification']:
    assert results[0][field] == results[1][field], field
publication = json.loads((source / 'reports/validation/combined-process-capture-method/review.json').read_bytes())
for name, expected in publication['files'].items():
    assert hashlib.sha256((source / name).read_bytes()).hexdigest() == expected, name
result = {'sourceCommit': '74ec308b405c79f0568f3ba03d3a5699c39c0f9b',
    'sourceChangesRaw': subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=all'], cwd=source).decode(),
    'readerOverlay': 'Actual uncommitted current reader; frozen scientific code is unchanged',
    'sameScientificInputs': True, 'functionalProcessesRead': 64, 'newMeasurementProcesses': 0,
    'CSVAndJSONLByteIdenticalBetweenSDKs': True, 'memoryGroupsIdenticalBetweenSDKs': True,
    'performanceAccepted': None, 'gateReevaluated': False, 'commands': commands}
(proof / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key not in ['commands', 'sourceChangesRaw']}), flush=True)
