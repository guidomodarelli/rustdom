/** @file Native Selection activation and scalar contracts through the actual addon. */
'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { NativeSelectionState, SelectionOperation, selectionOperationStatistics } = require('../dist/native.cjs');
const { JSDOM } = require('../dist/index.cjs');

test('should preserve native direction, association and containment decisions', () => {
  const state = new NativeSelectionState(); assert.equal(state.direction, 0);
  assert.equal(state.associate(false, true, false, true, true), true); assert.equal(state.anchorIsStart, true);
  state.orient(true); assert.equal(state.direction, -1); assert.equal(state.anchorIsStart, false);
  assert.equal(state.associate(true, true, false, true, true), false); assert.equal(state.direction, 1);
  assert.equal(NativeSelectionState.selectionType(false, true), 'None'); assert.equal(NativeSelectionState.selectionType(true, true), 'Caret');
  assert.equal(NativeSelectionState.contains(true, false, true), true); assert.equal(NativeSelectionState.contains(true, false, false), false);
  assert.equal(SelectionOperation[SelectionOperation.Anchor], undefined);
});

test('should run public Selection operations through native control while retaining shared Range identity', () => {
  const dom = new JSDOM('<p>abcdef</p>');
  try {
    const before = selectionOperationStatistics(); const selection = dom.window.getSelection(); const text = dom.window.document.querySelector('p').firstChild;
    selection.setBaseAndExtent(text, 5, text, 1); assert.equal(selection.anchorOffset, 5); assert.equal(selection.focusOffset, 1); assert.equal(String(selection), 'bcde');
    const range = selection.getRangeAt(0); range.setEnd(text, 6); assert.equal(String(selection), 'bcdef');
    selection.removeAllRanges(); assert.equal(selection.rangeCount, 0);
    const after = selectionOperationStatistics(); assert.ok(after.calls > before.calls); assert.equal(after.active, 0);
  } finally { dom.window.close(); }
});
