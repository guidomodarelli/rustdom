#[path = "/home/guido/rustdom-validation/ownership-cold-cleanup-prototype/source/third-party/napi/src/bindgen_runtime/class_ownership.rs"]
mod class_ownership;
