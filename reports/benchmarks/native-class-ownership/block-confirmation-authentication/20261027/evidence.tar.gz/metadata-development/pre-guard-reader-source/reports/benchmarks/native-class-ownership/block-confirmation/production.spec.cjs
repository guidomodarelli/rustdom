/** @module production-equivalence-contracts Treats compiler sources as authenticated input data, never matches implementation strings or mocks the runtime. */
'use strict';
const assert = require('node:assert/strict');
const test = require('node:test');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { inspectProduction, requireProductionEquivalence } = require('./production.cjs');
const policy = require('./constants/production.json');
const candidate = process.env[policy.candidateSourcesEnvironment];
const production = process.env[policy.sourceEnvironment];
const baseline = process.env[policy.baselineSourcesEnvironment];

test('isolated authenticated candidate sources match all 344 inputs but do not certify production, a build or performance', () => {
  const result = requireProductionEquivalence(candidate);
  assert.equal(result.inputCount, 344); assert.equal(result.differences.length, 0);
  assert.equal(result.GitIdentityAuthenticated, false); assert.equal(result.binaryBuiltByThisFunction, false);
  assert.equal(result.packageAuthenticatedByThisFunction, false); assert.equal(result.performanceAccepted, null);
  assert.equal(result.gateReevaluated, false);
});

test('published pre-integration baseline reports the complete four-file gap and blocks source-equivalence approval', () => {
  const result = inspectProduction(baseline);
  assert.equal(result.inputCount, 344); assert.equal(Object.keys(result.observedInputs).length, 344);
  assert.deepEqual(result.differences.map((entry) => entry.path).sort(),
    ['src/dom/native-tree.cjs', 'src/dom/range_state.rs', 'src/dom/range_state_binding.rs', 'types/native.d.cts']);
  assert.equal(result.matchesSelectedCompilerInputs, false);
  assert.throws(() => requireProductionEquivalence(baseline), /4 compiler inputs differ/);
});

test('actual current production is compared in full and cannot be approved when any input differs', () => {
  const result = inspectProduction(production);
  assert.equal(result.inputCount, 344); assert.equal(Object.keys(result.observedInputs).length, 344);
  if (result.differences.length === 0) assert.equal(requireProductionEquivalence(production).matchesSelectedCompilerInputs, true);
  else assert.throws(() => requireProductionEquivalence(production), /compiler inputs differ/);
  assert.equal(result.performanceAccepted, null);
});

test('one altered or missing compiler input in an owned copy cannot pass the selected candidate identity', (context) => {
  const parent = fs.realpathSync(os.tmpdir());
  const root = fs.mkdtempSync(path.join(parent, 'rustdom-production-equivalence-'));
  context.after(() => {
    const resolved = fs.realpathSync(root);
    assert.ok(resolved.startsWith(parent + path.sep));
    assert.ok(path.basename(resolved).startsWith('rustdom-production-equivalence-'));
    fs.rmSync(resolved, { recursive: true });
  });
  const input = inspectProduction(candidate);
  for (const relative of Object.keys(input.observedInputs)) {
    const output = path.join(root, ...relative.split('/'));
    fs.mkdirSync(path.dirname(output), { recursive: true });
    fs.copyFileSync(path.join(candidate, ...relative.split('/')), output);
  }
  assert.equal(requireProductionEquivalence(root).matchesSelectedCompilerInputs, true);
  const target = path.join(root, 'Cargo.toml');
  fs.appendFileSync(target, '\n');
  assert.equal(inspectProduction(root).differences.length, 1);
  assert.throws(() => requireProductionEquivalence(root), /1 compiler inputs differ/);
  fs.unlinkSync(target);
  const missing = inspectProduction(root);
  assert.equal(missing.differences.length, 1); assert.equal(missing.differences[0].reason, 'missing-input');
});
