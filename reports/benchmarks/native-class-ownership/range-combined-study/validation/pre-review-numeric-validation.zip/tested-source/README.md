# PreparaciÃ³n numÃ©rica para un mÃ©todo prospectivo

Este directorio todavÃ­a no define un estudio ejecutable: no tiene sampler,
activador, paquete seleccionado, nÃºmero de procesos congelado ni decisiÃ³n de
aceptaciÃ³n. Los 48 pares de algunos fixtures son datos numÃ©ricos sintÃ©ticos,
no duraciones capturadas ni el tamaÃ±o aprobado de un experimento.
No reemplaza los estimadores ni los rechazos de estudios histÃ³ricos.

`paired-interval.cjs` calcula el cociente de medias aritmÃ©ticas y un intervalo
Fieller a partir de resÃºmenes emparejados por proceso. El consumidor debe
proporcionar una media por proceso y el valor crÃ­tico declarado. La fÃ³rmula
conserva la covarianza dentro de cada par; las observaciones repetidas de un
proceso no pasan a ser ejecuciones independientes por aparecer en un array.
El mÃ³dulo no autentica captures ni demuestra independencia o estacionariedad.

Para n pares, medias a/b, varianzas muestrales va/vb y covarianza c:

```
h = criticalValueÂ² / n
A = aÂ² - h * va
B = a*b - h * c
C = bÂ² - h * vb
interval = (B Â± sqrt(BÂ² - A*C)) / A
```

La implementaciÃ³n escala las duraciones antes de acumular momentos con
Welford. Un denominador no positivo devuelve `unbounded`; un cÃ¡lculo no
representable devuelve `not-estimable`. Nunca se truncan intervalos al presupuesto.
Solo se admite redondear un discriminante negativo dentro de 64 ULP de sus
tÃ©rminos; se registra cuando ocurre. Los resultados siempre conservan
`performanceAccepted=null` y `gateReevaluated=false`.

Referencias primarias: [Kalibera y Jones](https://kar.kent.ac.uk/33611/45/p63-kaliber.pdf)
tratan la repeticiÃ³n por niveles y la incertidumbre del cociente de tiempos;
[Georges, Buytaert y Eeckhout](https://users.elis.ugent.be/~leeckhou/papers/oopsla07-stat.pdf)
distinguen iteraciones de invocaciones. La variante emparejada con covarianza
es la fÃ³rmula explÃ­cita de este mÃ³dulo, no una afirmaciÃ³n de que esos trabajos
validaron el sampler de rustdom. Los intervalos requieren supuestos estadÃ­sticos;
un cambio dentro de una ejecuciÃ³n no prueba causalidad JIT/GC ni steady-state.

La referencia independiente usa NumPy 2.2.6/SciPy 1.15.3 y encuentra las raÃ­ces
de la desigualdad t emparejada mediante Brent, sin copiar la fÃ³rmula cuadrÃ¡tica
JavaScript. Incluye proporcionalidad exacta, covarianza positiva/negativa y
baseline incierto. Los tests verifican ademÃ¡s unidades, permutaciÃ³n, inversiÃ³n
de labels, entradas invÃ¡lidas, underflow y preservaciÃ³n de las entradas.

```sh
python -m pip install -r tools/reference-requirements.txt
python -B tools/generate-numerical-reference.py /salida-nueva/reference.json
python -B tools/reference.spec.py
node --test paired-interval.spec.cjs
```

Usar un entorno local aislado para la referencia cientÃ­fica; no se aÃ±ade SciPy
como dependencia del runtime, paquete npm o capturador. Los tests usan el cÃ³digo
actual y los fixtures numÃ©ricos, nunca scripts archivados ni un runtime DOM.

El cÃ¡lculo conserva solo acumuladores y el input de la llamada, sin caches ni
referencias persistentes. No crea Window/Document, observers ni recursos N-API;
no aporta nueva cobertura de memoria DOM ni mide memoria pico. La validaciÃ³n
funcional del candidato y sus probes se conservan por separado. TodavÃ­a deben
fijarse y revisarse todos los detalles de cualquier futura mediciÃ³n antes de
ejecutarla, con los presupuestos originales y la autorizaciÃ³n permanente.
