/** @module paired-process-interval Computes a bounded Fieller interval from complete paired process summaries. */
'use strict';
const policy = require('./constants/interval.json');

/**
 * Estimate a ratio of arithmetic means without treating repeated spans as independent processes.
 * The caller supplies one summary per process in each matched pair and the declared t critical value.
 * This numerical function does not choose a confidence level, sampler, budget, or acceptance decision.
 * @param {{baselineMeanMs: number, candidateMeanMs: number}[]} pairs - Matched independent execution summaries.
 * @param {number} criticalValue - Positive critical value chosen before interpreting results.
 * @returns {object} Bounded interval or an explicit non-estimable/unbounded result, never acceptance.
 * @throws {RangeError} When the public numerical inputs cannot describe positive execution durations.
 */
function pairedInterval(pairs, criticalValue) {
  if (!Array.isArray(pairs) || pairs.length < policy.minimumPairCount) {
    throw new RangeError('Paired interval: provide at least ' + policy.minimumPairCount + ' process pairs');
  }
  if (!Number.isFinite(criticalValue) || criticalValue <= 0) {
    throw new RangeError('Paired interval: criticalValue must be finite and positive');
  }
  let scale = 0;
  for (const [pairIndex, pair] of pairs.entries()) {
    for (const field of ['baselineMeanMs', 'candidateMeanMs']) {
      if (!pair || !Number.isFinite(pair[field]) || pair[field] <= 0) {
        throw new RangeError('Paired interval: ' + field + ' must be finite and positive at pairIndex=' + pairIndex);
      }
    }
    scale = Math.max(scale, pair.baselineMeanMs, pair.candidateMeanMs);
  }
  let baselineMean = 0;
  let candidateMean = 0;
  let baselineSquaredDeviations = 0;
  let candidateSquaredDeviations = 0;
  let pairedDeviations = 0;
  for (const [pairIndex, pair] of pairs.entries()) {
    const count = pairIndex + 1;
    const baseline = pair.baselineMeanMs / scale;
    const candidate = pair.candidateMeanMs / scale;
    const baselineDelta = baseline - baselineMean;
    const candidateDelta = candidate - candidateMean;
    baselineMean += baselineDelta / count;
    candidateMean += candidateDelta / count;
    baselineSquaredDeviations += baselineDelta * (baseline - baselineMean);
    candidateSquaredDeviations += candidateDelta * (candidate - candidateMean);
    pairedDeviations += baselineDelta * (candidate - candidateMean);
  }
  const pointRatio = candidateMean / baselineMean;
  const result = { revision: policy.revision, pairCount: pairs.length, criticalValue,
    baselineMeanMs: baselineMean * scale, candidateMeanMs: candidateMean * scale,
    pointRatio, changePercent: 100 * (pointRatio - 1), intervalRatio: null,
    intervalChangePercent: null, performanceAccepted: null, gateReevaluated: false };
  const degreesOfFreedom = pairs.length - 1;
  const varianceBaseline = baselineSquaredDeviations / degreesOfFreedom;
  const varianceCandidate = candidateSquaredDeviations / degreesOfFreedom;
  const covariance = pairedDeviations / degreesOfFreedom;
  const squaredCriticalOverCount = criticalValue ** 2 / pairs.length;
  const denominator = baselineMean ** 2 - squaredCriticalOverCount * varianceBaseline;
  const center = baselineMean * candidateMean - squaredCriticalOverCount * covariance;
  const constant = candidateMean ** 2 - squaredCriticalOverCount * varianceCandidate;
  if (![pointRatio, denominator, center, constant].every(Number.isFinite) || baselineMean <= 0) {
    return { ...result, status: 'not-estimable', reason: 'non-finite-arithmetic' };
  }
  if (denominator <= 0) {
    return { ...result, status: 'unbounded', reason: 'baseline-uncertainty-includes-zero' };
  }
  const squaredCenter = center ** 2;
  const product = denominator * constant;
  const discriminant = squaredCenter - product;
  const tolerance = policy.discriminantRelativeToleranceMultiplier * Number.EPSILON *
    Math.max(Math.abs(squaredCenter), Math.abs(product), Number.MIN_VALUE);
  if (!Number.isFinite(discriminant) || discriminant < -tolerance) {
    return { ...result, status: 'not-estimable', reason: 'negative-or-non-finite-discriminant' };
  }
  const roundedDiscriminant = Math.max(0, discriminant);
  const halfWidth = Math.sqrt(roundedDiscriminant);
  const upper = (center + halfWidth) / denominator;
  const lower = upper !== 0 ? constant / (denominator * upper) : (center - halfWidth) / denominator;
  if (![lower, upper].every(Number.isFinite)) {
    return { ...result, status: 'not-estimable', reason: 'non-finite-bounds' };
  }
  return { ...result, status: 'bounded', intervalRatio: [lower, upper],
    intervalChangePercent: [100 * (lower - 1), 100 * (upper - 1)],
    discriminantRoundedToZero: discriminant < 0 };
}

module.exports = { pairedInterval };
