import json,runpy,sys
from pathlib import Path
root=Path.cwd();package=root/'reports/benchmarks/native-class-ownership/range-combined-study';out=root/'.cache/numerical-reference-with-producer.json';assert not out.exists()
sys.path.insert(0,str(root/'.cache/statistics-reference'));sys.argv=[str(package/'tools/generate-numerical-reference.py'),str(out)];runpy.run_path(sys.argv[0],run_name='__main__')
(package/'validation/numerical-reference.json').write_bytes(out.read_bytes())
sys.argv=[str(package/'tools/reference.spec.py')];runpy.run_path(sys.argv[0],run_name='__main__')
