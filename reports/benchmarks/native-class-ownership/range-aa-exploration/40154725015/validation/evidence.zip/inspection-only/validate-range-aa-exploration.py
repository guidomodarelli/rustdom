import hashlib,json,subprocess,sys
from pathlib import Path
root=Path.cwd()
linux='/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom'
relative='reports/benchmarks/native-class-ownership/range-aa-exploration/40154725015'
source='reports/benchmarks/native-class-ownership/range-control-telemetry-results/40154725015'
proof=root/'.cache/range-aa-exploration-validation'
proof.mkdir(exist_ok=True)
records=[]
def execute(label,argv):
    with (proof/(label+'.stdout.log')).open('xb') as stdout,(proof/(label+'.stderr.log')).open('xb') as stderr:
        result=subprocess.run(argv,cwd=root,stdout=stdout,stderr=stderr)
    records.append({'label':label,'argv':argv,'exitCode':result.returncode})
    (proof/'commands.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8',newline='\n')
    assert result.returncode==0,label
execute('windows-contracts',[sys.executable,'-B',str(root/relative/'tools/explore.spec.py'),str(root/source)])
execute('linux-contracts',['wsl','-d','Ubuntu-22.04','--','python3','-B',linux+'/'+relative+'/tools/explore.spec.py',linux+'/'+source])
execute('linux-export',['wsl','-d','Ubuntu-22.04','--','python3','-B',linux+'/'+relative+'/tools/explore.py',linux+'/'+source,linux+'/.cache/range-aa-within-process-linux'])
execute('actionlint',['wsl','-d','Ubuntu-22.04','--','/mnt/c/Users/guido/ghq/projects/rustdom/.tools/actionlint/actionlint','-no-color',linux+'/.github/workflows/range-aa-result-readers.yml'])
hashes={}
for name in json.loads((root/relative/'tools/constants/exploration.json').read_bytes())['outputs']:
    published=(root/relative/name).read_bytes()
    assert published==(root/'.cache/range-aa-within-process-linux'/name).read_bytes()
    hashes[name]=hashlib.sha256(published).hexdigest()
result={'windowsContracts':8,'linuxContracts':8,'exportsByteIdentical':hashes,'actionlintExitCode':0,'newMeasurements':0,'DOMExecuted':False,'performanceAccepted':None,'gateReevaluated':False,'sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'sourceChangesRaw':subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=root,text=True)}
(proof/'summary.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(result))
