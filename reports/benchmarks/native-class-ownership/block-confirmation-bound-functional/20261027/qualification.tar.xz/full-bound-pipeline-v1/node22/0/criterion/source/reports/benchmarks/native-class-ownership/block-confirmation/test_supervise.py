"""Exercise the real Linux supervisor and detached processes at an owned coordinator fault boundary; no DOM, fake platform API or scientific data."""
import sys
if sys.flags.optimize:
    raise RuntimeError('Supervisor contracts require non-optimized Python')
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import tempfile
import time
import unittest

SOURCE = Path(__file__).resolve().parent
REPOSITORY = SOURCE.parents[3]
NODE = Path(os.environ['RUSTDOM_CONFIRMATION_NODE']).resolve(strict=True)
POLICY = json.loads((SOURCE / 'constants/capture.json').read_bytes())
DESIGN = json.loads((SOURCE / 'constants/design.json').read_bytes())
assert hashlib.sha256(NODE.read_bytes()).hexdigest() in DESIGN['nodeExecutableSha256'].values()

COORDINATOR = r"""'use strict';
const fs=require('node:fs'),path=require('node:path'),{spawn}=require('node:child_process');
const policy=require('./constants/capture.json');
const destination=process.argv[4],criterionId=process.argv[5];
fs.mkdirSync(destination);
const uptimeSeconds=Number(fs.readFileSync('/proc/uptime','ascii').split(' ',1)[0]);
fs.writeFileSync(path.join(destination,policy.files.captureStart),JSON.stringify({revision:policy.revision,mode:policy.functionalMode,
parentPid:process.pid,node:process.version,criterionId:process.env.CONFIRMATION_FAULT==='bad-marker'?'synthetic-invalid-marker':criterionId,uptimeSeconds,uptimeResolutionSeconds:policy.uptimeResolutionSeconds,
captureBudgetMs:policy.functionalTimeoutMs,clock:policy.uptimeClock}));
if(process.env.CONFIRMATION_FAULT==='success')process.exit(0);
const child=spawn(process.execPath,['-e','setInterval(()=>{},1000)'],{detached:true,stdio:'ignore'});child.unref();
fs.writeFileSync(path.join(destination,'ready.json'),JSON.stringify({parentPid:process.pid,childPid:child.pid}));
if(process.env.CONFIRMATION_FAULT==='orphan')process.exit(7);
setInterval(()=>{},1000);
"""


class SupervisorContracts(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='confirmation-supervisor-contract-')
        self.root = Path(self.temporary.name)
        self.repository = self.root / 'repo'
        self.source = self.repository / SOURCE.relative_to(REPOSITORY)
        (self.source / 'constants').mkdir(parents=True)
        for name in ['supervise.py', 'constants/capture.json', 'constants/design.json']:
            shutil.copyfile(SOURCE / name, self.source / name)
        helper = self.repository / POLICY['supervisor']['helper']
        helper.parent.mkdir(parents=True)
        shutil.copyfile(REPOSITORY / POLICY['supervisor']['helper'], helper)
        original_policy = REPOSITORY / Path(POLICY['supervisor']['helper']).parent.parent / 'constants/capture.json'
        target_policy = helper.parent.parent / 'constants/capture.json'
        target_policy.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(original_policy, target_policy)
        (self.source / 'criterion.cjs').write_text(COORDINATOR)
        self.prepared = self.root / 'unused-package'; self.prepared.mkdir()
        self.output = self.root / 'criterion'; self.receipt = self.root / 'supervisor.json'

    def tearDown(self):
        self.temporary.cleanup()

    def argv(self):
        return [sys.executable, '-B', str(self.source / 'supervise.py'), '--functional', str(self.receipt),
                str(NODE), '--expose-gc', str(self.source / 'criterion.cjs'), '--functional', str(self.prepared),
                str(self.output), 'synthetic-lifecycle-boundary-no-scientific-samples']

    def run_case(self, fault):
        child = subprocess.run(self.argv(), env=dict(os.environ, CONFIRMATION_FAULT=fault), capture_output=True, timeout=30)
        record = json.loads(self.receipt.read_bytes())
        self.assertTrue(record['complete']); self.assertEqual(record['ownedDescendantsRemaining'], [])
        self.assertIsNone(record['performanceAccepted']); self.assertFalse(record['gateReevaluated'])
        return child, record

    def test_fast_success_reads_marker_even_after_the_parent_exits(self):
        child, record = self.run_case('success')
        self.assertEqual(child.returncode, 0, child.stderr.decode())
        self.assertEqual(record['parentExitCode'], 0); self.assertEqual(record['exitCode'], 0)
        self.assertIn('captureStartMarkerSha256', record)
        self.assertFalse(record['unexpectedDescendants']); self.assertFalse(record['deadlineReached'])

    def test_forced_parent_exit_reaps_a_real_detached_child_without_accepting_it(self):
        child, record = self.run_case('orphan')
        self.assertEqual(child.returncode, 2); self.assertEqual(record['parentExitCode'], 7)
        self.assertTrue(record['unexpectedDescendants'])
        self.assertTrue(record['descendantsObservedAtParentExit'])

    def test_functional_fault_fixture_deadline_kills_owned_processes_and_preserves_rejection(self):
        # Only this owned functional fixture is shortened. The scientific design/budgets are not changed.
        filename = self.source / 'constants/capture.json'; policy = json.loads(filename.read_bytes())
        policy['functionalTimeoutMs'] = 200; filename.write_text(json.dumps(policy))
        child, record = self.run_case('wait')
        self.assertEqual(child.returncode, 2); self.assertTrue(record['deadlineReached'])

    def test_real_termination_signal_closes_parent_and_detached_descendant(self):
        child = subprocess.Popen(self.argv(), env=dict(os.environ, CONFIRMATION_FAULT='wait'), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        try:
            deadline = time.monotonic() + 10
            while not (self.output / 'ready.json').exists():
                self.assertIsNone(child.poll())
                self.assertLess(time.monotonic(), deadline); time.sleep(0.02)
            child.send_signal(signal.SIGTERM)
            stdout, stderr = child.communicate(timeout=20)
            self.assertEqual(child.returncode, 2, stderr.decode())
            record = json.loads(self.receipt.read_bytes())
            self.assertTrue(record['interrupted']); self.assertEqual(record['ownedDescendantsRemaining'], [])
        finally:
            if child.poll() is None:
                child.send_signal(signal.SIGTERM); child.communicate(timeout=20)

    def test_invalid_marker_reaps_live_owned_processes_and_preserves_the_failure(self):
        child, record = self.run_case('bad-marker')
        self.assertEqual(child.returncode, 2)
        self.assertIn('failure', record); self.assertEqual(record['exitCode'], 2)

    def test_existing_receipt_is_preserved_before_launching_a_coordinator(self):
        original = b'previous-owned-or-concurrent-evidence\n'; self.receipt.write_bytes(original)
        child = subprocess.run(self.argv(), env=dict(os.environ, CONFIRMATION_FAULT='success'), capture_output=True, timeout=20)
        self.assertEqual(child.returncode, 2); self.assertEqual(self.receipt.read_bytes(), original)
        self.assertFalse(self.output.exists())


if __name__ == '__main__':
    unittest.main()
