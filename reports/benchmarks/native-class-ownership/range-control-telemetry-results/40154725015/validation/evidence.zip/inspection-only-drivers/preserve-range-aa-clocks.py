import hashlib,json
from pathlib import Path
root=Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom')
packet=root/'reports/benchmarks/native-class-ownership/range-control-telemetry-results/40154725015'
capture=Path('/home/guido/rustdom-validation/range-aa-telemetry-result-40154725015/archive-current-reader/range-aa-telemetry/capture')
index=json.loads((capture/'index.json').read_bytes())
with (packet/'metadata/clock-observations.jsonl').open('x',encoding='utf-8') as output:
    for ordinal,entry in enumerate(index['processes']):
        raw=(capture/str(ordinal).zfill(4)/'analysis.json').read_bytes()
        assert hashlib.sha256(raw).hexdigest()==entry['files']['analysis.json']
        analysis=json.loads(raw)
        record={'ordinal':ordinal,'sourceAnalysisSha256':entry['files']['analysis.json']}
        for field in ['pid','node','mode','engine','label','physical','position','seed','jitBrackets','jitOffsets','cpuOffsets']:record[field]=analysis[field]
        output.write(json.dumps(record,separators=(',',':'))+'\n')
print('Preserved exact clock fields from all256 authenticated original analyses; no profiling executed')
