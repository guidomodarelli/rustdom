"""Replay the single authenticated AA archive with the exact reviewed Linux Git source; never run DOM."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

if sys.flags.optimize:
    raise RuntimeError('Range AA replay requires non-optimized Python')

repository = Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom')
source = Path('/home/guido/rustdom-validation/range-aa-telemetry-source-d5ec4186')
capture = Path('/home/guido/rustdom-validation/range-aa-telemetry-result-40154725015/archive-current-reader/range-aa-telemetry/capture')
collection = repository / '.cache/range-aa-collection-40154725015'
output = repository / '.cache/range-aa-replay-40154725015'
expected_head = 'd5ec4186d2033709e532bc93d6f47d930afe525f'

assert (source / '.git').is_dir(), 'Use a real Linux Git checkout, never the Windows gitfile'
state = json.loads((collection / 'collection.json').read_bytes())
assert state['runId'] == 40154725015 and state['jobId'] == 121053535757 and state['attempt'] == 1
assert state['head'] == expected_head and state['transportAuthenticated'] is True and state['status'] == 'completed'
index = json.loads((capture / 'index.json').read_bytes())
assert index['sourceCommit'] == expected_head and index['hostedRunId'] == '40154725015' and index['runAttempt'] == 1
receipt_name = 'reports/validation/native-class-ownership/range-control-telemetry-method/review.json'
receipt_bytes = (source / receipt_name).read_bytes()
assert hashlib.sha256(receipt_bytes).hexdigest() == 'bdab7f4639f99054c93b1f4f962f233a9e5feb98db6ea6c708de4da87e5be9fb'
assert receipt_bytes == (repository / receipt_name).read_bytes()
pins = json.loads(receipt_bytes)['files']
assert len(pins) == 599
for relative, expected in pins.items():
    assert hashlib.sha256((source / relative).read_bytes()).hexdigest() == expected, relative
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip()
status = subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=all'], cwd=source)
assert head == expected_head and status == b''
output.mkdir(exist_ok=False)
records = []
for label, relative, version, expected in [
    ('node22', '.tools/node-22/bin/node', 'v22.12.0', '177208bfc4a9403121a40c72d038c670f4fd937fa16ca7df0a720e90be0fe2d9'),
    ('node24', '.tools/node/bin/node', 'v24.14.1', 'bf9112eb83a827dc9f9c8d19bb7bddcbf00f7b2fedae18fdcaee05406981f20a')]:
    node = Path('/mnt/c/Users/guido/ghq/projects/rustdom') / relative
    assert hashlib.sha256(node.read_bytes()).hexdigest() == expected
    assert subprocess.check_output([str(node), '--version'], text=True).strip() == version
    argv = [str(node), str(source / 'reports/benchmarks/native-class-ownership/range-control-telemetry/run.cjs'), '--verify', str(capture)]
    result = subprocess.run(argv, cwd=source, capture_output=True)
    (output / (label + '.json')).write_bytes(result.stdout)
    (output / (label + '.stderr.log')).write_bytes(result.stderr)
    records.append({'argv': argv, 'exitCode': result.returncode, 'node': version, 'nodeSha256': expected,
        'stdoutSha256': hashlib.sha256(result.stdout).hexdigest(), 'stderrSha256': hashlib.sha256(result.stderr).hexdigest(),
        'sourceHead': head, 'sourceGitStatusRaw': status.decode()})
    (output / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(json.dumps({'node': version, 'exitCode': result.returncode}), flush=True)
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip() == head
assert subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=all'], cwd=source) == status
assert all(record['exitCode'] == 0 for record in records), 'Preserve failed replays and the original archive; never repeat capture'
assert (output / 'node22.json').read_bytes() == (output / 'node24.json').read_bytes()
print((output / 'node22.json').read_text())
