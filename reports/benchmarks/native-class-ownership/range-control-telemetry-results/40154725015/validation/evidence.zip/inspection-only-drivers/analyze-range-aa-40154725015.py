import hashlib,json,subprocess
from pathlib import Path
root=Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom')
packet=root/'reports/benchmarks/native-class-ownership/range-control-telemetry-results/40154725015'
capture=Path('/home/guido/rustdom-validation/range-aa-telemetry-result-40154725015/archive-current-reader/range-aa-telemetry/capture')
output=root/'.cache/range-aa-analysis-40154725015';output.mkdir(exist_ok=False)
commands=[]
for label,relative,version,expected in [('node22','.tools/node-22/bin/node','v22.12.0','177208bfc4a9403121a40c72d038c670f4fd937fa16ca7df0a720e90be0fe2d9'),('node24','.tools/node/bin/node','v24.14.1','bf9112eb83a827dc9f9c8d19bb7bddcbf00f7b2fedae18fdcaee05406981f20a')]:
    node=Path('/mnt/c/Users/guido/ghq/projects/rustdom')/relative
    assert hashlib.sha256(node.read_bytes()).hexdigest()==expected
    assert subprocess.check_output([str(node),'--version'],text=True).strip()==version
    argv=[str(node),str(packet/'tools/analyze.cjs'),str(capture),str(output/(label+'-export')),str(packet/'replay-node22.json')]
    result=subprocess.run(argv,cwd=root,capture_output=True)
    (output/(label+'.stdout.log')).write_bytes(result.stdout);(output/(label+'.stderr.log')).write_bytes(result.stderr)
    commands.append({'argv':argv,'exitCode':result.returncode,'node':version,'nodeSha256':expected,'analyzerSha256':hashlib.sha256((packet/'tools/analyze.cjs').read_bytes()).hexdigest(),'captureSourceCommit':'d5ec4186d2033709e532bc93d6f47d930afe525f','samplerInvoked':False})
    (output/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    print(json.dumps({'node':version,'exitCode':result.returncode,'stdout':result.stdout.decode()}),flush=True)
assert all(command['exitCode']==0 for command in commands)
exports={}
for label in ['node22','node24']:
    exports[label]={file.name:hashlib.sha256(file.read_bytes()).hexdigest() for file in (output/(label+'-export')).iterdir() if file.is_file()}
assert exports['node22']==exports['node24']
(output/'comparison.json').write_text(json.dumps({'node22Node24ByteIdentical':True,'files':exports['node22']},indent=2)+'\n')
