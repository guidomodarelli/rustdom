import hashlib,json,os,subprocess
from pathlib import Path
repository=Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom')
source=Path('/home/guido/rustdom-validation/inventory-source-d5ec4186-20261025')
dependencies=Path('/home/guido/rustdom-validation/static-range-candidate-20261024/source/node_modules')
assert (source/'.git').is_dir()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()=='d5ec4186d2033709e532bc93d6f47d930afe525f'
assert subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=source)==b''
paths=['tests/validation/migration-inventory.spec.mjs','tests/helpers/inventory-memory.cjs','scripts/migration-inventory.cjs','scripts/migration-inventory/reference.cjs','scripts/migration-inventory/surface.cjs','scripts/constants/migration-inventory.cjs','package.json','package-lock.json']
paths.append('scripts/memory-endpoint.cjs')
paths += [path.relative_to(repository).as_posix() for path in (repository/'reports/progress/inventory').iterdir() if path.is_file() and path.suffix=='.json']
proof={}
for relative in paths:
    raw=(source/relative).read_bytes();assert raw==(repository/relative).read_bytes(),relative
    proof[relative]=hashlib.sha256(raw).hexdigest()
assert json.loads((dependencies/'jsdom/package.json').read_bytes())['version']=='27.4.0'
output=repository/'.cache/inventory-narrative-native-linux-complete-20261025';output.mkdir(exist_ok=False)
(output/'source-proof.json').write_text(json.dumps({'sourceHead':'d5ec4186d2033709e532bc93d6f47d930afe525f','sourceCleanBefore':True,'inventorySourcesIdenticalToCurrent':proof,'dependenciesDirectory':str(dependencies),'jsdomVersion':'27.4.0','runtimeCandidateNotLoaded':True,'scientificSamplerInvoked':False},indent=2)+'\n')
commands=[]
for label,relative,version,expected in [('node22','.tools/node-22/bin/node','v22.12.0','177208bfc4a9403121a40c72d038c670f4fd937fa16ca7df0a720e90be0fe2d9'),('node24','.tools/node/bin/node','v24.14.1','bf9112eb83a827dc9f9c8d19bb7bddcbf00f7b2fedae18fdcaee05406981f20a')]:
    node=Path('/mnt/c/Users/guido/ghq/projects/rustdom')/relative
    assert hashlib.sha256(node.read_bytes()).hexdigest()==expected
    env=dict(os.environ,NODE_PATH=str(dependencies))
    resolution=subprocess.check_output([str(node),'-e',"console.log(JSON.stringify({jsdom:require.resolve('jsdom/package.json'),typescript:require.resolve('typescript/package.json')}))"],cwd=source,env=env)
    (output/(label+'.resolutions.json')).write_bytes(resolution)
    argv=[str(node),'--test',str(source/'tests/validation/migration-inventory.spec.mjs')]
    result=subprocess.run(argv,cwd=source,env=env,capture_output=True)
    (output/(label+'.stdout.log')).write_bytes(result.stdout);(output/(label+'.stderr.log')).write_bytes(result.stderr)
    commands.append({'argv':argv,'exitCode':result.returncode,'node':version,'nodeSha256':expected,'sourceHead':'d5ec4186d2033709e532bc93d6f47d930afe525f','sourceInventoryMatchesCurrent':True,'scientificSamplerInvoked':False})
    (output/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    print(json.dumps({'node':version,'exitCode':result.returncode}),flush=True)
assert subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=source)==b''
assert all(command['exitCode']==0 for command in commands)
