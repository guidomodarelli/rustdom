import json,subprocess
from pathlib import Path
root=Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom')
packet=root/'reports/benchmarks/native-class-ownership/range-control-telemetry-results/40154725015'
proof=root/'.cache/range-aa-result-qualification-proof';proof.mkdir(exist_ok=False)
argv=['python3','-B',str(packet/'tools/qualify.py'),str(root),'/home/guido/rustdom-validation/range-aa-telemetry-source-d5ec4186','/home/guido/rustdom-validation/range-aa-result-qualification-40154725015','/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node-22/bin/node','/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node/bin/node']
result=subprocess.run(argv,cwd=root,capture_output=True)
(proof/'stdout.log').write_bytes(result.stdout);(proof/'stderr.log').write_bytes(result.stderr)
(proof/'command.json').write_text(json.dumps({'argv':argv,'exitCode':result.returncode,'DOMExecuted':False,'newMeasurements':0})+'\n')
print(result.stdout.decode());assert result.returncode==0,result.stderr.decode()
