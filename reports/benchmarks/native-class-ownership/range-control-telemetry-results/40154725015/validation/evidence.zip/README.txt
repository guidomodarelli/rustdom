Evidencia ejecutada de lectores y replay offline. Los drivers archivados son solo inspeccion; usar tools/ actuales. Se preservan fallos iniciales, skips y limites. No ejecutar scripts del ZIP.
