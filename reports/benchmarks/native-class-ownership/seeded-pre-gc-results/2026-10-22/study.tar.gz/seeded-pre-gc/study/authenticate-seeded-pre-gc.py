import base64,hashlib,io,json,pathlib,subprocess,sys,tarfile
repo=pathlib.Path(sys.argv[1]).resolve() if len(sys.argv)>1 else pathlib.Path(__file__).resolve().parent.parent
run=lambda args:subprocess.run(args,cwd=repo,check=True,capture_output=True).stdout
head=run(['git','rev-parse','HEAD']).decode().strip()
assert run(['git','ls-remote','origin','refs/heads/feature/native-class-ownership']).decode().split()[0]==head
prefix='reports/validation/native-class-ownership/seeded-pre-gc-method/'
harness=json.loads((repo/prefix/'source-manifest.json').read_bytes())
review=json.loads((repo/prefix/'review.json').read_bytes())
assert review['actionableFindings']==0 and review['harnessSha256']==harness['sha256']
for name,digest in review['launchersSha256'].items():
    assert hashlib.sha256((repo/'.cache'/name).read_bytes()).hexdigest()==digest, name
blob=run(['git','archive','--format=tar',head,*[entry['path'] for entry in harness['files']]])
actual={}
with tarfile.open(fileobj=io.BytesIO(blob)) as stream:
    for member in stream:
        if member.isfile():actual[member.name]={'path':member.name,'bytes':member.size,
            'sha256':hashlib.sha256(stream.extractfile(member).read()).hexdigest()}
assert [actual[entry['path']] for entry in harness['files']]==harness['files']
receiptPath=prefix+'review.json'
remote=json.loads(run(['gh','api',f'repos/guidomodarelli/rustdom/contents/{receiptPath}?ref={head}']))
assert base64.b64decode(remote['content'])==(repo/receiptPath).read_bytes()
provenance={'reviewedCommit':head,'harnessSha256':harness['sha256'],
    'receiptUrl':f'https://github.com/guidomodarelli/rustdom/blob/{head}/{receiptPath}'}
publication={'head':head,'remoteHeadMatched':True,'sourceFiles':len(harness['files']),
    'allGitBlobsMatched':True,'reviewReceiptMatchedGitHub':True,'provenance':provenance,
    'publishedHarnessTarSha256':hashlib.sha256(blob).hexdigest(),
    'launchersSha256':review['launchersSha256']}
tarPath=repo/'.cache/seeded-pre-gc-published-harness.tar'
if tarPath.exists():assert tarPath.read_bytes()==blob, 'Preserve the existing published harness'
else:
    with tarPath.open('xb') as destination:destination.write(blob)
publicationPath=repo/'.cache/seeded-pre-gc-publication.json'
if publicationPath.exists():assert json.loads(publicationPath.read_bytes())==publication, 'Preserve the existing publication'
else:
    with publicationPath.open('x',encoding='utf-8',newline='\n') as destination:json.dump(publication,destination,indent=2)
print(json.dumps(publication))
