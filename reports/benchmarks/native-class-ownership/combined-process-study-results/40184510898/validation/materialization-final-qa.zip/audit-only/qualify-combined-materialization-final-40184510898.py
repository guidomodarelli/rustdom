"""Verify the complete fixed reader and its transitive configuration boundary using saved real transport and isolated current sources."""
import hashlib,json,subprocess,sys
from pathlib import Path
original=Path(sys.argv[1]).resolve(strict=True);source=Path(sys.argv[2]).resolve(strict=True);root=Path(sys.argv[3]);assert not root.exists();root.mkdir()
packet=original/'reports/benchmarks/native-class-ownership/combined-process-study-results/40184510898';reader=packet/'tools/materialize.py';qualifier=original/'.cache/qualify-combined-materialization-safe-cache-40184510898.py'
command=[sys.executable,'-B',str(qualifier),str(source),str(root/'qualification'),str(packet)]
child=subprocess.run(command,capture_output=True);(root/'qualification.stdout.log').write_bytes(child.stdout);(root/'qualification.stderr.log').write_bytes(child.stderr);assert child.returncode==0,child.stderr.decode(errors='replace')
receipt=json.loads((root/'qualification/receipt.json').read_bytes());policy=json.loads((packet/'tools/constants/materialization.json').read_bytes())
method=source/policy['transportReader'];probe=subprocess.run([sys.executable,'-B','-c','import importlib.util,sys; descriptor=importlib.util.spec_from_file_location("timestamp_cache_control_final",sys.argv[1]); module=importlib.util.module_from_spec(descriptor); descriptor.loader.exec_module(module)',str(method)],capture_output=True)
(root/'poison-control.stdout.log').write_bytes(probe.stdout);(root/'poison-control.stderr.log').write_bytes(probe.stderr);assert probe.returncode!=0 and b'COMBINED_POISON_CACHE_EXECUTED' in probe.stderr
injected=source/'injected-materialization-reader.py';assert not injected.exists();injected.write_text('raise RuntimeError("UNAUTHENTICATED_CONFIGURATION_HELPER_EXECUTED")\n',encoding='utf-8')
for dependency in policy['transportDependencies']:
 filename=source/dependency['path'];saved=filename.read_bytes();assert hashlib.sha256(saved).hexdigest()==dependency['sha256']
 if filename.name=='transport.json':
  config=json.loads(saved);config['reader']={'path':injected.relative_to(source).as_posix(),'sha256':hashlib.sha256(injected.read_bytes()).hexdigest(),'dependencies':[]};changed=(json.dumps(config)+'\n').encode()
 else: changed=saved+b' '
 name='reject-transitive-'+filename.stem;output=root/(name+'-output');command=[sys.executable,'-B',str(reader),str(source),str(packet),str(output)]
 try:
  filename.write_bytes(changed);child=subprocess.run(command,capture_output=True)
  (root/(name+'.stdout.log')).write_bytes(child.stdout);(root/(name+'.stderr.log')).write_bytes(child.stderr)
  assert child.returncode!=0 and b'current transport dependency changed' in child.stderr and b'UNAUTHENTICATED_CONFIGURATION_HELPER_EXECUTED' not in child.stderr and not output.exists(),name
 finally: filename.write_bytes(saved)
 receipt['commands'].append({'name':name,'argv':command,'exitCode':child.returncode,'expectedSuccess':False})
for dependency in policy['transportDependencies']: assert hashlib.sha256((source/dependency['path']).read_bytes()).hexdigest()==dependency['sha256']
receipt['poisonCacheRegression']={'controlCacheActuallyExecuted':True,'fixedReaderIgnoredCache':True,'sourceBytesUnchanged':True,'archivedCodeExecuted':False}
receipt['transitiveConfigurationRegression']={'independentPins':3,'allThreeRejectedBeforeOutput':True,'helperRedirectionRejectedBeforeExecution':True,'sourceConfigurationRestored':True}
receipt['configSha256']=hashlib.sha256((packet/'tools/constants/materialization.json').read_bytes()).hexdigest()
(root/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'platform':receipt['platform'],'contracts':len(receipt['commands']),'poisonCacheControlPassed':True,'configurationRedirectionRejected':True,'archivesByteIdentical':True,'readerSha256':receipt['readerSha256']}),flush=True)
