"""Exercise a timestamp/size-valid poison pyc control and the fixed materializer with actual archives, without altering reviewed sources."""
import hashlib,importlib.util,json,os,py_compile,shutil,subprocess,sys
from pathlib import Path
original=Path(sys.argv[1]).resolve(strict=True);root=Path(sys.argv[2]);assert not root.exists();root.mkdir()
repository=root/'source';repository.mkdir()
receipt_name='reports/validation/combined-process-capture-method/review.json'
publication=json.loads((original/receipt_name).read_bytes())
for name in [*publication['files'],receipt_name]:
 source=original/name;target=repository/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
 if name in publication['files']: assert hashlib.sha256(target.read_bytes()).hexdigest()==publication['files'][name]
method=repository/'reports/benchmarks/native-class-ownership/combined-process-study/transport.py';source_hash=hashlib.sha256(method.read_bytes()).hexdigest()
cache=Path(importlib.util.cache_from_source(str(method)));cache.parent.mkdir(parents=True,exist_ok=True)
poison=root/'poison-control.py';code=b'raise RuntimeError("COMBINED_POISON_CACHE_EXECUTED")\n';assert len(code)<method.stat().st_size
poison.write_bytes(code+b' '*(method.stat().st_size-len(code)));os.utime(poison,ns=(method.stat().st_atime_ns,method.stat().st_mtime_ns))
py_compile.compile(str(poison),cfile=str(cache),dfile=str(method),doraise=True)
command=[sys.executable,'-B','-c','import importlib.util,sys; descriptor=importlib.util.spec_from_file_location("timestamp_cache_control",sys.argv[1]); module=importlib.util.module_from_spec(descriptor); descriptor.loader.exec_module(module)',str(method)]
probe=subprocess.run(command,capture_output=True);(root/'poison-control.stdout.log').write_bytes(probe.stdout);(root/'poison-control.stderr.log').write_bytes(probe.stderr)
assert probe.returncode!=0 and b'COMBINED_POISON_CACHE_EXECUTED' in probe.stderr
packet=original/'reports/benchmarks/native-class-ownership/combined-process-study-results/40184510898'
qualifier=original/'.cache/qualify-combined-materialization-safe-cache-40184510898.py';output=root/'qualification'
child=subprocess.run([sys.executable,'-B',str(qualifier),str(repository),str(output),str(packet)],capture_output=True)
(root/'qualification.stdout.log').write_bytes(child.stdout);(root/'qualification.stderr.log').write_bytes(child.stderr)
assert child.returncode==0,child.stderr.decode(errors='replace')
assert hashlib.sha256(method.read_bytes()).hexdigest()==source_hash
receipt=json.loads((output/'receipt.json').read_bytes())
receipt['poisonCacheRegression']={'controlExitCode':probe.returncode,'controlCacheActuallyExecuted':True,'sourceBytesUnchanged':True,'sourceSha256':source_hash,'cacheBytes':cache.stat().st_size,'fixedReaderIgnoredCache':True,'isolatedSourceFiles':len(publication['files'])+1,'archivedCodeExecuted':False}
(root/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'platform':receipt['platform'],'contracts':len(receipt['commands']),'poisonCacheControlPassed':True,'fixedMaterializationPassed':True,'archivesByteIdentical':True}),flush=True)
