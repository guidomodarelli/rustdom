import hashlib,importlib.util,json,shutil
from pathlib import Path
repository=Path.cwd(); collection=repository/'.cache/combined-science-collection-40184510898'
binding_file=repository/'.cache/combined-process-run-40184510898/binding.results.json'; binding=json.loads(binding_file.read_bytes())
method=repository/'reports/benchmarks/native-class-ownership/combined-process-study/transport.py'
spec=importlib.util.spec_from_file_location('current_science_transport',method); transport=importlib.util.module_from_spec(spec); spec.loader.exec_module(transport)
assert transport.verify_collection(repository,collection,binding)['transportAuthenticated']
root=repository/'reports/benchmarks/native-class-ownership/combined-process-study-results/40184510898'
assert not root.exists(); root.mkdir(parents=True)
(root/'.gitattributes').write_text('* -text -whitespace\n',encoding='utf-8',newline='\n')
parts_directory=root/'parts';parts_directory.mkdir(); layout={}; part_bytes=33554432
for name in ['artifact.zip',binding['tarName']]:
 source=collection/name; entries=[]; checksum=hashlib.sha256(); total=0
 with source.open('rb') as content:
  ordinal=0
  while chunk:=content.read(part_bytes):
   filename=f'{name}.part-{ordinal:03d}'
   with (parts_directory/filename).open('xb') as output: output.write(chunk)
   entries.append({'name':filename,'bytes':len(chunk),'sha256':hashlib.sha256(chunk).hexdigest()});checksum.update(chunk);total+=len(chunk);ordinal+=1
 kind='zip' if name=='artifact.zip' else 'tar'
 assert total==binding[kind+'Bytes'] and checksum.hexdigest()==binding[kind+'Sha256']
 layout[name]={'bytes':total,'sha256':checksum.hexdigest(),'parts':entries}
(root/'parts.json').write_text(json.dumps(layout,indent=2)+'\n',encoding='utf-8',newline='\n')
metadata=root/'metadata';metadata.mkdir()
for source in sorted(collection.rglob('*')):
 if source.is_file() and source.name not in ['artifact.zip',binding['tarName']]:
  target=metadata/'transport'/source.relative_to(collection);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
for name in ['binding.activation.json','binding.results.json','latest.json','collect.stdout.log','collect.stderr.log']:
 source=binding_file.parent/name; assert source.is_file();shutil.copyfile(source,metadata/name)
shutil.copytree(repository/'.cache/combined-process-trigger-95e64bd2',metadata/'activation-receipt')
shutil.copyfile(method,root/'transport-current-reader.py.audit-only')
print(json.dumps({'root':str(root),'parts':sum(len(value['parts']) for value in layout.values()),'zipBytes':binding['zipBytes'],'tarBytes':binding['tarBytes'],'transportAuthenticated':True,'DOMExecuted':False}))
