"""Qualify actual published archive materialization on Windows/Linux using real bytes, links and filesystem destinations."""
import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
if sys.flags.optimize: raise RuntimeError('Qualification requires non-optimized Python')
repository=Path(sys.argv[1]).resolve(strict=True); root=Path(sys.argv[2]); platform='windows' if os.name=='nt' else 'linux'
packet=repository/'reports/benchmarks/native-class-ownership/combined-process-study-results/40184510898'
reader=packet/'tools/materialize.py'; assert not root.exists(); root.mkdir()
policy=json.loads((packet/'tools/constants/materialization.json').read_bytes())
inputs=[packet/name for name in policy['metadataFiles']]+list((packet/'parts').iterdir())
before={str(filename.relative_to(packet)):hashlib.sha256(filename.read_bytes()).hexdigest() for filename in inputs}
receipt={'platform':platform,'python':sys.version,'readerSha256':hashlib.sha256(reader.read_bytes()).hexdigest(),'commands':[],'archivedCodeExecuted':False,'measurementExecuted':False}
def invoke(name,source,destination,success,optimized=False):
 command=[sys.executable,'-O' if optimized else '-B',str(reader),str(repository),str(source),str(destination)]
 with (root/(name+'.stdout.log')).open('xb') as stdout,(root/(name+'.stderr.log')).open('xb') as stderr: child=subprocess.run(command,stdout=stdout,stderr=stderr)
 receipt['commands'].append({'name':name,'argv':command,'exitCode':child.returncode,'expectedSuccess':success})
 assert (child.returncode==0)==success,name
 if not success and name!='preserve-existing-output': assert not destination.exists(),name
 receipt_file=root/'receipt.json';receipt_file.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
invoke('reconstruct-real-archives',packet,root/'reconstructed',True)
valid=json.loads((root/'reconstruct-real-archives.stdout.log').read_bytes());assert valid['transportAuthenticated'] and valid['performanceAccepted'] is None
for name,declared in json.loads((packet/'parts.json').read_bytes()).items(): assert hashlib.sha256((root/'reconstructed'/name).read_bytes()).hexdigest()==declared['sha256']
existing=root/'existing';existing.mkdir();(existing/'sentinel').write_bytes(b'foreign destination preserved')
invoke('preserve-existing-output',packet,existing,False);assert (existing/'sentinel').read_bytes()==b'foreign destination preserved'
for category in ['bad-part','bad-metadata']:
 clone=root/category;clone.mkdir();shutil.copytree(packet/'metadata',clone/'metadata');shutil.copyfile(packet/'parts.json',clone/'parts.json');(clone/'parts').mkdir()
 if category=='bad-part':
  original=sorted((packet/'parts').iterdir())[0];changed=clone/'parts'/original.name
  shutil.copyfile(original,changed)
  with changed.open('r+b') as content: first=content.read(1);content.seek(0);content.write(bytes([first[0]^1]))
 else:
  changed=clone/'metadata/binding.results.json';changed.write_bytes(changed.read_bytes()+b' ')
 invoke('reject-'+category,clone,root/(category+'-output'),False)
link=root/'packet-link'
if os.name=='nt':
 child=subprocess.run(['cmd','/d','/c','mklink','/J',str(link),str(packet)],capture_output=True);assert child.returncode==0,child.stderr
 receipt['linkKind']='junction'
else: link.symlink_to(packet,target_is_directory=True);receipt['linkKind']='symlink'
invoke('reject-packet-link',link,root/'link-output',False)
invoke('reject-optimized-python',packet,root/'optimized-output',False,optimized=True)
after={str(filename.relative_to(packet)):hashlib.sha256(filename.read_bytes()).hexdigest() for filename in inputs}
assert before==after
receipt.update(sourceInputPreserved=True,archivesByteIdentical=True,transportAuthenticated=True,performanceAccepted=None,gateReevaluated=False)
(root/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'platform':platform,'passed':len(receipt['commands']),'archivesByteIdentical':True,'sourceInputPreserved':True,'linkKind':receipt['linkKind']}),flush=True)
