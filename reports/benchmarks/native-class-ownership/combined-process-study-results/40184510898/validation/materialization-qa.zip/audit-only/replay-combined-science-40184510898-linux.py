"""Reproduce one saved authenticated result with current reviewed readers and both pinned SDKs; never executes archived code or captures DOM."""
import concurrent.futures,datetime,hashlib,json,subprocess,sys
from pathlib import Path
if sys.flags.optimize: raise RuntimeError('Replay requires non-optimized Python')
repository=Path('/home/guido/rustdom-validation/combined-process-source-95e64bd2')
owner=Path('/mnt/c/Users/guido/.codex/worktrees/native-class-ownership/rustdom')
collection=owner/'.cache/combined-science-collection-40184510898'
binding=owner/'.cache/combined-process-run-40184510898/binding.results.json'
root=Path('/home/guido/rustdom-validation/combined-process-replay-40184510898')
assert binding.is_file() and not root.exists()
assert subprocess.check_output(['git','-C',str(repository),'rev-parse','HEAD'],text=True).strip()=='95e64bd20711975b08864cf1bef1dee362b79663'
assert not subprocess.check_output(['git','-C',str(repository),'status','--porcelain'])
assert len(json.loads((repository/'reports/validation/combined-process-capture-method/review.json').read_bytes())['files'])==724
for name,checksum in json.loads((repository/'reports/validation/combined-process-capture-method/review.json').read_bytes())['files'].items(): assert hashlib.sha256((repository/name).read_bytes()).hexdigest()==checksum,name
root.mkdir()
sdks=[('22',Path('/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node-22/bin/node'),'v22.12.0','177208bfc4a9403121a40c72d038c670f4fd937fa16ca7df0a720e90be0fe2d9'),('24',Path('/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node/bin/node'),'v24.14.1','bf9112eb83a827dc9f9c8d19bb7bddcbf00f7b2fedae18fdcaee05406981f20a')]
receipt={'runId':40184510898,'jobId':121142337986,'attempt':1,'sourceCommit':'95e64bd20711975b08864cf1bef1dee362b79663','archivedCodeExecuted':False,'measurementExecuted':False,'SDKs':[]}
for major,node,version,checksum in sdks:
 assert hashlib.sha256(node.read_bytes()).hexdigest()==checksum
 assert subprocess.check_output([str(node),'--version'],text=True).strip()==version
 destination=root/('node'+major)
 command=[str(node),str(repository/'reports/benchmarks/native-class-ownership/combined-process-study/decision.cjs'),str(binding),str(collection),str(destination)]
 with (root/('node'+major+'.stdout.log')).open('xb') as stdout,(root/('node'+major+'.stderr.log')).open('xb') as stderr:
  child=subprocess.run(command,cwd=repository,stdout=stdout,stderr=stderr)
 decision=json.loads((destination/'decision.json').read_bytes()) if (destination/'decision.json').is_file() else None
 receipt['SDKs'].append({'node':version,'sha256':checksum,'argv':command,'exitCode':child.returncode,'decision':decision})
 (root/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
 print(json.dumps({'node':version,'exitCode':child.returncode,'complete':None if decision is None else decision['complete'],'performanceAccepted':None if decision is None else decision['performanceAccepted'],'phase':None if decision is None else decision['phase'],'failure':None if decision is None else decision.get('failure',{}).get('message')}),flush=True)
assert not subprocess.check_output(['git','-C',str(repository),'status','--porcelain'])
print(json.dumps({'replayRoot':str(root),'SDKs':len(receipt['SDKs']),'measurementExecuted':False}),flush=True)
