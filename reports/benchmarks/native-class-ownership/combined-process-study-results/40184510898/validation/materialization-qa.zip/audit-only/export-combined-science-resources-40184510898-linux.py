"""Export the already verified full scientific payload with the current pinned resource reader and both official SDKs; no measurement."""
import hashlib,json,subprocess,sys
from pathlib import Path
if sys.flags.optimize: raise RuntimeError('Resource replay requires non-optimized Python')
source=Path('/home/guido/rustdom-validation/combined-resource-source-fc99401e')
replay=Path('/home/guido/rustdom-validation/combined-process-replay-40184510898')
capture=replay/'node22/extracted/combined-process-study/capture'
assert json.loads((replay/'node22/decision.json').read_bytes())['complete'] and json.loads((replay/'node24/decision.json').read_bytes())['complete']
assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()=='fc99401e790d517f7a1f1abec43f0c42c2d2b716'
assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain'])
method=source/'reports/benchmarks/native-class-ownership/combined-process-exports'
for name,checksum in json.loads((method/'constants/ci-files.json').read_bytes())['files'].items(): assert hashlib.sha256((source/name).read_bytes()).hexdigest()==checksum,name
root=Path('/home/guido/rustdom-validation/combined-resource-replay-40184510898'); assert not root.exists(); root.mkdir()
receipt={'runId':40184510898,'archivedCodeExecuted':False,'measurementExecuted':False,'performanceAccepted':None,'gateReevaluated':False,'SDKs':[]}
for major,node in [('22','/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node-22/bin/node'),('24','/mnt/c/Users/guido/ghq/projects/rustdom/.tools/node/bin/node')]:
 destination=root/('node'+major)
 command=[node,str(method/'resources.cjs'),'--capture',str(capture),str(destination)]
 with (root/('node'+major+'.stdout.log')).open('xb') as stdout,(root/('node'+major+'.stderr.log')).open('xb') as stderr: child=subprocess.run(command,cwd=source,stdout=stdout,stderr=stderr)
 files={path.name:{'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()} for path in destination.iterdir() if path.is_file()} if destination.is_dir() else {}
 receipt['SDKs'].append({'nodeMajor':major,'exitCode':child.returncode,'argv':command,'files':files})
 (root/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
 print(json.dumps({'nodeMajor':major,'exitCode':child.returncode,'files':files}),flush=True)
 assert child.returncode==0
for name in ['spans.csv','resources-native.jsonl']: assert receipt['SDKs'][0]['files'][name]==receipt['SDKs'][1]['files'][name],name
assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain'])
print(json.dumps({'exportsByteIdentical':True,'measurementExecuted':False,'root':str(root)}),flush=True)
