//! Shared lossless DOM-string conversion at the Node-API boundary.
use super::data::DomString;
use napi::bindgen_prelude::{Either, Either3, Undefined, Utf16String};

/// Copy borrowed UTF-8 directly into V8; preserve isolated UTF-16 units on the fallback.
pub(super) fn string_result(value: Option<&DomString>) -> Option<Either<&str, Utf16String>> {
    value.map(|value| match value {
        DomString::Text(value) => Either::A(value.as_str()),
        DomString::Utf16(value) => Either::B(value.clone().into()),
        DomString::Undefined => unreachable!("Undefined is restricted to CharacterData getters"),
    })
}

/// Preserve internal undefined separately from nullable Node values at the V8 boundary.
pub(super) fn node_string_result(
    value: Option<&DomString>,
) -> Option<Either3<&str, Utf16String, Undefined>> {
    value.map(|value| match value {
        DomString::Text(value) => Either3::A(value.as_str()),
        DomString::Utf16(value) => Either3::B(value.clone().into()),
        DomString::Undefined => Either3::C(()),
    })
}

/// Own short DOM inputs on the stack; longer values retain the ordinary owned UTF-16 representation.
pub enum DomStringInput {
    Inline {
        units: [u16; super::constants::INLINE_DOM_STRING_CAPACITY_UNITS + 1],
        length: usize,
    },
    Heap(Utf16String),
}

impl napi::bindgen_prelude::TypeName for DomStringInput {
    fn type_name() -> &'static str {
        <Utf16String as napi::bindgen_prelude::TypeName>::type_name()
    }
    fn value_type() -> napi::ValueType {
        napi::ValueType::String
    }
}

impl napi::bindgen_prelude::ValidateNapiValue for DomStringInput {}

impl std::ops::Deref for DomStringInput {
    type Target = [u16];
    fn deref(&self) -> &Self::Target {
        match self {
            Self::Inline { units, length } => &units[..*length],
            Self::Heap(units) => units,
        }
    }
}

impl napi::bindgen_prelude::FromNapiValue for DomStringInput {
    unsafe fn from_napi_value(
        env: napi::sys::napi_env,
        value: napi::sys::napi_value,
    ) -> napi::Result<Self> {
        use super::constants::{
            INLINE_DOM_STRING_CAPACITY_UNITS, NAPI_UTF16_INPUT_CONVERSION_ERROR,
        };
        let mut units = [0; INLINE_DOM_STRING_CAPACITY_UNITS + 1];
        let mut written = 0;
        // The extra slot receives Node-API's terminator. The result counts copied UTF-16 units,
        // including embedded NUL values, and never performs Unicode replacement or user coercion.
        napi::check_status!(
            unsafe {
                napi::sys::napi_get_value_string_utf16(
                    env,
                    value,
                    units.as_mut_ptr(),
                    units.len(),
                    &mut written,
                )
            },
            "{}",
            NAPI_UTF16_INPUT_CONVERSION_ERROR
        )?;
        if written < INLINE_DOM_STRING_CAPACITY_UNITS {
            return Ok(Self::Inline {
                units,
                length: written,
            });
        }
        let mut length = 0;
        napi::check_status!(
            unsafe {
                napi::sys::napi_get_value_string_utf16(
                    env,
                    value,
                    std::ptr::null_mut(),
                    0,
                    &mut length,
                )
            },
            "{}",
            NAPI_UTF16_INPUT_CONVERSION_ERROR
        )?;
        if length <= INLINE_DOM_STRING_CAPACITY_UNITS {
            return Ok(Self::Inline { units, length });
        }
        let mut buffer = vec![0; length + 1];
        napi::check_status!(
            unsafe {
                napi::sys::napi_get_value_string_utf16(
                    env,
                    value,
                    buffer.as_mut_ptr(),
                    buffer.len(),
                    &mut written,
                )
            },
            "{}",
            NAPI_UTF16_INPUT_CONVERSION_ERROR
        )?;
        buffer.truncate(written);
        Ok(Self::Heap(buffer.into()))
    }
}
