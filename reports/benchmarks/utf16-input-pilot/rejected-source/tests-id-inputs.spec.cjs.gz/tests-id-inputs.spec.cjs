/** @file Real-addon UTF16 input boundaries, public coercion and raw registration error contracts. */
'use strict';
const { test, after } = require('node:test');
const assert = require('node:assert/strict');
const { mkdirSync, readFileSync, writeFileSync, existsSync } = require('node:fs');
const { createHash } = require('node:crypto');
const engines = { jsdom: require('jsdom'), rustdom: require('../dist/index.cjs') };
const native = require('../dist/native.cjs');
const values = [...[0, 1, 15, 31, 62, 63, 64, 65, 66, 127, 128, 129, 4096].map((length) => 'x'.repeat(length)),
  ...[62, 63, 64].flatMap((length) => ['x'.repeat(length) + '\ud800', 'x'.repeat(length) + '\udc00',
    'x'.repeat(length) + '𠮷', 'x'.repeat(length) + '\0tail']), '\ud800'.repeat(4096), '𠮷\0'.repeat(2048)];
const report = { capturedAt: new Date().toISOString(), node: process.version,
  reference: require('jsdom/package.json').version, values: values.length, cases: [], raw: [] };
for (const realm of ['default', 'vm']) for (const kind of ['document', 'fragment', 'svg']) {
  test(`should preserve exact short boundary long and isolated UTF16 inputs in ${realm}/${kind}`, () => {
    const observations = {};
    for (const [engine, runtime] of Object.entries(engines)) {
      const { window } = new runtime.JSDOM('<!doctype html><body>', realm === 'vm' ? { runScripts: 'outside-only' } : {});
      const document = window.document;
      const root = kind === 'fragment' ? document.createDocumentFragment() : kind === 'svg'
        ? document.createElementNS('http://www.w3.org/2000/svg', 'svg') : document.createElement('section');
      if (kind !== 'fragment') document.body.append(root);
      const scope = kind === 'document' ? document : root;
      const cases = [];
      try {
        for (const value of values) {
          root.replaceChildren();
          const target = document.createElementNS('urn:id-input', 'p:entry');
          target.setAttribute('id', value); root.append(target);
          const expected = value === '' && kind !== 'svg' ? null : target;
          assert.equal(scope.getElementById(value), expected);
          assert.equal(scope.getElementById(Object(value)), expected);
          assert.equal(target.getAttribute('id'), value);
          let conversions = 0;
          const key = { toString() { conversions++; target.setAttribute('id', value); return value; } };
          assert.equal(scope.getElementById(key), expected); assert.equal(conversions, 1);
          assert.equal(scope.getElementById(value + '!'), null);
          cases.push({ units: value.length, returned: expected === target, conversions,
            valueSha256: createHash('sha256').update(Buffer.from(value, 'utf16le')).digest('hex') });
        }
      } finally { window.close(); }
      observations[engine] = cases;
    }
    assert.deepEqual(observations.rustdom, observations.jsdom);
    report.cases.push({ realm, kind, ...observations });
  });
}

test('should preserve raw input validation nullability registration and non-coercion contracts', () => {
  for (const method of ['queryElementById', 'queryDocumentElementById', 'querySvgElementById',
    'attachDocumentId', 'detachDocumentId', 'changeDocumentId']) {
    for (const input of ['undefined', 'null', 'number', 'boolean', 'symbol', 'object', 'boxed-string']) {
      const tree = new native.NativeTree();
      const document = tree.allocate(); tree.setData(document, '{"kind":9}');
      const element = tree.allocate(); tree.setData(element, '{"kind":1,"name":"entry","attributes":[{"name":"id","value":"original"}]}');
      tree.append(document, element); tree.attachDocumentId(document, element, 'original');
      let coercions = 0;
      const marker = new Error('raw ID conversion must not invoke user code');
      const value = input === 'undefined' ? undefined : input === 'null' ? null : input === 'number' ? 7
        : input === 'boolean' ? true : input === 'symbol' ? Symbol('id-input')
        : input === 'boxed-string' ? Object('original') : { toString() { coercions++; throw marker; } };
      let error = null;
      try {
        if (method.startsWith('query')) tree[method](method === 'querySvgElementById' ? element : document, value);
        else if (method === 'changeDocumentId') tree[method](document, element, value, 'changed');
        else tree[method](document, element, value);
      } catch (caughtError) {
        error = { name: caughtError.name, message: caughtError.message, sameError: caughtError === marker };
      }
      const nullable = !method.startsWith('query') && ['undefined', 'null'].includes(input);
      assert.equal(error === null, nullable, method + ':' + input);
      assert.equal(coercions, 0); if (error) assert.equal(error.sameError, false);
      const statistics = tree.documentIdStatistics();
      assert.equal(statistics.entries, nullable && method === 'changeDocumentId' ? 2 : 1);
      const original = tree.queryDocumentElementById(document, 'original') === element;
      const changed = tree.queryDocumentElementById(document, 'changed') === element;
      assert.equal(original, true);
      assert.equal(changed, nullable && method === 'changeDocumentId');
      report.raw.push({ method, input, error, coercions,
        entries: statistics.entries, names: statistics.names, memberships: statistics.memberships,
        original, changed });
      tree.release(element); tree.release(document);
      assert.equal(tree.documentIdStatistics().entries, 0);
    }
  }
  const baseline = 'reports/validation/id-inputs/raw-baseline-' + process.version + '.json';
  if (existsSync(baseline)) assert.deepEqual(report.raw, JSON.parse(readFileSync(baseline, 'utf8')));
});

after(() => {
  mkdirSync('reports/validation/id-inputs', { recursive: true });
  const path = 'reports/validation/id-inputs/' + report.capturedAt.replaceAll(':', '-') + '-contracts.json';
  writeFileSync(path, JSON.stringify(report, null, 2) + '\n'); console.log('Guardado: ' + path);
});
