'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const { createHash } = require('node:crypto');
const { Session } = require('node:inspector');
const { performance } = require('node:perf_hooks');
const root = process.argv[2];
const output = root + '/reports/validation/id-input-profile';
fs.mkdirSync(output, { recursive: true });
const capturedAt = new Date().toISOString();
const stamp = capturedAt.replaceAll(':', '-');
const engines = { jsdom: require(root + '/node_modules/jsdom'), rustdom: require(root + '/dist/index.cjs') };
const source = require(root + '/benchmarks/sources.cjs').captureSourceIdentity(root);
const nativeBuild = JSON.parse(fs.readFileSync(root + '/dist/native-build.json'));
assert.equal(nativeBuild.binarySha256, 'cc8852f6ba6e3755fbe8805948c8fb71bd140323b08b86d091727aacc8ed6753');
assert.equal(source.sourceHash, '95f641ef6dd84ddac7bbd70119121ece19669c125d5bb3c70d9693c9770a19b1');
const report = { capturedAt, node: process.version, baselinePublishedHead: 'be90ba1ac6b7404c585a8e1905e7808d883b512b',
  sourceHash: source.sourceHash, nativeBinarySha256: nativeBuild.binarySha256,
  scriptSha256: createHash('sha256').update(fs.readFileSync(__filename)).digest('hex'),
  methodology: 'Diagnostic CPU profiles of actual public Document ID reads/misses. One profiled series per case, sampling interval 100 microseconds, 50000 warmup and 2000000 measured queries over 1000 Elements. Profiler overhead is included; elapsed values are not controlled benchmark comparisons or speedup claims. Both namespaces and all three fixture attributes are preserved.', cases: [] };
async function main() {
  for (const [engine, runtime] of Object.entries(engines)) for (const kind of ['read', 'miss']) {
    const { window } = new runtime.JSDOM('<!doctype html><body>');
    const document = window.document;
    let target;
    const session = new Session();
    const post = (method, params = {}) => new Promise((resolve, reject) => session.post(method, params, (error, result) => error ? reject(error) : resolve(result)));
    try {
      for (let index = 0; index < 1000; index++) {
        const namespace = index % 2 === 0 ? 'http://www.w3.org/1999/xhtml' : 'urn:collection';
        const element = document.createElementNS(namespace, namespace === 'urn:collection' ? 'p:entry' : 'div');
        element.setAttribute('data-id-entry', String(index)); element.id = 'id-entry-' + index;
        element.setAttributeNS('urn:collection', 'p:id', 'id-missing'); document.body.append(element); target = element;
      }
      const key = kind === 'miss' ? 'id-missing' : 'id-entry-999';
      if (kind === 'miss') target = null;
      for (let iteration = 0; iteration < 50000; iteration++) assert.equal(document.getElementById(key), target);
      session.connect(); await post('Profiler.enable'); await post('Profiler.setSamplingInterval', { interval: 100 });
      const before = runtime.getNativeTreeStatistics?.().nativeCollectionQueries;
      await post('Profiler.start');
      let checksum = 0; const started = performance.now();
      for (let iteration = 0; iteration < 2000000; iteration++) checksum += Number(document.getElementById(key) === target);
      const elapsedMs = performance.now() - started;
      const { profile } = await post('Profiler.stop');
      assert.equal(checksum, 2000000);
      if (before !== undefined) assert.equal(runtime.getNativeTreeStatistics().nativeCollectionQueries - before, 2000000);
      assert.equal(document.getElementById(key), target);
      const name = stamp + '-' + engine + '-' + kind + '.cpuprofile';
      fs.writeFileSync(path.join(output, name), JSON.stringify(profile), { flag: 'wx' });
      report.cases.push({ engine, kind, elapsedMs, checksum, samples: profile.samples.length, profile: name,
        topFunctions: [...profile.nodes].sort((left, right) => (right.hitCount || 0) - (left.hitCount || 0)).slice(0, 15).map((node) => ({
          name: node.callFrame.functionName, url: node.callFrame.url, line: node.callFrame.lineNumber, hits: node.hitCount || 0 })) });
    } finally { session.disconnect(); window.close(); }
    await new Promise((resolve) => setImmediate(resolve)); global.gc?.();
  }
  const destination = path.join(output, stamp + '-summary.json');
  fs.writeFileSync(destination, JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
  console.log(JSON.stringify({ path: destination, cases: report.cases.map(({ engine, kind, elapsedMs, samples, topFunctions }) => ({ engine, kind, elapsedMs, samples, topFunctions: topFunctions.slice(0, 6) })) }));
}
main().catch((error) => { console.error(error); process.exitCode = 1; });
